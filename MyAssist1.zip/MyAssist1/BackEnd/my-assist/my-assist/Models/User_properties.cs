﻿namespace my_assist.Models
{
    public class User_Login
    {
        public string userName { get; set; }
        public string password { get; set; }
    }
    public class User_properties
    {
        public string tokenString { get; set; }
        public string StrUsrNme { get; set; }
        public string StrPassword { get; set; }
        public string StrRole { get; set; }
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public string StrMsg { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public List<int> LstModuleIds { get; set; }
        public string IsActive { get; set; }
        public string Enable { get; set; }

    }
}
    public class Module_properties
    {
       public string StrModuleName { get; set; }
        public int UserID { get; set; }
        public int MODULE_ID { get; set; }
    }
    
