﻿namespace my_assist.Models
{
    public class Login
    {
    }
    public class UserLogin
    {
        public string UserName { get; set; }
        public string Password { get; set; }


    }
    public class ForgetPassword
    {
        public int id { get; set; }
        public string value { get; set; }
    }
}
