﻿namespace my_assist.Models
{
    public class Home_Properties
    {
    }

    public class Claims_properties
    {
        public int USER_ID { get; set; }
        public int SEARCH_ID { get; set; }
        public string CLCL_ID { get; set; }
        public string SBSB_ID { get; set; }
        public string CKPY_REF_ID { get; set; }
        public string CDML_UMAUTH_ID { get; set; }
        public string CDML_UMREF_ID { get; set; }
        public string MB_TYPE { get; set; }
        public string MB_VAL { get; set; }
        public int C_SEQ_NO { get; set; }
        public int SBSB_CK { get; set; }
        public int GRGR_CK { get; set; }
        public int UNITS { get; set; }
        public string PRPR_ID { get; set; }
        public string CSPI_ID { get; set; }
        public string PRPR_NPI { get; set; }
        public string PRPR_NAME { get; set; }
        public string CLCL_CL_TYPE { get; set; }
        public string CLCL_CUR_STS { get; set; }
        public string START_DT { get; set; }
        public string END_DT { get; set; }
        public decimal CLCL_TOT_CHG { get; set; }
        public decimal CLCL_TOT_PAYABLE { get; set; }
        public decimal MEMB_LIABILITY { get; set; }
        public string CLCL_NTWK_IND { get; set; }
        public string PLDS_DESC { get; set; }
        public string CLCL_TYPE { get; set; }
        public string DATE_TYPE { get; set; }
        public string POS { get; set; }
        public string SERVICE_ID { get; set; }
        public string SEDS_DESC { get; set; }
        public string PSCD_DESC { get; set; }
        public string SESE_ID { get; set; }
        public string IDCD_ID { get; set; }
        public string CLCL_LOW_SVC_DT { get; set; }
        public string CLCL_HIGH_SVC_DT { get; set; }
        public string CLCL_PAID_DT { get; set; }
        public DateTime? FROM_DT { get; set; }
        public DateTime? TO_DATE { get; set; }



        
    }

    public class Meme_properties
    {
        public int USER_ID { get; set; }
        public int SEARCH_ID { get; set; }
        public string SBSB_ID { get; set; }
        public int MEME_ID { get; set; }
        public string? GRGR_ID { get; set; }
        public string? MEME_REL { get; set; }
        public string? SGSG_ID { get; set; }
        public string? FIRST_NAME { get; set; }
        public string? LAST_NAME { get; set; }
        public string? BIRTH_DT { get; set; }
        //public DateTime DOB { get; set; }
       public string? DOB { get; set; }
        public string? GENDER { get; set; }
    }

    public class Meme_Desc_properties
    {

        public string? SBSB_NAME { get; set; }
        public string MEME_REL { get; set; }
        public string GRGR_ID { get; set; }
        public string SBSB_ID { get; set; }
        public string MCRE_ID { get; set; }
        public string GRGR_NAME { get; set; }
        public decimal? NET_DUE { get; set; }
        public string COB { get; set; }
        public string LAST_PAY_DT { get; set; }
        public string MEME_STATUS { get; set; }
        public string ID_MAILED_DT { get; set; }
        public string DELIQUENCY_DT { get; set; }
        public int SBSB_CK { get; set; }
        public int SGSG_CK { get; set; }
        public int MEME_CK { get; set; }
        public int GRGR_CK { get; set; }
        public string PLAN_DESC { get; set; }
        public string CARRIER_NAME { get; set; }
        public string COB_EFF_DT { get; set; }
        public string COB_TERM_DT { get; set; }
        public string MEMBER_RELATION { get; set; }
        public string MEMBER_NAME { get; set; }
        public string PLAN_EFF_DT { get; set; }
        public string PLAN_TERM_DT { get; set; }
        public string MEMBER_DOB { get; set; }
        public string HOME_ADDRESS { get; set; }
        public string PCP_DETAILS { get; set; }
    }
    public class PRPR_properties
    {
        public int USER_ID { get; set; }
        public int SEARCH_ID { get; set; }
        public string PRPR_NPI { get; set; }
        public string PRPR_ID { get; set; }
        public string PRPR_NAME { get; set; }
        public string PRPR_SPEC { get; set; }
        public string PRPR_MED_IND { get; set; }
        public string NWPR_PCP_IND { get; set; }
        public string BILLING_IND { get; set; }
        public string PRPR_ENTITY { get; set; }
        public string NWNW_ID { get; set; }
        public string NWNW_NAME { get; set; }
        public string PRPR_FLAG { get; set; }
        public DateTime? FROM_DT { get; set; }
        public DateTime? END_DT { get; set; }
        public string? FROM_DTs { get; set; }
        public string? END_DTs { get; set; }
    }

    public class PRPR_DESC_properties
    {
        public string NWNW_ID { get; set; }
        public string NWPR_PCP_IND { get; set; }
        public string PRPR_STS { get; set; }
        public string NWPR_EFF_DT { get; set; }
        public string NWPR_TERM_DT { get; set; }
        public string PRCP_ID { get; set; }
        public string ADDRESS { get; set; }
        public string PRPR_NPI { get; set; }
        public string PRAD_TYPE_CHECK { get; set; }
        public string MCTN_ID { get; set; }
        public string PRCR_INIT_CRED_DT { get; set; }
        public string PRPR_NAME { get; set; }
        public string NWPR_AUTO_PCP_IND { get; set; }
    }
    public class BILL_properties
    {

        public string? INVOICE_ID { get; set; }
        public int USER_ID { get; set; }
        public int SEARCH_ID { get; set; }
        public string GRGR_ID { get; set; }
        public string GSM_TYPE { get; set; }
        public string GSM_VAL { get; set; }
        public string DT_TYPE { get; set; }
        public string ENTITY_TYPE { get; set; }
        public DateTime? STRT_DT { get; set; }
        public DateTime? END_DT { get; set; }
        public string STRT_DTs { get; set; }
        public string END_DTs { get; set; }
    }

    public class BILL_DESC_properties
    {
        public decimal BLEI_NET_DUE { get; set; }
        public decimal RCPT_AMT { get; set; }
        public decimal BLBL_BILLED_AMT { get; set; }
        public decimal BLBL_RCVD_AMT { get; set; }
        public string BLEI_LST_PD_DUE_DT { get; set; }
        public string REFUND_DT { get; set; }
        public string BLEI_LST_BL_DUE_DT { get; set; }
        public string GRGR_ID { get; set; }
        public string GRGR_NAME { get; set; }
        public string SGSG_ID { get; set; }
        public string SGSG_NAME { get; set; }
        public string SBSB_ID { get; set; }
        public string SUSB_NAME { get; set; }
        public string BLIV_ID { get; set; }
        public string BLBL_CREATE_DTM { get; set; }
        public string BLBL_DUE_DT { get; set; }
        public string RCPT_ID { get; set; }
        public string BLEI_BILL_LEVEL { get; set; }
        public string PLDS_DESC { get; set; }
        public int Lives { get; set; }
        public decimal TotalBreakUp { get; set; }
        public decimal INID_OUTSTAND_BAL { get; set; }
        public int BLEI_CK { get; set; }
    }

    public class UM_properties
    {
        public int USER_ID { get; set; }
        public int SEARCH_ID { get; set; }
        public string MEME_ID { get; set; }
        public string UM_ID { get; set; }
        public string DTRNG_TYPE { get; set; }
        public string STATUS { get; set; }
        public string UM_TYPE { get; set; }
        public string SRVC_TYPES { get; set; }
        public string PRPR_NPI { get; set; }
        public string REQ_NPI { get; set; }
        public string SRVC_NPI { get; set; }
        public DateTime? START_DT { get; set; }
        public DateTime? END_DT { get; set; }
        public string START_DTs { get; set; }
        public string END_DTs { get; set; }
    }

    public class UM_DESC_properties
    {
        public string UMUM_REF_ID { get; set; }
        public string UMSV_RECD_DT { get; set; }
        public string UMSV_FROM_DT { get; set; }
        public string UMSV_PRPR_ID_REQ { get; set; }
        public string UMSV_PRPR_ID_SVC { get; set; }
        public string UMVT_STS { get; set; }
        public string REF_TYPE { get; set; }
        public string CLCL_ID { get; set; }
        public int REQUESTED_UNITS { get; set; }
        public int AUTHORIZATION_UNITS { get; set; }
        public string AUTHORIZATION_DT { get; set; }
        public string PROCEDURE_CODE { get; set; }
        public string DIAGNOSIS_CODE { get; set; }
        public string SERVICE_TYPE { get; set; }
        public string AUTHORIZATION_HISTORY { get; set; }
        public string UM_STATUS { get; set; }
        public string SBSB_ID { get; set; }
    }

    public class BNFT_properties
    {
        public int USER_ID { get; set; }
        public int SEARCH_ID { get; set; }
        public string GRGR_ID { get; set; }
        public string CSPI_ID { get; set; }
        public string PDPD_ID { get; set; }
        public string LOB { get; set; }
        public DateTime? EFF_FROM_DT { get; set; }
        public DateTime? EFF_TO_DT { get; set; }
        public DateTime? END_FROM_DT { get; set; }
        public DateTime? END_TO_DT { get; set; }
        public string EFF_FROM_DTs { get; set; }
        public string EFF_TO_DTs { get; set; }
        public string END_FROM_DTs { get; set; }
        public string END_TO_DTs { get; set; }
    }
    public class BNFT_DESC_properties
    {
        public string CSPI_ID { get; set; }
        public string PDPD_ID { get; set; }
        public string GRGR_ID { get; set; }
        public string CSPI_EFF_DT { get; set; }
        public string CSPI_TERM_DT { get; set; }
        public string PLDS_DESC { get; set; }
        public string CSPD_CAT { get; set; }
        public string PDDS_MCTR_BCAT { get; set; }
        public int ACCOUNT_NO { get; set; }
        public string RELATION { get; set; }
        public string Accumulator_Name { get; set; }
        public Decimal ACC_AMT1 { get; set; }
        public Decimal ACC_AMT2 { get; set; }
        public string Benefits_Name { get; set; }
        public string Pre_Auth_Indicator { get; set; }
        public string Limits_Applies_to_Service_or_not { get; set; }
    }

    }
