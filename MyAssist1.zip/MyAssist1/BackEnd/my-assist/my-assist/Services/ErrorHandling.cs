﻿using System.Xml;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace my_assist.Services
{
    public class ErrorHandling
    {
        IHostingEnvironment _envi;
        public ErrorHandling(IHostingEnvironment envi)
        {
            _envi = envi;
        }

        public void GetXmlString(Exception exception)
        {
            if (exception == null)
            {
                throw new ArgumentNullException("exception");
            }
            using (XmlWriter xw = XmlWriter.Create(Path.Combine(_envi.WebRootPath + "/" + "Error_Data", Guid.NewGuid().ToString() + ".xml")))//System.IO.Path.Combine("")))// HttpContext.Current.Server.MapPath("~/Error_Data"), Guid.NewGuid().ToString() + ".xml")))
            {
                WriteException(xw, "exception", exception);
            }
        }

        public void WriteException(XmlWriter writer, string name, Exception exception)
        {
            if (exception == null) return;
            writer.WriteStartElement(name);
            writer.WriteElementString("message", exception.Message);
            writer.WriteElementString("source", exception.Source);
            writer.WriteElementString("Date", DateTime.Now.ToString());
            writer.WriteElementString("stackTrace", exception.StackTrace);
            WriteException(writer, "innerException", exception.InnerException);
            writer.WriteEndElement();
        }
    }
   
}
