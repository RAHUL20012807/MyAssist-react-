﻿using System.Data.SqlClient;
using System.Data;
using my_assist.Models;

namespace my_assist.Services
{
    public class cls_Home : IHome
    {

        private readonly IConfiguration _configuration;
        SqlConnection con;
        SqlConnection con1 = new SqlConnection();
        public cls_Home(IConfiguration configuration)
        {
            _configuration = configuration;
            con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));            
            con1 = new SqlConnection(_configuration.GetConnectionString("SecondConnection"));

        }
        public List<object> getClaims(Claims_properties objp)
        {
            List<object> lst = new List<object>();
            List<Claims_properties> lstClms = new List<Claims_properties>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_CLAIMS", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@CLCL_ID", objp.CLCL_ID);
                cmd.Parameters.AddWithValue("@MB_TYPE", objp.MB_TYPE);
                cmd.Parameters.AddWithValue("@MB_VAL", objp.MB_VAL);
                cmd.Parameters.AddWithValue("@CDML_UMAUTH_ID", objp.CDML_UMAUTH_ID);
                cmd.Parameters.AddWithValue("@CLCL_TYPE", objp.CLCL_TYPE);
                cmd.Parameters.AddWithValue("@DATE_TYPE", objp.DATE_TYPE);
                cmd.Parameters.AddWithValue("@FROM_DT", objp.FROM_DT);
                cmd.Parameters.AddWithValue("@TO_DATE", objp.TO_DATE);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new Claims_properties();
                    objp.CLCL_ID = GetSafeString(dr, dr.GetOrdinal("CLCL_ID"));
                    objp.SBSB_ID = GetSafeString(dr, dr.GetOrdinal("SBSB_ID"));
                    objp.PRPR_NPI = GetSafeString(dr, dr.GetOrdinal("PRPR_NPI"));
                    objp.PRPR_NAME = GetSafeString(dr, dr.GetOrdinal("PRPR_NAME"));
                    objp.CLCL_CL_TYPE = GetSafeString(dr, dr.GetOrdinal("CLCL_CL_TYPE"));
                    objp.CLCL_CUR_STS = GetSafeString(dr, dr.GetOrdinal("CLCL_CUR_STS"));
                    objp.CLCL_LOW_SVC_DT = GetSafeDate(dr, dr.GetOrdinal("CLCL_LOW_SVC_DT"));
                    objp.CLCL_HIGH_SVC_DT = GetSafeDate(dr, dr.GetOrdinal("CLCL_HIGH_SVC_DT"));
                    objp.CLCL_TOT_CHG = GetSafeDecimal(dr, dr.GetOrdinal("CLCL_TOT_CHG"));
                    objp.CLCL_TOT_PAYABLE = GetSafeDecimal(dr, dr.GetOrdinal("CLCL_TOT_PAYABLE"));
                    objp.CKPY_REF_ID = GetSafeString(dr, dr.GetOrdinal("CKPY_REF_ID"));
                    objp.CDML_UMAUTH_ID = GetSafeString(dr, dr.GetOrdinal("AUTHORIZATION_ID"));
                    objp.CLCL_NTWK_IND = GetSafeString(dr, dr.GetOrdinal("CLCL_NTWK_IND"));
                    objp.PLDS_DESC = GetSafeString(dr, dr.GetOrdinal("PLDS_DESC"));
                    objp.CLCL_PAID_DT = GetSafeDate(dr, dr.GetOrdinal("CLCL_PAID_DT"));
                    lstClms.Add(objp);
                }
                dr.Close();

                lst.Add(false);
                lst.Add(lstClms);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }
        public List<object> getClaimsDetails(Claims_properties objp)
        {
            List<object> lst = new List<object>();
            List<Claims_properties> lstClms = new List<Claims_properties>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_CLAIMS_DETAILS", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@CLCL_ID", objp.CLCL_ID);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new Claims_properties();
                    objp.CLCL_ID = GetSafeString(dr, dr.GetOrdinal("CLCL_ID"));
                    objp.PRPR_NPI = GetSafeString(dr, dr.GetOrdinal("PRPR_NPI"));
                    objp.CLCL_LOW_SVC_DT = GetSafeDate(dr, dr.GetOrdinal("CLCL_LOW_SVC_DT"));
                    objp.CLCL_HIGH_SVC_DT = GetSafeDate(dr, dr.GetOrdinal("CLCL_HIGH_SVC_DT"));
                    objp.CLCL_TOT_CHG = GetSafeDecimal(dr, dr.GetOrdinal("CLCL_TOT_CHG"));
                    objp.CLCL_TOT_PAYABLE = GetSafeDecimal(dr, dr.GetOrdinal("CLCL_TOT_PAYABLE"));
                    objp.CDML_UMAUTH_ID = GetSafeString(dr, dr.GetOrdinal("AUTHORIZATION_ID"));
                    objp.IDCD_ID = GetSafeString(dr, dr.GetOrdinal("IDCD_ID"));
                    objp.PSCD_DESC = GetSafeString(dr, dr.GetOrdinal("PSCD_DESC"));
                    objp.SEDS_DESC = GetSafeString(dr, dr.GetOrdinal("SEDS_DESC"));
                    objp.MEMB_LIABILITY = GetSafeDecimal(dr, dr.GetOrdinal("MEMBER_LIABILITY"));
                    objp.UNITS = GetSafeint16(dr, dr.GetOrdinal("UNITS"));
                    lstClms.Add(objp);
                }
                dr.Close();

                lst.Add(false);
                lst.Add(lstClms);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }
        public List<object> getClaimsSrch(int USER_ID)
        {

            List<object> lst = new List<object>();
            List<Claims_properties> lstClms = new List<Claims_properties>();
            try
            {
                Claims_properties objp;
                if (con1.State == ConnectionState.Closed)
                {
                  con1.Open();
                }
                SqlCommand cmd = new SqlCommand("AST_SP_GET_SRCHCLMS", con1);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@USER_ID", USER_ID);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new Claims_properties();
                    objp.SEARCH_ID = GetSafeint(dr, dr.GetOrdinal("SEARCH_ID"));
                    objp.CLCL_ID = GetSafeString(dr, dr.GetOrdinal("CLAIM_ID"));
                    objp.MB_TYPE = GetSafeString(dr, dr.GetOrdinal("MB_TYPE"));
                    objp.MB_VAL = GetSafeString(dr, dr.GetOrdinal("MB_VAL"));
                    objp.CLCL_CL_TYPE = GetSafeString(dr, dr.GetOrdinal("CLAIM_TYPE"));
                    objp.DATE_TYPE = GetSafeString(dr, dr.GetOrdinal("DATE_TYPE"));
                    objp.CDML_UMAUTH_ID = GetSafeString(dr, dr.GetOrdinal("AUTH_ID"));
                    objp.START_DT = GetSafeDate(dr, dr.GetOrdinal("FROM_DT"));
                    objp.END_DT = GetSafeDate(dr, dr.GetOrdinal("END_DT"));
                    lstClms.Add(objp);
                }
                dr.Close();

                lst.Add(false);
                lst.Add(lstClms);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con1.Close();
            }
            finally
            {
                con1.Close();
            }
            return lst;
        }

        public List<object> getMemeSrch(int USER_ID)
        {
            List<object> lst = new List<object>();
            List<Meme_properties> lstmeme = new List<Meme_properties>();
            try
            {
                Meme_properties objp;
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_SRCHMEME", con1);
                cmd.Parameters.AddWithValue("@USER_ID", USER_ID);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new Meme_properties();
                    objp.SEARCH_ID = GetSafeint(dr, dr.GetOrdinal("SEARCH_ID"));
                    objp.SBSB_ID = GetSafeString(dr, dr.GetOrdinal("SBSB_ID"));
                    objp.MEME_REL = GetSafeString(dr, dr.GetOrdinal("MEME_REL"));
                    objp.GRGR_ID = GetSafeString(dr, dr.GetOrdinal("GRGR_ID"));
                    objp.SGSG_ID = GetSafeString(dr, dr.GetOrdinal("SGSG_ID"));
                    objp.FIRST_NAME = GetSafeString(dr, dr.GetOrdinal("FIRST_NAME"));
                    objp.LAST_NAME = GetSafeString(dr, dr.GetOrdinal("LAST_NAME"));
                    objp.GENDER = GetSafeString(dr, dr.GetOrdinal("GENDER"));
                    objp.BIRTH_DT = GetSafeDate(dr, dr.GetOrdinal("BIRTH_DT"));
                    lstmeme.Add(objp);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstmeme);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }

        public List<object> getPRPRSrch(int USER_ID)
        {
            List<object> lst = new List<object>();
            List<PRPR_properties> lstmeme = new List<PRPR_properties>();
            try
            {
                PRPR_properties objp;
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_SRCHPRPR", con1);
                cmd.Parameters.AddWithValue("@USER_ID", USER_ID);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new PRPR_properties();
                    objp.SEARCH_ID = GetSafeint(dr, dr.GetOrdinal("SEARCH_ID"));
                    objp.PRPR_NPI = GetSafeString(dr, dr.GetOrdinal("PRPR_NPI"));
                    objp.PRPR_SPEC = GetSafeString(dr, dr.GetOrdinal("PRPR_SPEC"));
                    objp.NWNW_ID = GetSafeString(dr, dr.GetOrdinal("NWNW_ID"));
                    objp.NWNW_NAME = GetSafeString(dr, dr.GetOrdinal("NWNW_NAME"));
                    objp.FROM_DTs = GetSafeDate(dr, dr.GetOrdinal("FROM_DT"));
                    objp.END_DTs = GetSafeDate(dr, dr.GetOrdinal("END_DT"));
                    objp.PRPR_FLAG = GetSafeString(dr, dr.GetOrdinal("PRPR_FLAG"));
                    lstmeme.Add(objp);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstmeme);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }


        public List<object> getBILLSrch(int USER_ID)
        {
            List<object> lst = new List<object>();
            List<BILL_properties> lstBILL = new List<BILL_properties>();
            try
            {
                BILL_properties objp;
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_SRCHBILL", con1);
                cmd.Parameters.AddWithValue("@USER_ID", USER_ID);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new BILL_properties();
                    objp.SEARCH_ID = GetSafeint(dr, dr.GetOrdinal("SEARCH_ID"));
                    objp.GSM_TYPE = GetSafeString(dr, dr.GetOrdinal("GSM_TYPE"));
                    objp.GSM_VAL = GetSafeString(dr, dr.GetOrdinal("GSM_VAL"));
                    objp.DT_TYPE = GetSafeString(dr, dr.GetOrdinal("DT_TYPE"));
                    objp.ENTITY_TYPE = GetSafeString(dr, dr.GetOrdinal("ENTITY_TYPE"));
                    objp.STRT_DTs = GetSafeDate(dr, dr.GetOrdinal("STRT_DT"));
                    objp.END_DTs = GetSafeDate(dr, dr.GetOrdinal("END_DT"));
                    objp.INVOICE_ID = GetSafeString(dr, dr.GetOrdinal("INVOICE_ID"));
                    lstBILL.Add(objp);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstBILL);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }

        public List<object> getUMSrch(int USER_ID)
        {
            List<object> lst = new List<object>();
            List<UM_properties> lstBILL = new List<UM_properties>();
            try
            {
                UM_properties objp;
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_SRCH_UM", con1);
                cmd.Parameters.AddWithValue("@USER_ID", USER_ID);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new UM_properties();
                    objp.SEARCH_ID = GetSafeint(dr, dr.GetOrdinal("SEARCH_ID"));
                    objp.MEME_ID = GetSafeString(dr, dr.GetOrdinal("MEME_ID"));
                    objp.UM_ID = GetSafeString(dr, dr.GetOrdinal("UM_ID"));
                    objp.START_DTs = GetSafeDate(dr, dr.GetOrdinal("START_DT"));
                    objp.END_DTs = GetSafeDate(dr, dr.GetOrdinal("END_DT"));
                    objp.DTRNG_TYPE = GetSafeString(dr, dr.GetOrdinal("DTRNG_TYPE"));
                    objp.STATUS = GetSafeString(dr, dr.GetOrdinal("STATUS"));
                    objp.UM_TYPE = GetSafeString(dr, dr.GetOrdinal("UM_TYPE"));
                    objp.SRVC_TYPES = GetSafeString(dr, dr.GetOrdinal("SRVC_TYPES"));
                    objp.PRPR_NPI = GetSafeString(dr, dr.GetOrdinal("PRPR_NPI"));
                    objp.REQ_NPI = GetSafeString(dr, dr.GetOrdinal("REQ_NPI"));
                    objp.SRVC_NPI = GetSafeString(dr, dr.GetOrdinal("SRVC_NPI"));
                    lstBILL.Add(objp);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstBILL);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }


        public List<object> getBNFTSrch(int USER_ID)
        {
            List<object> lst = new List<object>();
            List<BNFT_properties> lstBILL = new List<BNFT_properties>();
            try
            {
                BNFT_properties objp;
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_SRCHBENFTS", con1);
                cmd.Parameters.AddWithValue("@USER_ID", USER_ID);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new BNFT_properties();
                    objp.SEARCH_ID = GetSafeint(dr, dr.GetOrdinal("SEARCH_ID"));
                    objp.GRGR_ID = GetSafeString(dr, dr.GetOrdinal("GRGR_ID"));
                    objp.CSPI_ID = GetSafeString(dr, dr.GetOrdinal("CSPI_ID"));
                    objp.PDPD_ID = GetSafeString(dr, dr.GetOrdinal("PDPD_ID"));
                    objp.LOB = GetSafeString(dr, dr.GetOrdinal("LOB"));
                    objp.EFF_FROM_DTs = GetSafeDate(dr, dr.GetOrdinal("EFF_FROM_DT"));
                    objp.EFF_TO_DTs = GetSafeDate(dr, dr.GetOrdinal("EFF_TO_DT"));
                    objp.END_FROM_DTs = GetSafeDate(dr, dr.GetOrdinal("END_FROM_DT"));
                    objp.END_TO_DTs = GetSafeDate(dr, dr.GetOrdinal("END_TO_DT"));
                    lstBILL.Add(objp);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstBILL);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }

        public string insertClaimsSrch(Claims_properties objp)
        {
            List<Claims_properties> lstClms = new List<Claims_properties>();
            string strRes = "";
            try
            {
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_INSERT_SRCH_CLMS", con1);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@CLCL_ID", objp.CLCL_ID);
                cmd.Parameters.AddWithValue("@MB_TYPE", objp.MB_TYPE);
                cmd.Parameters.AddWithValue("@MB_VAL", objp.MB_VAL);
                cmd.Parameters.AddWithValue("@CDML_UMAUTH_ID", objp.CDML_UMAUTH_ID);
                cmd.Parameters.AddWithValue("@CLCL_TYPE", objp.CLCL_TYPE);
                cmd.Parameters.AddWithValue("@DATE_TYPE", objp.DATE_TYPE);
                cmd.Parameters.AddWithValue("@FROM_DT", objp.FROM_DT);
                cmd.Parameters.AddWithValue("@TO_DATE", objp.TO_DATE);
                cmd.Parameters.AddWithValue("@USER_ID", objp.USER_ID);
                int i = cmd.ExecuteNonQuery();
                if (i < 0)
                {
                    strRes = "Failed";
                }
                else
                {
                    strRes = "Success";

                }
            }
            catch (Exception Ex)
            {
                con1.Close();
            }
            finally
            {
                con1.Close();
            }
            return strRes;
        }

        public string insertMemeSrch(Meme_properties objp)
        {
            List<Meme_properties> lstClms = new List<Meme_properties>();
            string strRes = "";
            try
            {
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_INSERT_SRCH_MEME", con1);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@SBSB_ID", objp.SBSB_ID);
                cmd.Parameters.AddWithValue("@MEME_REL", objp.MEME_REL);

                cmd.Parameters.AddWithValue("@GRGR_ID", objp.GRGR_ID);
                cmd.Parameters.AddWithValue("@SGSG_ID", objp.SGSG_ID);
                cmd.Parameters.AddWithValue("@FIRST_NAME", objp.FIRST_NAME);
                cmd.Parameters.AddWithValue("@LAST_NAME", objp.LAST_NAME);
                cmd.Parameters.AddWithValue("@BIRTH_DT", objp.DOB);
                cmd.Parameters.AddWithValue("@GENDER", objp.GENDER);
                cmd.Parameters.AddWithValue("@USER_ID", objp.USER_ID);
                int i = cmd.ExecuteNonQuery();
                if (i < 0)
                {
                    strRes = "Failed";
                }
                else
                {
                    strRes = "Success";

                }
            }
            catch (Exception Ex)
            {
                con1.Close();
            }
            finally
            {
                con1.Close();
            }
            return strRes;
        }

        public string insertPRPRSrch(PRPR_properties objp)
        {
            List<PRPR_properties> lstClms = new List<PRPR_properties>();
            string strRes = "";
            try
            {
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_INSERT_SRCH_PRPR", con1);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@PRPR_NPI", objp.PRPR_NPI);
                cmd.Parameters.AddWithValue("@PRCF_SPEC", objp.PRPR_SPEC);
                cmd.Parameters.AddWithValue("@NWNW_ID", objp.NWNW_ID);
                cmd.Parameters.AddWithValue("@NWNW_NAME", objp.NWNW_NAME);
                cmd.Parameters.AddWithValue("@ST_DT", objp.FROM_DT);
                cmd.Parameters.AddWithValue("@END_DT", objp.END_DT);
                cmd.Parameters.AddWithValue("@FLAG", objp.PRPR_FLAG);
                cmd.Parameters.AddWithValue("@USER_ID", objp.USER_ID);
                int i = cmd.ExecuteNonQuery();
                if (i < 0)
                {
                    strRes = "Failed";
                }
                else
                {
                    strRes = "Success";

                }
            }
            catch (Exception Ex)
            {
                con1.Close();
            }
            finally
            {
                con1.Close();
            }
            return strRes;
        }

        public string insertBILLSrch(BILL_properties objp)
        {
            List<BILL_properties> lstClms = new List<BILL_properties>();
            string strRes = "";
            try
            {
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_INSERT_SRCH_BILL", con1);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@INVOICE_ID", objp.INVOICE_ID);
                cmd.Parameters.AddWithValue("@GSM_TYPE", objp.GSM_TYPE);
                cmd.Parameters.AddWithValue("@GSM_VAL", objp.GSM_VAL);
                cmd.Parameters.AddWithValue("@DT_TYPE", objp.DT_TYPE);
                cmd.Parameters.AddWithValue("@ENTITY_TYPE", objp.ENTITY_TYPE);
                cmd.Parameters.AddWithValue("@STRT_DT", objp.STRT_DT);
                cmd.Parameters.AddWithValue("@END_DT", objp.END_DT);
                cmd.Parameters.AddWithValue("@USER_ID", objp.USER_ID);
                int i = cmd.ExecuteNonQuery();
                if (i < 0)
                {
                    strRes = "Failed";
                }
                else
                {
                    strRes = "Success";

                }
            }
            catch (Exception Ex)
            {
                con1.Close();
            }
            finally
            {
                con1.Close();
            }
            return strRes;
        }


        public string insertUMSrch(UM_properties objp)
        {
            List<UM_properties> lstClms = new List<UM_properties>();
            string strRes = "";
            try
            {
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_INSERT_SRCH_UM", con1);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@MEME_ID", objp.MEME_ID);
                cmd.Parameters.AddWithValue("@UM_ID", objp.UM_ID);
                cmd.Parameters.AddWithValue("@START_DT", objp.START_DT);
                cmd.Parameters.AddWithValue("@END_DT", objp.END_DT);
                cmd.Parameters.AddWithValue("@DTRNG_TYPE", objp.DTRNG_TYPE);
                cmd.Parameters.AddWithValue("@STATUS", objp.STATUS);
                cmd.Parameters.AddWithValue("@UM_TYPE", objp.UM_TYPE);
                cmd.Parameters.AddWithValue("@SRVC_TYPES", objp.SRVC_TYPES);
                cmd.Parameters.AddWithValue("@PRPR_NPI", objp.PRPR_NPI);
                cmd.Parameters.AddWithValue("@REQ_NPI", objp.REQ_NPI);
                cmd.Parameters.AddWithValue("@SRVC_NPI", objp.SRVC_NPI);
                cmd.Parameters.AddWithValue("@USER_ID", objp.USER_ID);
                int i = cmd.ExecuteNonQuery();
                if (i < 0)
                {
                    strRes = "Failed";
                }
                else
                {
                    strRes = "Success";

                }
            }
            catch (Exception Ex)
            {
                con1.Close();
            }
            finally
            {
                con1.Close();
            }
            return strRes;
        }


        public string insertBNFTSrch(BNFT_properties objp)
        {
            List<BNFT_properties> lstClms = new List<BNFT_properties>();
            string strRes = "";
            try
            {
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_INSERT_SRCH_BNFT", con1);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@CSPI_ID", objp.CSPI_ID);
                cmd.Parameters.AddWithValue("@PDPD_ID", objp.PDPD_ID);
                cmd.Parameters.AddWithValue("@LOB", objp.LOB);
                cmd.Parameters.AddWithValue("@EFF_FROM_DT", objp.EFF_FROM_DT);
                cmd.Parameters.AddWithValue("@EFF_TO_DT", objp.EFF_TO_DT);
                cmd.Parameters.AddWithValue("@END_FROM_DT", objp.END_FROM_DT);
                cmd.Parameters.AddWithValue("@END_TO_DT", objp.END_TO_DT);
                cmd.Parameters.AddWithValue("@GRGR_ID", objp.GRGR_ID);
                cmd.Parameters.AddWithValue("@USER_ID", objp.USER_ID);
                int i = cmd.ExecuteNonQuery();
                if (i < 0)
                {
                    strRes = "Failed";
                }
                else
                {
                    strRes = "Success";

                }
            }
            catch (Exception Ex)
            {
                con1.Close();
            }
            finally
            {
                con1.Close();
            }
            return strRes;
        }


        public List<object> getMembers(Meme_properties objp)
        {
            List<object> lst = new List<object>();
            List<Meme_Desc_properties> lstMeme = new List<Meme_Desc_properties>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_MEMBERS", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                if (objp.SBSB_ID == "")
                {
                    cmd.Parameters.AddWithValue("@SBSB_ID", null);
                }
                else {
                    cmd.Parameters.AddWithValue("@SBSB_ID", objp.SBSB_ID);
                }


                if (objp.MEME_REL == "")
                {
                    cmd.Parameters.AddWithValue("@MEME_REL", null);
                }
                else { cmd.Parameters.AddWithValue("@MEME_REL", objp.MEME_REL); }



                if (objp.GRGR_ID == "")
                {
                    cmd.Parameters.AddWithValue("@GRGR_ID", null);
                }
                else { cmd.Parameters.AddWithValue("@GRGR_ID", objp.GRGR_ID); }

                if (objp.SGSG_ID=="") { cmd.Parameters.AddWithValue("@SGSG_ID", null); }
                else { cmd.Parameters.AddWithValue("@SGSG_ID", objp.SGSG_ID); }


                if (objp.FIRST_NAME == "") { cmd.Parameters.AddWithValue("@MEME_FIRST_NAME", null); }
                else { cmd.Parameters.AddWithValue("@MEME_FIRST_NAME", objp.FIRST_NAME); }


                if (objp.LAST_NAME == "") { cmd.Parameters.AddWithValue("@MEME_LAST_NAME", null); }
                else { cmd.Parameters.AddWithValue("@MEME_BIRTH_DT", objp.DOB); }

                if (objp.GENDER == "") { cmd.Parameters.AddWithValue("@MEME_SEX", null); }
                else { cmd.Parameters.AddWithValue("@MEME_SEX", objp.GENDER); }

                SqlDataReader dr = cmd.ExecuteReader();
                Meme_Desc_properties objd;
                while (dr.Read())
                {
                    objd = new Meme_Desc_properties();
                    objd.SBSB_NAME = GetSafeString(dr, dr.GetOrdinal("MEMBER_NAME"));
                    objd.GRGR_ID = GetSafeString(dr, dr.GetOrdinal("GROUP_ID"));
                    objd.GRGR_NAME = GetSafeString(dr, dr.GetOrdinal("GROUP_NAME"));
                    objd.MEME_REL = GetSafeString(dr, dr.GetOrdinal("MEME_REL"));
                    objd.COB = GetSafeString(dr, dr.GetOrdinal("COB"));
                    objd.NET_DUE = GetSafeDecimalM(dr, dr.GetOrdinal("NET_DUE"));
                    objd.LAST_PAY_DT = GetSafeDate(dr, dr.GetOrdinal("LAST_PAYMENT_DT"));
                    objd.MEME_STATUS = GetSafeString(dr, dr.GetOrdinal("MEME_STATUS"));
                    objd.ID_MAILED_DT = GetSafeDate(dr, dr.GetOrdinal("ID_CARD_MAILED_DT"));
                    objd.DELIQUENCY_DT = GetSafeDate(dr, dr.GetOrdinal("DELIQUENCY_DT"));
                    objd.MEME_CK = GetSafeint(dr, dr.GetOrdinal("MEME_CK"));

                    objd.SGSG_CK = GetSafeint(dr, dr.GetOrdinal("SGSG_CK"));
                    objd.SBSB_ID = GetSafeString(dr, dr.GetOrdinal("SBSB_ID"));
                    //objp.POS = GetSafeString(dr, dr.GetOrdinal("POS"));
                    //objp.SERVICE_ID = GetSafeString(dr, dr.GetOrdinal("SERVICE_ID"));
                    lstMeme.Add(objd);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstMeme);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }


        public List<object> getMemberDetails(Meme_Desc_properties objp)
        {
            List<object> lst = new List<object>();
            List<Meme_Desc_properties> lstMems = new List<Meme_Desc_properties>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_MEM_DETAILS", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@MEME_CK", objp.MEME_CK);
                cmd.Parameters.AddWithValue("@SGSG_CK", objp.SGSG_CK);
                cmd.Parameters.AddWithValue("@SBSB_ID", objp.SBSB_ID);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new Meme_Desc_properties();
                    objp.SBSB_NAME = GetSafeString(dr, dr.GetOrdinal("SUBGROUP_NAME"));
                    objp.PLAN_DESC = GetSafeString(dr, dr.GetOrdinal("PLAN_NAME"));
                    objp.CARRIER_NAME = GetSafeString(dr, dr.GetOrdinal("CARRIER_NAME"));
                    objp.COB_EFF_DT = GetSafeDate(dr, dr.GetOrdinal("COB_EFF_DT"));
                    objp.COB_TERM_DT = GetSafeDate(dr, dr.GetOrdinal("COB_TERM_DT"));
                    objp.MEMBER_RELATION = GetSafeString(dr, dr.GetOrdinal("RELATIONSHIP_DESC"));
                    objp.MEMBER_NAME = GetSafeString(dr, dr.GetOrdinal("MEMBER_NAME"));
                    objp.PLAN_EFF_DT = GetSafeDate(dr, dr.GetOrdinal("EFFECTIVE_DT"));
                    objp.PLAN_TERM_DT = GetSafeDate(dr, dr.GetOrdinal("TERM_DT"));
                    objp.MEMBER_DOB = GetSafeDate(dr, dr.GetOrdinal("DOB"));
                    objp.HOME_ADDRESS = GetSafeString(dr, dr.GetOrdinal("HOME_ADDRESS"));
                    objp.PCP_DETAILS = GetSafeString(dr, dr.GetOrdinal("PCP_DETAILS"));
                    lstMems.Add(objp);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstMems);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }


        public List<object> getProviders(PRPR_properties objp)
        {
            List<object> lst = new List<object>();
            List<PRPR_properties> lstPRPR = new List<PRPR_properties>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_PROVIDERS", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@PRPR_NPI", objp.PRPR_NPI);
                cmd.Parameters.AddWithValue("@PRCF_SPEC", objp.PRPR_SPEC);
                cmd.Parameters.AddWithValue("@NWNW_ID", objp.NWNW_ID);
                cmd.Parameters.AddWithValue("@NWNW_NAME", objp.NWNW_NAME);
                cmd.Parameters.AddWithValue("@ST_DT", objp.FROM_DT);
                cmd.Parameters.AddWithValue("@END_DT", objp.END_DT);
                cmd.Parameters.AddWithValue("@FLAG", objp.PRPR_FLAG);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    objp = new PRPR_properties();
                    objp.PRPR_ID = GetSafeString(dr, dr.GetOrdinal("PRPR_ID"));
                    objp.PRPR_NAME = GetSafeString(dr, dr.GetOrdinal("PRPR_NAME"));
                    objp.PRPR_NPI = GetSafeString(dr, dr.GetOrdinal("PRPR_NPI"));
                    objp.PRPR_SPEC = GetSafeString(dr, dr.GetOrdinal("MCTR_DESC"));
                    objp.PRPR_MED_IND = GetSafeString(dr, dr.GetOrdinal("MD_IND"));
                    objp.NWPR_PCP_IND = GetSafeString(dr, dr.GetOrdinal("PCP_IND"));
                    objp.PRPR_ENTITY = GetSafeString(dr, dr.GetOrdinal("PRPR_ENTITY"));
                    objp.BILLING_IND = GetSafeString(dr, dr.GetOrdinal("BILLING_IND"));

                    //objp.POS = GetSafeString(dr, dr.GetOrdinal("POS"));
                    //objp.SERVICE_ID = GetSafeString(dr, dr.GetOrdinal("SERVICE_ID"));
                    lstPRPR.Add(objp);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstPRPR);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }

        public List<object> getProviderDetails(PRPR_properties objp)
        {
            List<object> lst = new List<object>();
            List<PRPR_DESC_properties> lstMems = new List<PRPR_DESC_properties>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_PROVIDER_DESC", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@PRPR_ID", objp.PRPR_ID);
                cmd.Parameters.AddWithValue("@PRPR_ENTITY", objp.PRPR_ENTITY);
                SqlDataReader dr = cmd.ExecuteReader();
                PRPR_DESC_properties objd;
                if (objp.PRPR_ENTITY == "P")
                {
                    while (dr.Read())
                    {
                        objd = new PRPR_DESC_properties();
                        objd.NWNW_ID = GetSafeString(dr, dr.GetOrdinal("NWNW_ID"));
                        objd.NWPR_PCP_IND = GetSafeString(dr, dr.GetOrdinal("NWPR_PCP_IND"));
                        objd.PRPR_STS = GetSafeString(dr, dr.GetOrdinal("PRPR_STS"));
                        objd.NWPR_EFF_DT = GetSafeDate(dr, dr.GetOrdinal("NWPR_EFF_DT"));
                        objd.NWPR_TERM_DT = GetSafeDate(dr, dr.GetOrdinal("NWPR_TERM_DT"));
                        objd.PRCP_ID = GetSafeString(dr, dr.GetOrdinal("PRCP_ID"));
                        objd.ADDRESS = GetSafeString(dr, dr.GetOrdinal("OFFICE_ADDRESS"));
                        objd.PRAD_TYPE_CHECK = GetSafeString(dr, dr.GetOrdinal("PRAD_TYPE_CHECK"));
                        objd.MCTN_ID = GetSafeString(dr, dr.GetOrdinal("MCTN_ID"));
                        objd.PRCR_INIT_CRED_DT = GetSafeDate(dr, dr.GetOrdinal("PRCR_INIT_CRED_DT"));
                        lstMems.Add(objd);
                    }

                }
                else if (objp.PRPR_ENTITY == "G")
                {
                    while (dr.Read())
                    {
                        objd = new PRPR_DESC_properties();
                        objd.PRPR_NAME = GetSafeString(dr, dr.GetOrdinal("PRPR_NAME"));
                        objd.ADDRESS = GetSafeString(dr, dr.GetOrdinal("GROUP_ADDRESS"));
                        objd.MCTN_ID = GetSafeString(dr, dr.GetOrdinal("MCTN_ID"));
                        objd.PRAD_TYPE_CHECK = GetSafeDate(dr, dr.GetOrdinal("PRAD_TYPE_CHECK"));
                        objd.PRPR_NPI = GetSafeDate(dr, dr.GetOrdinal("PRPR_NPI"));
                        objd.NWPR_EFF_DT = GetSafeDate(dr, dr.GetOrdinal("NWPR_EFF_DT"));
                        objd.NWPR_TERM_DT = GetSafeDate(dr, dr.GetOrdinal("NWPR_TERM_DT"));
                        lstMems.Add(objd);
                    }

                }
                else if (objp.PRPR_ENTITY == "F")
                {
                    while (dr.Read())
                    {
                        objd = new PRPR_DESC_properties();
                        objd.NWNW_ID = GetSafeString(dr, dr.GetOrdinal("NWNW_ID"));
                        objd.NWPR_PCP_IND = GetSafeString(dr, dr.GetOrdinal("NWPR_PCP_IND"));
                        objd.PRPR_STS = GetSafeString(dr, dr.GetOrdinal("PRPR_STS"));
                        objd.NWPR_EFF_DT = GetSafeDate(dr, dr.GetOrdinal("NWPR_EFF_DT"));
                        objd.NWPR_TERM_DT = GetSafeDate(dr, dr.GetOrdinal("NWPR_TERM_DT"));
                        objd.ADDRESS = GetSafeString(dr, dr.GetOrdinal("FACILITY_ADDRESS"));
                        objd.NWPR_AUTO_PCP_IND = GetSafeString(dr, dr.GetOrdinal("NWPR_AUTO_PCP_IND"));
                        objd.PRAD_TYPE_CHECK = GetSafeString(dr, dr.GetOrdinal("PRAD_TYPE_CHECK"));
                        objd.MCTN_ID = GetSafeString(dr, dr.GetOrdinal("MCTN_ID"));
                        lstMems.Add(objd);
                    }

                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstMems);
            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }


        public List<object> getBillings(BILL_properties objp)
        {
            List<object> lst = new List<object>();
            List<BILL_DESC_properties> lstPRPR = new List<BILL_DESC_properties>();
            try
            {
                con.Open();
                SqlDataReader dr = null;
                SqlCommand cmd = new SqlCommand();
                BILL_DESC_properties objp1;

                cmd = new SqlCommand("AST_SP_GET_BLBL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                if (objp.INVOICE_ID == "") { cmd.Parameters.AddWithValue("@INVOICE_ID", null); }
                else { cmd.Parameters.AddWithValue("@INVOICE_ID", objp.INVOICE_ID); }

                cmd.Parameters.AddWithValue("@GSM_TYPE", objp.GSM_TYPE);
                cmd.Parameters.AddWithValue("@GSM_VAL", objp.GSM_VAL);
                cmd.Parameters.AddWithValue("@DT_TYPE", objp.DT_TYPE);

                if (objp.ENTITY_TYPE == "") { cmd.Parameters.AddWithValue("@ENTITY_TYPE", null); }
                else if(objp.ENTITY_TYPE == "  ") { cmd.Parameters.AddWithValue("@ENTITY_TYPE", null); }
                else { cmd.Parameters.AddWithValue("@ENTITY_TYPE", objp.ENTITY_TYPE); }
                
                cmd.Parameters.AddWithValue("@STRT_DT", objp.STRT_DT);
                cmd.Parameters.AddWithValue("@END_DT", objp.END_DT);

                dr = cmd.ExecuteReader();
                if (objp.INVOICE_ID == null || objp.INVOICE_ID == "")
                {
                    while (dr.Read())
                    {
                        objp1 = new BILL_DESC_properties();
                        objp1.BLEI_CK = GetSafeint(dr, dr.GetOrdinal("BLEI_CK"));
                        objp1.BLEI_NET_DUE = GetSafeDecimal(dr, dr.GetOrdinal("BLEI_NET_DUE"));
                        objp1.BLBL_DUE_DT = GetSafeDate(dr, dr.GetOrdinal("BLBL_DUE_DT"));
                        objp1.BLEI_LST_PD_DUE_DT = GetSafeDate(dr, dr.GetOrdinal("BLEI_LST_PD_DUE_DT"));
                        objp1.BLEI_LST_BL_DUE_DT = GetSafeDate(dr, dr.GetOrdinal("BLEI_LST_BL_DUE_DT"));
                        objp1.GRGR_ID = GetSafeString(dr, dr.GetOrdinal("GRGR_ID"));
                        objp1.GRGR_NAME = GetSafeString(dr, dr.GetOrdinal("GRGR_NAME"));
                        objp1.SGSG_ID = GetSafeString(dr, dr.GetOrdinal("SGSG_ID"));
                        objp1.SGSG_NAME = GetSafeString(dr, dr.GetOrdinal("SGSG_NAME"));
                        objp1.RCPT_AMT = GetSafeDecimal(dr, dr.GetOrdinal("RCPT_AMT"));
                        objp1.SBSB_ID = GetSafeString(dr, dr.GetOrdinal("SBSB_ID"));
                        objp1.SUSB_NAME = GetSafeString(dr, dr.GetOrdinal("SUSB_NAME"));


                        lstPRPR.Add(objp1);
                    }
                }
                else
                {

                    while (dr.Read())
                    {
                        objp1 = new BILL_DESC_properties();

                        objp1.BLEI_CK = GetSafeint(dr, dr.GetOrdinal("BLEI_CK"));
                        objp1.BLIV_ID = GetSafeString(dr, dr.GetOrdinal("BLIV_ID"));
                        objp1.BLBL_BILLED_AMT = GetSafeDecimal(dr, dr.GetOrdinal("BLBL_BILLED_AMT"));
                        objp1.BLBL_RCVD_AMT = GetSafeDecimal(dr, dr.GetOrdinal("BLBL_RCVD_AMT"));
                        objp1.BLBL_CREATE_DTM = GetSafeDate(dr, dr.GetOrdinal("BLBL_CREATE_DTM"));
                        objp1.BLBL_DUE_DT = GetSafeDate(dr, dr.GetOrdinal("BLBL_DUE_DT"));
                        objp1.RCPT_ID = GetSafeString(dr, dr.GetOrdinal("RCPT_ID"));
                        objp1.GRGR_ID = GetSafeString(dr, dr.GetOrdinal("GRGR_ID"));


                        lstPRPR.Add(objp1);
                    }
                }
                dr.Close();

                lst.Add(false);
                lst.Add(lstPRPR);

            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }


        public List<object> getBillingDetails(BILL_DESC_properties objp)
        {
            List<object> lst = new List<object>();
            List<BILL_DESC_properties> lstbills = new List<BILL_DESC_properties>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_BLBL_DESC", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@BLEI_CK", objp.BLEI_CK);
                cmd.Parameters.AddWithValue("@BLBL_DUE_DT", objp.BLBL_DUE_DT);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new BILL_DESC_properties();
                    objp.PLDS_DESC = GetSafeString(dr, dr.GetOrdinal("PLN"));
                    objp.Lives = GetSafeint(dr, dr.GetOrdinal("Lives"));
                    objp.TotalBreakUp = GetSafeDecimal(dr, dr.GetOrdinal("TotalBreakUp"));
                    objp.INID_OUTSTAND_BAL = GetSafeDecimal(dr, dr.GetOrdinal("AMT"));
                    objp.RCPT_ID = GetSafeString(dr, dr.GetOrdinal("RECEIPT_ID"));
                    objp.RCPT_AMT = GetSafeDecimal(dr, dr.GetOrdinal("RECEIVED_AMT"));
                    objp.BLIV_ID = GetSafeString(dr, dr.GetOrdinal("INVOICE_NUM"));
                    objp.BLBL_DUE_DT = GetSafeDate(dr, dr.GetOrdinal("DUE_DT"));
                    objp.REFUND_DT = GetSafeDate(dr, dr.GetOrdinal("REFUND_DT"));
                    lstbills.Add(objp);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstbills);

            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }

        public List<object> getUM(UM_properties objp)
        {
            List<object> lst = new List<object>();
            List<UM_DESC_properties> lstPRPR = new List<UM_DESC_properties>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_UM", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@UMUM_REF_ID", objp.UM_ID);
                cmd.Parameters.AddWithValue("@SBSB_ID", objp.MEME_ID);
                cmd.Parameters.AddWithValue("@DT_TYPE", objp.DTRNG_TYPE);
                cmd.Parameters.AddWithValue("@FRM_DT", objp.START_DT);
                cmd.Parameters.AddWithValue("@TO_DT", objp.END_DT);
                cmd.Parameters.AddWithValue("@UMVT_STS", objp.STATUS);
                cmd.Parameters.AddWithValue("@SEGR_DESC", objp.SRVC_TYPES);
                cmd.Parameters.AddWithValue("@PRPR_NPI", objp.PRPR_NPI);
                cmd.Parameters.AddWithValue("@SVC_PRPR_NPI", objp.SRVC_NPI);
                cmd.Parameters.AddWithValue("@REQ_PRPR_NPI", objp.REQ_NPI);
                cmd.Parameters.AddWithValue("@UM_TYPE", objp.UM_TYPE);
                UM_DESC_properties objp1;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    objp1 = new UM_DESC_properties();
                    objp1.UMUM_REF_ID = GetSafeString(dr, dr.GetOrdinal("UMUM_REF_ID"));
                    objp1.UMSV_RECD_DT = GetSafeDate(dr, dr.GetOrdinal("UMSV_RECD_DT"));
                    objp1.UMSV_FROM_DT = GetSafeDate(dr, dr.GetOrdinal("UMSV_FROM_DT"));
                    objp1.UMSV_PRPR_ID_REQ = GetSafeString(dr, dr.GetOrdinal("UMSV_PRPR_ID_REQ"));
                    objp1.UMSV_PRPR_ID_SVC = GetSafeString(dr, dr.GetOrdinal("UMSV_PRPR_ID_SVC"));
                    objp1.UMVT_STS = GetSafeString(dr, dr.GetOrdinal("UMVT_STS"));
                    objp1.REF_TYPE = GetSafeString(dr, dr.GetOrdinal("REF_TYPE"));
                    objp1.CLCL_ID = GetSafeString(dr, dr.GetOrdinal("CLCL_ID"));


                    lstPRPR.Add(objp1);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstPRPR);

            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }


        public List<object> getUMDetails(UM_DESC_properties objp)
        {
            List<object> lst = new List<object>();
            List<UM_DESC_properties> lstbills = new List<UM_DESC_properties>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_UM_DESC", con);
                cmd.CommandType = CommandType.StoredProcedure;
                string Ref_ID = objp.UMUM_REF_ID;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@UMUM_REF_ID", Ref_ID);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new UM_DESC_properties();
                    objp.UMUM_REF_ID = Ref_ID;
                    objp.REQUESTED_UNITS = GetSafeint16(dr, dr.GetOrdinal("REQUESTED_UNITS"));
                    objp.AUTHORIZATION_UNITS = GetSafeint16(dr, dr.GetOrdinal("AUTHORIZATION_UNITS"));
                    objp.AUTHORIZATION_DT = GetSafeDate(dr, dr.GetOrdinal("AUTHORIZATION_DT"));
                    objp.PROCEDURE_CODE = GetSafeString(dr, dr.GetOrdinal("PROCEDURE_CODE"));
                    objp.DIAGNOSIS_CODE = GetSafeString(dr, dr.GetOrdinal("DIAGNOSIS_CODE"));
                    objp.SERVICE_TYPE = GetSafeString(dr, dr.GetOrdinal("SERVICE_TYPE"));
                    objp.UM_STATUS = GetSafeString(dr, dr.GetOrdinal("UM_STATUS"));
                    lstbills.Add(objp);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstbills);

            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }

        public List<object> getBenefits(BNFT_properties objp)
        {
            List<object> lst = new List<object>();
            List<BNFT_DESC_properties> lstPRPR = new List<BNFT_DESC_properties>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_BENEFITS", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                if (objp.CSPI_ID == "") { cmd.Parameters.AddWithValue("@CSPI_ID", null); }
                else { cmd.Parameters.AddWithValue("@CSPI_ID", objp.CSPI_ID); }

                if (objp.PDPD_ID=="") { cmd.Parameters.AddWithValue("@PDPD_ID", null); }
                else { cmd.Parameters.AddWithValue("@PDPD_ID", objp.PDPD_ID); }

                if (objp.LOB == "") { cmd.Parameters.AddWithValue("@PDDS_MCTR_BCAT", null); }
                else { cmd.Parameters.AddWithValue("@PDDS_MCTR_BCAT", objp.LOB); }


                if (objp.GRGR_ID == "") { cmd.Parameters.AddWithValue("@GRGR_ID", null); }
                else { cmd.Parameters.AddWithValue("@GRGR_ID", objp.GRGR_ID); }


                cmd.Parameters.AddWithValue("@EFF_FROM_DT", objp.EFF_FROM_DT);
                cmd.Parameters.AddWithValue("@EFF_TO_DT", objp.EFF_TO_DT);
                cmd.Parameters.AddWithValue("@TERM_FROM_DT", objp.END_FROM_DT);
                cmd.Parameters.AddWithValue("@TERM_TO_DT", objp.END_TO_DT);
                
                BNFT_DESC_properties objp1;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    objp1 = new BNFT_DESC_properties();
                    objp1.CSPI_ID = GetSafeString(dr, dr.GetOrdinal("CSPI_ID"));
                    objp1.PDPD_ID = GetSafeString(dr, dr.GetOrdinal("PDPD_ID"));
                    objp1.GRGR_ID = GetSafeString(dr, dr.GetOrdinal("GRGR_ID"));
                    objp1.CSPI_EFF_DT = GetSafeDate(dr, dr.GetOrdinal("CSPI_EFF_DT"));
                    objp1.CSPI_TERM_DT = GetSafeDate(dr, dr.GetOrdinal("CSPI_TERM_DT"));
                    objp1.PLDS_DESC = GetSafeString(dr, dr.GetOrdinal("PLDS_DESC"));
                    objp1.CSPD_CAT = GetSafeString(dr, dr.GetOrdinal("CSPD_CAT"));
                    objp1.PDDS_MCTR_BCAT = GetSafeString(dr, dr.GetOrdinal("PDDS_MCTR_BCAT"));

                    lstPRPR.Add(objp1);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstPRPR);

            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }


        public List<object> getBenefitDetails(BNFT_DESC_properties objp)
        {
            List<object> lst = new List<object>();
            List<BNFT_DESC_properties> lstbills = new List<BNFT_DESC_properties>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_BENFT_DESC", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@PDPD_ID", objp.PDPD_ID);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    objp = new BNFT_DESC_properties();
                    objp.Accumulator_Name = GetSafeString(dr, dr.GetOrdinal("ACDE_DESC"));
                    objp.ACC_AMT1 = GetSafeDecimal(dr, dr.GetOrdinal("LTLT_AMT1"));
                    objp.ACC_AMT2 = GetSafeDecimal(dr, dr.GetOrdinal("LTLT_AMT2"));
                    objp.Benefits_Name = GetSafeString(dr, dr.GetOrdinal("SEDS_DESC"));
                    objp.Pre_Auth_Indicator = GetSafeString(dr, dr.GetOrdinal("SEDF_UM_REQ_IND"));
                    objp.Limits_Applies_to_Service_or_not = GetSafeString(dr, dr.GetOrdinal("SESE_ID"));
                    lstbills.Add(objp);
                }
                dr.Close();
                lst.Add(false);
                lst.Add(lstbills);

            }
            catch (Exception Ex)
            {
                lst.Add(true);
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return lst;
        }



        public string GetSafeDate(SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
                return reader.GetDateTime(colIndex).ToShortDateString();
            else
            {
                return string.Empty;
            }
        }
        public int GetSafeint(SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
                return reader.GetInt32(colIndex);
            else
            {
                return 0;
            }
        }
        public int GetSafeint16(SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
                return reader.GetInt16(colIndex);
            else
            {
                return 0;
            }
        }
        public decimal GetSafeDecimal(SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
                return reader.GetDecimal(colIndex);
            else
            {
                return 0;
            }
        }
        public decimal? GetSafeDecimalM(SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
                return reader.GetDecimal(colIndex);
            else
            {
                return null;
            }
        }
        public string GetSafeString(SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
                return reader.GetString(colIndex);
            else
                return string.Empty;
        }
    }
}
