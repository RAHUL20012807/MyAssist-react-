﻿using my_assist.Models;
using System.Data.SqlClient;
using System.Data;
using System.Reflection.PortableExecutable;
using System.Net.Mail;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;
using Common.Common;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace my_assist.Services
{
    public class cls_User : IUser
    {
        public IUser objdb;
        private IHostingEnvironment _envi;
        private readonly IConfiguration _configuration;
        SqlConnection con;
        SqlConnection con1;
        private bool LastOperation = false;
        private string ErrorMessage;
        public ErrorHandling obj;
        public cls_User(IConfiguration configuration, IHostingEnvironment envi)
        {
            _envi = envi;
            _configuration = configuration;
            obj = new ErrorHandling(_envi);
            con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));
            con1 = new SqlConnection(_configuration.GetConnectionString("SecondConnection"));
        }




        public List<object> checkUser(User_properties objp)
        {
            List<object> lstobj = new List<object>();
            List<Module_properties> lstMod = new List<Module_properties>();
            Module_properties objp1 = new Module_properties();
            try
            {
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_CHECK_USER", con1);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@USER_NAME", objp.StrUsrNme);
                cmd.Parameters.AddWithValue("@PASSWORD", objp.StrPassword);

                SqlCommand cmd1 = new SqlCommand("AST_SP_GET_MODULES", con1);
                cmd1.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd1.Parameters.AddWithValue("@USER_NAME", objp.StrUsrNme);
                cmd1.Parameters.AddWithValue("@PASSWORD", objp.StrPassword);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    objp.UserId = dr.GetInt32(dr.GetOrdinal("USER_ID"));
                    objp.Firstname = GetSafeString(dr, dr.GetOrdinal("FIRST_NAME"));
                    objp.Lastname = GetSafeString(dr, dr.GetOrdinal("LAST_NAME"));
                    objp.StrRole = GetSafeString(dr, dr.GetOrdinal("ROLE_NAME"));
                    objp.StrUsrNme = GetSafeString(dr, dr.GetOrdinal("USER_NAME"));
                    //  objp.StrMsg = GetSafeString(dr, dr.GetOrdinal("MODULE_NAME"));
                }
                dr.Close();
                if (objp.StrRole == null)
                {
                    objp.StrMsg = "Invalid username or password";
                    objp.StrRole = "none";
                    //HttpContext.Current.Session["Islogin"] = false;
                }
                else if (objp.StrRole.Trim() != "")
                {
                    SqlDataReader dr1 = cmd1.ExecuteReader();
                    while (dr1.Read())
                    {
                        objp1 = new Module_properties();
                        objp1.StrModuleName = GetSafeString(dr1, dr1.GetOrdinal("MODULE_NAME"));
                        lstMod.Add(objp1);
                    }
                    dr1.Close();
                    //HttpContext.Current.Session["Islogin"] = true;
                }
            }
            catch (Exception Ex)
            {
                objp.StrMsg = "Something went wrong";
                objp.StrRole = "none";
                //HttpContext.Current.Session["Islogin"] = false;
                con1.Close();
            }
            finally
            {
                con1.Close();
                lstobj.Add(objp);
                lstobj.Add(lstMod);
            }
            return lstobj;
        }




        public string GetSafeString(SqlDataReader reader, int colIndex)
        {
            if (!reader.IsDBNull(colIndex))
                return reader.GetString(colIndex);
            else
                return string.Empty;
        }
        public List<User_properties> getUsers()
        {
            List<User_properties> lstUsres = new List<User_properties>();
            try
            {
                User_properties objp;

                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_USERS", con1);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    objp = new User_properties();
                    objp.UserId = dr.GetInt32(dr.GetOrdinal("USER_ID"));
                    objp.Firstname = GetSafeString(dr, dr.GetOrdinal("FIRST_NAME"));
                    objp.Lastname = GetSafeString(dr, dr.GetOrdinal("LAST_NAME"));
                    objp.StrRole = GetSafeString(dr, dr.GetOrdinal("ROLE_NAME"));
                    objp.StrUsrNme = GetSafeString(dr, dr.GetOrdinal("USER_NAME"));
                    objp.StrPassword = GetSafeString(dr, dr.GetOrdinal("PASSWORD"));
                    lstUsres.Add(objp);
                }
                dr.Close();

            }
            catch (Exception Ex)
            {
                // ErrorHandling obj = new ErrorHandling();
                // obj.GetXmlString(Ex);
                lstUsres = null;
                con1.Close();
            }
            finally
            {

                con1.Close();
            }
            return lstUsres;

        }
        public List<Module_properties> getUserModules(int iUserID)
        {
            List<Module_properties> lstMod = new List<Module_properties>();
            try
            {

                Module_properties objp;
                con1.Open();
                SqlCommand cmd = new SqlCommand("AST_SP_GET_USRMODULES", con1);
                cmd.CommandType = CommandType.StoredProcedure;
                //declaring input parameters.......
                cmd.Parameters.AddWithValue("@USER_ID", iUserID);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    objp = new Module_properties();
                    objp.MODULE_ID = dr.GetInt32(dr.GetOrdinal("MODULE_ID"));
                    objp.StrModuleName = GetSafeString(dr, dr.GetOrdinal("MODULE_NAME"));
                    lstMod.Add(objp);
                }
                dr.Close();

            }
            catch (Exception Ex)
            {
                // ErrorHandling obj = new ErrorHandling();
                // obj.GetXmlString(Ex);
                lstMod = null;
                con1.Close();
            }
            finally
            {

                con1.Close();
            }
            return lstMod;

        }
        public User_properties AddUser(User_properties objp)
        {
            con1.Open();
            SqlTransaction tranUsrMng;
            SqlCommand cmd = new SqlCommand("AST_SP_INSERT_USR", con1);
            SqlCommand cmd1 = new SqlCommand("AST_SP_INSERT_USRMOD", con1);
            tranUsrMng = con1.BeginTransaction();
            try
            {
                cmd.Transaction = tranUsrMng;
                cmd1.Transaction = tranUsrMng;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd1.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FIRST_NAME", objp.Firstname);
                cmd.Parameters.AddWithValue("@LAST_NAME", objp.Lastname);
                cmd.Parameters.AddWithValue("@USER_NAME", objp.StrUsrNme);
                cmd.Parameters.AddWithValue("@PASSWORD", objp.StrPassword);
                cmd.Parameters.AddWithValue("@ROLE_ID", objp.RoleId);
                cmd.Parameters.AddWithValue("@ISACTIVE", objp.IsActive);
                cmd.Parameters.AddWithValue("@ENABLE", objp.Enable);
                cmd.Parameters.Add("@id", SqlDbType.Int);
                cmd.Parameters.Add("@RESULT", SqlDbType.NVarChar,150);
                cmd.Parameters["@id"].Direction = ParameterDirection.Output;
                cmd.Parameters["@RESULT"].Direction = ParameterDirection.Output;
                int i = cmd.ExecuteNonQuery();
                //storing the username in session if unique constraint Fires...for username column in DataBase....
                int UsrId = Convert.ToInt32(cmd.Parameters["@id"].Value);

                if (UsrId >= 0)
                {
                    List<int> lstModuleIds = objp.LstModuleIds;

                    for (int k = 0; k < lstModuleIds.Count; k++)
                    {
                        cmd1.Parameters.AddWithValue("@USER_ID", cmd.Parameters["@id"].Value);
                        cmd1.Parameters.AddWithValue("@MODULE_ID", lstModuleIds[k]);
                        i = cmd1.ExecuteNonQuery();
                        cmd1.Parameters.Clear();
                    }
                    tranUsrMng.Commit();
                }
                else
                {
                    tranUsrMng.Rollback();
                }
                return objp;
            }
            catch (Exception Ex)
            {
                // ErrorHandling obj = new ErrorHandling();
                // obj.GetXmlString(Ex);
                try
                {
                    tranUsrMng.Rollback();
                }
                catch (Exception Ex1)
                {
                    throw new("Something went wrong");
                }
                throw new("Something went wrong");
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con1.Close();
                }

            }
        }
        public User_properties UpdateUser(User_properties objp)
        {

            con1.Open();
            SqlTransaction tranUsrMng;
            SqlCommand cmd = new SqlCommand("AST_SP_UPDATE_USR", con1);
            SqlCommand cmd1 = new SqlCommand("AST_SP_INSERT_USRMOD", con1);
            tranUsrMng = con1.BeginTransaction();
            try
            {
                cmd.Transaction = tranUsrMng;
                cmd1.Transaction = tranUsrMng;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd1.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FIRST_NAME", objp.Firstname);
                cmd.Parameters.AddWithValue("@LAST_NAME", objp.Lastname);
                cmd.Parameters.AddWithValue("@USER_NAME", objp.StrUsrNme);
                cmd.Parameters.AddWithValue("@PASSWORD", objp.StrPassword);
                cmd.Parameters.AddWithValue("@ROLE_ID", objp.RoleId);
                cmd.Parameters.AddWithValue("@USER_ID", objp.UserId);
                cmd.Parameters.AddWithValue("@ISACTIVE", objp.IsActive);
                cmd.Parameters.AddWithValue("@ENABLE", objp.Enable);
                cmd.Parameters.Add("@RESULT", SqlDbType.NVarChar, 150);
                cmd.Parameters["@RESULT"].Direction = ParameterDirection.Output;
                int i = cmd.ExecuteNonQuery();


                List<int> lstModuleIds = objp.LstModuleIds;

                for (int k = 0; k < lstModuleIds.Count; k++)
                {
                    cmd1.Parameters.AddWithValue("@USER_ID", objp.UserId);
                    cmd1.Parameters.AddWithValue("@MODULE_ID", lstModuleIds[k]);
                    i = cmd1.ExecuteNonQuery();
                    cmd1.Parameters.Clear();
                }
                tranUsrMng.Commit();

                return objp;
            }
            catch (Exception Ex)
            {
                // ErrorHandling obj = new ErrorHandling();
                // obj.GetXmlString(Ex);
                try
                {
                    tranUsrMng.Rollback();
                }
                catch (Exception Ex1)
                {
                    throw new("Something went wrong");
                }
                throw new("Something went wrong");
            }
            finally
            {
                if (con1.State == ConnectionState.Open)
                {
                    con1.Close();
                }

            }
        }

        public int UpdateProfile(User_properties objp)
        {

            con1.Open();
            SqlCommand cmd = new SqlCommand("AST_SP_UPDATE_PROFILE", con1);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FIRST_NAME", objp.Firstname);
                cmd.Parameters.AddWithValue("@LAST_NAME", objp.Lastname);
                cmd.Parameters.AddWithValue("@USER_NAME", objp.StrUsrNme);
                cmd.Parameters.AddWithValue("@PASSWORD", objp.StrPassword);
                cmd.Parameters.AddWithValue("@USER_ID", objp.UserId);
                int i = cmd.ExecuteNonQuery();


                return i;
            }
            catch (Exception Ex)
            {
                throw new("Something went wrong");
            }
            finally
            {
                if (con1.State == ConnectionState.Open)
                {
                    con1.Close();
                }

            }
        }
        #region  Login Support Methods
        public User_properties Login(User_properties userLogin, string WebRootPath, ILogger log)
        {
            try
            {
                TokenModel tokenModel = new TokenModel
                {
                    UserId = userLogin.UserId,
                    UserName = userLogin.StrUsrNme,
                    UserRoleId = userLogin.RoleId,
                    UserRoleName = userLogin.StrRole,
                    Email = "",
                    IpAddress = "",
                    TimeZone = "",
                    FirstName = userLogin.Firstname,
                    lastName = userLogin.Lastname
                };
                string tokenString = GenerateJSONWebToken(tokenModel, WebRootPath);

                userLogin.tokenString = tokenString;
                return userLogin;
            }
            catch (Exception ex)
            {
                log.LogError(ex, ex.Message);
                return null;
            }
        }
        private string GenerateJSONWebToken(TokenModel tokenModel, string WebRootPath)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new[] {
                new Claim(JwtRegisteredClaimNames.Sub, tokenModel.UserName),
                new Claim(JwtRegisteredClaimNames.Email, tokenModel.Email),
        new Claim("UserId", tokenModel.UserId.ToString()),
        new Claim("UserName", tokenModel.UserName),
        new Claim("UserRoleId",  tokenModel.UserRoleId.ToString()),
        new Claim("UserRoleName",  tokenModel.UserRoleName),
        new Claim("requestRoot",  WebRootPath)                ,

        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
    };
            var token = new JwtSecurityToken(_configuration["Jwt:Issuer"],
             _configuration["Jwt:Issuer"],
             claims,
             expires: DateTime.Now.AddMinutes(10),
             signingCredentials: credentials);
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        //User_properties IUser.checkUser(User_properties objpro)
        //{
        //    throw new NotImplementedException();
        //}
        #endregion
    }
}
