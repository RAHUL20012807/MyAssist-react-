﻿using my_assist.Models;

namespace my_assist.Services
{
    public interface IUser
    {
       
        User_properties Login(User_properties userLogin, string WebRootPath, ILogger log);
        List<object> checkUser(User_properties objp);
        //User_properties checkUser(User_properties objpro);
        User_properties AddUser(User_properties objp);
        User_properties UpdateUser(User_properties objp);
        List<User_properties> getUsers();
        List<Module_properties> getUserModules(int iUserID);
        int UpdateProfile(User_properties objp);
    }
}
