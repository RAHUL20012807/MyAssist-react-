﻿using my_assist.Models;

namespace my_assist.Services
{
    public interface IHome
    {

        List<object> getClaims(Claims_properties objp);
        List<object> getClaimsDetails(Claims_properties objp);
        List<object> getClaimsSrch(int USER_ID);
        List<object> getMemeSrch(int USER_ID);
        List<object> getMembers(Meme_properties objp);
        List<object> getMemberDetails(Meme_Desc_properties objp);
        List<object> getPRPRSrch(int USER_ID);
        List<object> getProviders(PRPR_properties objp);
        List<object> getProviderDetails(PRPR_properties objp);
        List<object> getBILLSrch(int USER_ID);
        List<object> getBillings(BILL_properties objp);
        List<object> getBillingDetails(BILL_DESC_properties objp);
        List<object> getUMSrch(int USER_ID);
        List<object> getUM(UM_properties objp);
        List<object> getUMDetails(UM_DESC_properties objp);
        List<object> getBNFTSrch(int USER_ID);
        List<object> getBenefits(BNFT_properties objp);
        List<object> getBenefitDetails(BNFT_DESC_properties objp);
        string insertClaimsSrch(Claims_properties objp);
        string insertMemeSrch(Meme_properties objp);
        string insertPRPRSrch(PRPR_properties objp);
        string insertBILLSrch(BILL_properties objp);
        string insertUMSrch(UM_properties objp);
        string insertBNFTSrch(BNFT_properties objp);

    }
}
