﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace Common.Common
{
  
    public class TokenModel
    {
        public long   UserId { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string lastName { get; set; }
        public long UserRoleId { get; set; }
        public string UserRoleName { get; set; }
        public string Email { get; set; }
        public string TimeZone { get; set; }
        public string IpAddress { get; set; }
        public HttpRequest request { get; set; }
        public string requestRoot { get; set; }
        public string AppBaseUrl { get; set; }

    }
}
