﻿using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using my_assist.Services;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using my_assist.Models;
using Microsoft.OpenApi.Any;

namespace my_assist.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Microsoft.AspNetCore.Authorization.Authorize]
    public class HomeController : ControllerBase
    {
        private readonly IHome repository;

        public HomeController(IHome repository)
        {
            this.repository = repository;
        }

        [Route("getClaims")]
        [HttpPost]
        public IActionResult getClaims(Claims_properties objp)
        {
                List<object> lst = repository.getClaims(objp);
            
               if (lst == null)
   
                {
                //return NotFound("something went wrong");
                return StatusCode((int)HttpStatusCode.NotFound, "something went wrong");
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.OK,lst);
                }
           
        }


        [Route("getClaimsDetailDesc")]
        [HttpPost]
        public IActionResult getClaimsDetails(Claims_properties objp)
        {
         
                List<object> lst = repository.getClaimsDetails(objp);
                if (lst== null)
                {
                 return(StatusCode((int)HttpStatusCode.NotFound, "something went wrong"));
                }
                else
                {
                    //return Ok(lst);
                return StatusCode((int)HttpStatusCode.OK, lst);
            }
            
        }





        [Route("getClaimsSrch/{USER_ID}")]
        [HttpGet]
        public IActionResult getClaimsSrch(int USER_ID)
        {
                List<object> lst = repository.getClaimsSrch(USER_ID);
                if (lst == null)
                {
                    return NotFound("something went wrong");

                }
                else
                {
                    return Ok(lst);
                }
           
        }


        [Route("getMemeSrch/{USER_ID}")]
        [HttpGet]
        public IActionResult getMemeSrch(int USER_ID)
        {
                List<object> lst = repository.getMemeSrch(USER_ID);
                if (lst == null)
                {
                    return NotFound("something went wrong");
                }
                else
                {
                    return Ok(lst);
                }
            
        }

        [Route("getPRPRSrch/{USER_ID}")]
        [HttpGet]
        public IActionResult getPRPRSrch(int USER_ID)
        {
            
                List<object> lst = repository.getPRPRSrch(USER_ID);
                if (lst == null)
                {
                    return NotFound( "something went wrong");
                }
                else
                {
                    return Ok(lst);
                }
        }



        [Route("getBILLSrch/{USER_ID}")]
        [HttpGet]
        public IActionResult getBILLSrch(int USER_ID)
        {
                List<object> lst = repository.getBILLSrch(USER_ID);
                if (lst == null)
                {
                    return NotFound("something went wrong");
                }
                else
                {
                    return Ok(lst);
                }
         }

        [Route("getUMSrch/{USER_ID}")]
        [HttpGet]
        public IActionResult getUMSrch(int USER_ID)
        {
                List<object> lst = repository.getUMSrch(USER_ID);
                if (lst == null)
                {
                    return NotFound("something went wrong");
                }
                else
                {
                    return Ok(lst);
                }
        }

        [Route("getBNFTSrch/{USER_ID}")]
        [HttpGet]
        public IActionResult getBNFTSrch(int USER_ID)
        {
            
                List<object> lst = repository.getBNFTSrch(USER_ID);
                if (lst == null)
                {
                    return NotFound( "something went wrong");
                }
                else
                {
                    return Ok(lst);
                }
            
        }

        [Route("insertClaimsSrch")]
        [HttpPut]
        public IActionResult insertClaimsSrch(Claims_properties objp)
        {
            
                string res = repository.insertClaimsSrch(objp);
                if (res == "Failed")
                {
                    return NotFound(res);
                }
                else
                {
                    return Ok(res);
                }
           
        }

        [Route("insertMemeSrch")]
        [HttpPut]
        public IActionResult insertMemeSrch(Meme_properties objp)
        {
          

                string res = repository.insertMemeSrch(objp);
                if (res == "Failed")
                {
                    return NotFound( res);
                }
                else
                {
                    return Ok(res);
                }
          
        }

        [Route("insertPRPRSrch")]
        [HttpPut]
        public IActionResult insertPRPRSrch(PRPR_properties objp)
        {
           

                string res = repository.insertPRPRSrch(objp);
                if (res == "Failed")
                {
                    return NotFound(res);
                }
                else
                {
                    return Ok(res);
                }
           
        }

        [Route("insertBILLSrch")]
        [HttpPut]
        public IActionResult insertBILLSrch(BILL_properties objp)
        {
            
                string res = repository.insertBILLSrch(objp);
                if (res == "Failed")
                {
                    return NotFound( res);
                }
                else
                {
                    return Ok (res);
                }
          
        }

        [Route("insertUMSrch")]
        [HttpPut]
        public IActionResult insertUMSrch(UM_properties objp)
        {
            

                string res = repository.insertUMSrch(objp);
                if (res == "Failed")
                {
                    return NotFound (res);
                }
                else
                {
                    return Ok (res);
                }
           
        }

        [Route("insertBNFTSrch")]
        [HttpPut]
        public IActionResult insertBNFTSrch(BNFT_properties objp)
        {
           
                string res = repository.insertBNFTSrch(objp);
                if (res == "Failed")
                {
                    return NotFound( res);
                }
                else
                {
                    return Ok (res);
                }
          
        }


        [Route("getMembers")]
        [HttpPost]
        public IActionResult getMembers(Meme_properties objp)
        {
          
                List<object> lst = repository.getMembers(objp);
                if (lst == null)
                {
                    return NotFound( "something went wrong");
                }
                else
                {
                    return Ok (lst);
                }
           
        }

        [Route("getMemberDetailDesc")]
        [HttpPost]
        public IActionResult getMemberDetails(Meme_Desc_properties objp)
        {
          

                List<object> lst = repository.getMemberDetails(objp);
                if (lst == null)
                {
                    return NotFound( "something went wrong");
                }
                else
                {
                    return Ok (lst);
                }
           
        }


        [Route("getProviders")]
        [HttpPost]
        public IActionResult getProviders(PRPR_properties objp)
        {
           

                List<object> lst = repository.getProviders(objp);
                if (lst == null)
                {
                    return NotFound( "something went wrong");
                }
                else
                {
                    return Ok( lst);
                }
            
        }

        [Route("getProviderDetailDesc")]
        [HttpPost]
        public IActionResult getProviderDetails(PRPR_properties objp)
        {
            
                List<object> lst = repository.getProviderDetails(objp);
                if (lst == null)
                {
                    return NotFound ("something went wrong");
                }
                else
                {
                    return Ok (lst);
                }
          
        }

        [Route("getBillings")]
        [HttpPost]
        public IActionResult getBillings(BILL_properties objp)
        {
           

                List<object> lst = repository.getBillings(objp);
                if (lst == null)
                {
                    return NotFound ("something went wrong");
                }
                else
                {
                    return Ok (lst);
                }
           
        }

        [Route("getBillingDetailDesc")]
        [HttpPost]
        public IActionResult getBillingDetails(BILL_DESC_properties objp)
        {
            
                List<object> lst = repository.getBillingDetails(objp);
                if (lst == null)
                {
                    return NotFound( "something went wrong");
                }
                else
                {
                    return Ok (lst);
                }
            
        }

        [Route("getUM")]
        [HttpPost]
        public IActionResult getUM(UM_properties objp)
        {


            List<object> lst = repository.getUM(objp);
            if (lst == null)
            {
                return NotFound("something went wrong");
            }
            else
            {
                return Ok(lst);
            }
        }


        [Route("getUMDetailDesc")]
        [HttpPost]
        public IActionResult getUMDetails(UM_DESC_properties objp)
        {
            
                List<object> lst = repository.getUMDetails(objp);
                if (lst == null)
                {
                    return NotFound( "something went wrong");
                }
                else
                {
                    return Ok (lst);
                }
            
        }

        [Route("getBenefits")]
        [HttpPost]
        public IActionResult getBenefits(BNFT_properties objp)
        {
            

                List<object> lst = repository.getBenefits(objp);
                if (lst == null)
                {
                    return NotFound ("something went wrong");
                }
                else
                {
                    return Ok (lst);
                }
            
        }

        [Route("getBenefitDetailDesc")]
        [HttpPost]
        public IActionResult getBenefitDetails(BNFT_DESC_properties objp)
        {
            

                List<object> lst = repository.getBenefitDetails(objp);
                if (lst == null)
                {
                    return NotFound ("something went wrong");
                }
                else
                {
                    return Ok (lst);
                }
            
        }
    }
}
    

