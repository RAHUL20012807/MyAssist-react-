﻿using System.Collections.Generic;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using my_assist.Models;
using my_assist.Services;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace my_assist.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Microsoft.AspNetCore.Authorization.Authorize]
    public class UserController : ControllerBase
    {

        private readonly IUser _repository;
        IHostingEnvironment _hostingEnvironment;
        private readonly ILogger _logger;
        public UserController(IUser repository, IHostingEnvironment hostingEnvironment, ILogger<UserController> logger)
        {
            this._repository = repository;
            this._hostingEnvironment = hostingEnvironment;
            this._logger = logger;

        }




        [HttpPost("Login")]
        [Microsoft.AspNetCore.Authorization.AllowAnonymous]
        public IActionResult Login([FromBody] User_Login userLogin)
        {
            User_properties pros = new User_properties()
            {
                StrPassword = userLogin.password,
                StrUsrNme = userLogin.userName
            };
            //User_properties prop = _repository.checkUser(pros);
            List<object> result = _repository.checkUser(pros);

            User_properties prop = result[0] as User_properties; 
            List<Module_properties> modules = result[1] as List<Module_properties>;
           // if (prop.StrRole == null)
                if (prop.StrRole == "none")
                {
                return StatusCode((int)HttpStatusCode.BadRequest, "Login Failed");
            }
            else
            {
                User_properties props = _repository.Login(prop, _hostingEnvironment.WebRootPath + "/", _logger);
                List<Module_properties> module = _repository.getUserModules(prop.UserId);
                List<object> p=new List<object>();
                p.Add(props);
                p.Add(module); 
                return StatusCode((int)HttpStatusCode.OK, p);
            }

        }

        [Route("get_Users")]
        [HttpPost]
        public IActionResult GetUsers()
        {
            
                List<User_properties> users = _repository.getUsers();
                if (users == null)
                {
                    return NotFound ("something went wrong");
                }
                else
                {
                    return Ok (users);
                }
          
        }

        [Route("get_UserModules/{iUserID}")]
        [HttpGet]
        public IActionResult GetUserModules(int iUserID)
        {
            
                List<Module_properties> users = _repository.getUserModules(iUserID);
                if (users == null)
                {
                    return NotFound ("something went wrong");
                }
                else
                {
                    return Ok (users);
                }
           
        }

       


        [Route("Add_User")]
        [HttpPost]
        public IActionResult AddUser(User_properties objp)
        {
            
                User_properties user = _repository.AddUser(objp);
                if (user == null)
                {
                    return NotFound ("something went wrong");
                }
                else
                {
                    return Ok (user);
                }
           
        }

        [Route("Update_User")]
        [HttpPost]
        public IActionResult UpdateUser(User_properties objp)
        {
            
                User_properties user = _repository.UpdateUser(objp);
                if (user == null)
                {
                    return NotFound ("something went wrong");
                }
                else
                {
                    return Ok (user);
                }
            
        }

        [Route("Update_Profile")]
        [HttpPost]
        public IActionResult UpdateProfile(User_properties objp)
        {
            
                int res = _repository.UpdateProfile(objp);
                if (res < 0)
                {
                    return NotFound ("something went wrong");
                }
                else
                {
                    return Ok ("Success");
                }
            
        }

    }
}
