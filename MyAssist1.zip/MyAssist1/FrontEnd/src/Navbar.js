
import React, { useEffect, useState } from "react"; // Import useState
import { Outlet, Navigate, NavLink, Route, useLocation } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import Dropdown from "react-bootstrap/Dropdown";
import DropdownButton from "react-bootstrap/DropdownButton";
import "primeicons/primeicons.css";
import { useNavigate } from "react-router-dom";
import logo from "./symbol Logo.png"


function Navbar() {
  const navigate = useNavigate();
  const location = useLocation(); 
  const [showSidebar, setShowSidebar] = useState(true); 



  const data=JSON.parse(sessionStorage.getItem('UserModule'));
  console.log(data);
  const moduleIds = data.map((item) => item.modulE_ID);
  console.log(moduleIds.includes(1));

  useEffect (()=>{
    if(window.location.pathname==="/nav/MyProfile" ){
      setShowSidebar(false); 
    }
    else if(window.location.pathname==="/nav/UserManagement" ){
      setShowSidebar(false); 
    }
    else{
      setShowSidebar(true);
    }
    // if(window.location.pathname==="/nav"){
    //  var d= document.getElementById("1");
    //  d.setAttribute("className","link-active")
    // }
    }, [window.location.pathname]);



  return (
    <div>
      <div>
      <nav className="navbar sticky-top navbar-dark bg-info navTop" style={{height:"65px"}}>
         <a class="navbar-brand "  style={{marginLeft:50,cursor:"pointer"}} onClick={()=>navigate("/nav")} >
         
        <h2 style={{color:"white"}}>My Assist</h2>
        </a>
        <div className="mb-2" style={{ marginRight: 30, backgroundColor: "rgba(13,202,240)" }}>
          <DropdownButton
            id={`dropdown-button-drop-start`}
            variant="secondary"
            title={<i className="pi pi-cog" style={{ fontSize: "2rem",backgroundColor:"rgba(13,202,240)" }}></i>}
            style={{backgroundColor:"rgba(13,202,240)"}}>
            <Dropdown.Item eventKey="1" onClick={() =>{  navigate("MyProfile")}}>
              My Profile
            </Dropdown.Item>
            <Dropdown.Item eventKey="2" onClick={()=>{navigate("UserManagement")}}>User Management</Dropdown.Item>
            <Dropdown.Item eventKey="3" onClick={()=>{navigate("/"); sessionStorage.clear()}}> Logout</Dropdown.Item>
          </DropdownButton>
        </div>
      </nav>

     
      {showSidebar && (
        <nav className="sidenav">
          <ul>
          {moduleIds.includes(1) && <li >
        <NavLink
        id="1"
        to="/nav/claim"
        className={({ isActive}) => (isActive || window.location.pathname==="/nav" ? "link-active" : "link")} 
      >
        <span className="clickable-area"></span>
        Claim
      </NavLink></li>}

      {moduleIds.includes(2) && <li>
      <NavLink
      id="2"
        to="/nav/member"
        className={({ isActive }) => (isActive ? "link-active" : "link")}
      >
        Member
      </NavLink></li>}

      {moduleIds.includes(3) && <li>
      <NavLink
      id="3"
        to="/nav/provider"
        className={({ isActive }) => (isActive ? "link-active" : "link")}
      >
        Provider
      </NavLink></li>}
      
      {moduleIds.includes(4) && <li>
      <NavLink
      id="4"
        to="/nav/billing"
        className={({ isActive }) => (isActive ? "link-active" : "link")}
      >
        Billing
      </NavLink></li>}


      {moduleIds.includes(5) && <li>
      <NavLink
      id="5"
        to="/nav/um"
        className={({ isActive }) => (isActive ? "link-active" : "link")}
      >
        UM
      </NavLink></li>}

      {moduleIds.includes(6) && <li>
      <NavLink
      id="6"
        to="/nav/benifits"
        className={({ isActive }) => (isActive ? "link-active" : "link")}
      >
        Benifits
      </NavLink></li>}

      {moduleIds.includes(7) && <li>
      <NavLink
      id="7"
        to="/nav/sales"
        className={({ isActive }) => (isActive ? "link-active" : "link")}
      >
        Sales & Marketing
      </NavLink></li>}
          </ul>
        </nav>
      )}


      <Outlet />
      <footer className="footer">
    &copy; 2023 Your Company. All rights reserved.
  </footer>
      </div>
     
    </div>
  );
}

export default Navbar;
