import React, { useState } from "react";
import invoke from "../../api";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';


function ProviderSearch(props){

    console.log(props.data);
    var PRPRDetails=props.data;


    const [onclickPrpr, setOnclickPrpr]=useState(null);
    const [visible, setVisible] = useState(false);
    const [onclickview, setonClickView]=useState([]);
    const [visible1, setVisible1] = useState(false);

    const footerContent = (
        <div>
            
            <Button label="close"  onClick={() =>{ setVisible(false); setonClickView([])}} autoFocus />
        </div> )
  
  const paginatorLeft = <Button type="button" icon="pi pi-refresh" text />;
  const paginatorRight = <Button type="button" icon="pi pi-download" text />;


    return(
        <div className="MainArea">
        <div className="content">
          <div className="row">
                          <h4 className="col">Search Results</h4>
                          <div className="col">
                          <button className="btn btn-primary" onClick={()=>props.sendToParent("Form_page")}  style={{float:"right"}}> Back</button></div>
                          </div>
      
      <div className="card">
                  <DataTable value={PRPRDetails} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                          selectionMode="single" dataKey="searcH_ID" metaKeySelection={false}>
                      <Column field="prpR_NPI" header="Provider Id" body={row => <button style={{border:"1px white solid", backgroundColor:"white"}}onClick={() =>{
                            
                            var payload ={
                              "useR_ID": sessionStorage.getItem("UserId"),
                              "searcH_ID": 0,
                              "prpR_NPI": "",
                              "prpR_ID": row.prpR_ID,
                              "prpR_NAME": "",
                              "prpR_SPEC": "",
                              "prpR_MED_IND": "",
                              "nwpR_PCP_IND": "",
                              "billinG_IND": "",
                              "prpR_ENTITY": row.prpR_ENTITY,
                              "nwnW_ID": "",
                              "nwnW_NAME": "",
                              "prpR_FLAG": "",
                              "froM_DT": null,
                              "enD_DT": null,
                              "froM_DTs": "",
                              "enD_DTs": ""
                            
                            }
                            
                            invoke("api/home/getProviderDetailDesc", "post", (data, success, status) => {
                              if (success) {
                                if(status===200){
                               setOnclickPrpr(data[1]);
                                setVisible(true);
                            
                                }
                              } 
                            },payload);
      
                            }} >{row.prpR_ID}</button>}></Column>
                      <Column field="prpR_NAME" header="Provider Name" ></Column> 
                      <Column field="prpR_NPI" header="Provider NPI" ></Column>
                      <Column field="prpR_SPEC" header="Provider Specility" ></Column>
                      <Column  header="Medicare Assignment Indicator"  body={(rowData) => getIndicator(rowData.prpR_MED_IND)}></Column>
                      <Column  header="PCP Indicator" body={(rowData) => getIndicator(rowData.nwpR_PCP_IND)}></Column>
                      <Column field="billinG_IND" header="Billing Indicator" ></Column>
                      
                  </DataTable>
              </div>
      
          </div>
          {visible &&
            <div className="content"> 
            <h4>Detail Description</h4>

<DataTable value={onclickPrpr} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                   selectionMode="single"  dataKey="searcH_ID" metaKeySelection={false}>
               <Column  body={()=>"Practioner"} header="Provider Type"></Column>
               <Column field="nwnW_ID" header="Network Id" ></Column>
               <Column body={(row)=>getIndicator(row.nwpR_PCP_IND)} header="PCP Indicator" ></Column>
               <Column body={(row)=>PAR_Ind (row.prpR_STS)} header="PAR Indicator" ></Column>
               <Column field="nwpR_EFF_DT" header="Start Date" ></Column>
               <Column field="nwpR_TERM_DT" header="End Date" ></Column>
               <Column  header="View Details" body={row => <button className="btn btn-primary" onClick={()=>{setVisible1(true); var viewlist=[row]; setonClickView(viewlist)}}>view</button>} ></Column> 
           </DataTable>



             <Dialog header="Provider Details" visible={visible1} position={"top"} style={{ width: '80vw' }} onHide={() => setVisible1(false)} footer={footerContent} draggable={false} resizable={true}>
                      
                      {onclickview.map((i) => (
                        <table style={{width:"100%"}}>
                        <tr className="row" style={{height:50}}>
                          <th className="col">Network Id</th>
                          <td className="col">:{i.nwnW_ID}</td>
                          <th className="col">PCP Indicator</th>
                          <td className="col">: {getIndicator(i.nwpR_PCP_IND)}  </td>                  
                        </tr>
                        <tr className="row" style={{height:50}}>
                          <th className="col">PAR Indicator</th>
                          <td className="col">:{PAR_Ind(i.prpR_STS)}</td>
                          <th className="col">Start Date</th>
                          <td className="col">:{i.nwpR_EFF_DT}</td>
                        </tr>
                        <tr className="row" style={{height:50}}>
                          <th className="col">End Date</th>
                          <td className="col">:{i.nwpR_TERM_DT}</td>
                          <th className="col">Common Practioner Id</th>
                          <td className="col">:{i.prcP_ID}</td>
                        </tr>
                        <tr className="row" style={{height:50}} >
                          <th className="col">Office Address</th>
                          <td className="col">:{i.address}</td>
                          <th className="col">Remittance Address</th>
                          <td className="col">:{i.praD_TYPE_CHECK}</td>
                        </tr>
                      
                        <tr className="row" style={{height:50}}>
                          <th className="col">Tax Id</th>
                          <td className="col">:{i.mctN_ID}</td>
                          <th className="col">Credentials Date</th>
                          <td className="col">:{i.prcR_INIT_CRED_DT}</td>
                        </tr>
                        
                        
                        </table>
                         ))} 
                      
                  </Dialog>
              </div>
              }
          </div>
    )

}



function getIndicator(indicator){
    if(indicator==="N"){
      return("NO")
    }
    else if("Y"){
      return("YES")
    }
  }
  
  function PAR_Ind (value){
    if (value === 'PA') {
      return('Participating Provider');
  } else if (value === 'NP') {
       return('Non-Participating Provider');
  } else if (value === 'NR') {
      return ('Non-Reportable Provider');
  } else if (value === 'PX') {
      return( 'Proxy Provider for ITS');
  } else if (value === 'DM') {
      return ( 'Mock PCP for ITS');
  } else if (value=== 'NL') {
      return ('Non-Licensed Provider');
  } else if (value === 'NO') {
      return( 'None');
  }
  }


export default ProviderSearch;