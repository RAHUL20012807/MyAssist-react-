import React, { useState,useEffect, useRef} from "react";
import { Radio } from 'antd';
import {useNavigate} from "react-router-dom"
import invoke from "../../api";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import ProviderSearch from "./ProviderSearch";
import { useFormik } from "formik";
import { Toast } from "primereact/toast";

function Provider(){
  const navigate = useNavigate();

 
  const [Page,setPage] = useState("Form_page");
  const [selected, setselected] = useState(null); 
  const [providerDetails, setProviderDetails] =useState(null);

   
  var [li,setli]=useState([]);

  const [errmsg, seterrmg]= useState("");
  const toast = useRef(null);
   
    var id=sessionStorage.getItem("UserId");
    useEffect(() => {
      invoke("api/home/getPRPRSrch/"+id, "get", (data, success, status) => {
        if (success) {
          if (status === 200) {
            console.log(data[1])
            var lst=return_data(data)
            setli(lst)
          }
        } 
      })
    }, []);
    

useEffect(() => {
  if (selected) {
    formik.setFieldValue("message",selected.prpR_NPI);
    formik.setFieldValue("providerSpec",selected.prpR_SPEC);
    formik.setFieldValue("nwkName",selected.nwnW_ID);
    formik.setFieldValue("nwkId",selected.nwnW_NAME);
    formik.setFieldValue("FrDt",selected.froM_DT);
    formik.setFieldValue("endDt",selected.enD_DT);
    formik.setFieldValue("value",selected.prpR_FLAG);
  }
  
}, [selected]);




//------------------------------------
const formik = useFormik({
  initialValues: {
    message:'',
    providerSpec:'',
    nwkId:'',
    nwkName:'',
    FrDt:null,
    endDt:null,
    value:""
  },
  onSubmit: (values) => {
    if(values.message==="" && values.providerSpec==="" && values.nwkId==="" && values.nwkName==="" && values.FrDt===null && values.endDt===null && values.value===""){
      seterrmg("Please enter the values");
      toast.current.show({ severity: "error", summary: "Error", detail:"Please enter the values", life: 3000 });
    }
    else if (values.message !== "") {
      srch();
    }
    else {
      if ((values.providerSpec !== "")) {
        if ((values.nwkId === "")  || (values.FrDt === "") ) {
          seterrmg( "Please enter Network ID and Date range values");
          toast.current.show({ severity: "error", summary: "Error", detail:"Please enter Network ID and Date range values", life: 3000 });
         }
      }
      else if (((values.nwkId !== "") || (values.nwkName !== "") || (values.value !== ""))) {
        if ((values.FrDt === null) || (values.endDt === null)) {
            seterrmg("Please enter Date range values");
          toast.current.show({ severity: "error", summary: "Error", detail:"Please enter Date range values", life: 3000 });
        }
      }
      if ((values.FrDt !== null) && (values.endDt !== null)) {

            var res = dateDiffInDays(values.FrDt, values.endDt);
            if (res === "F") {
                seterrmg("Date range must be maximum of one year");
                toast.current.show({ severity: "error", summary: "Error", detail:"Date range must be maximum of one year", life: 3000 });

            } else if (res === "G") {
                seterrmg("Start date must be greater than end date");
                toast.current.show({ severity: "error", summary: "Error", detail:"Start date must be greater than end date", life: 3000 });
            }
        
    }else if ((values.FrDt === null) && (values.endDt !== null)) {
        
        seterrmg("Please enter both date range values");
        toast.current.show({ severity: "error", summary: "Error", detail:"Please enter both date range values", life: 3000 });
    }else if ((values.FrDt !== null) && (values.endDt === null)) {
        seterrmg("Please enter both date range values");
        toast.current.show({ severity: "error", summary: "Error", detail:"Please enter both date range values", life: 3000 });
    }
 
    }
    
    function srch(){
      var val={
        "useR_ID": sessionStorage.getItem("UserId"),
        "searcH_ID": 0,
        "prpR_NPI":values.message,
        "prpR_ID": "",
        "prpR_NAME": "",
        "prpR_SPEC":values.providerSpec,
        "prpR_MED_IND": "",
        "nwpR_PCP_IND": "",
        "billinG_IND": "",
        "prpR_ENTITY": "",
        "nwnW_ID":values.nwkId,
        "nwnW_NAME": values.nwkName,
        "prpR_FLAG": values.value,
        "froM_DT": values.FrDt,
        "enD_DT": values.endDt,
        "froM_DTs": "",
        "enD_DTs": ""
  }


    invoke(
      "api/Home/getProviders",
      "post",
      (data, success, status) => {
        if (success) {
          if (status === 200) {
            if(data[1].length>0){
              console.log(data[1]);
              setProviderDetails(data[1]);
              
              invoke("api/home/insertPRPRSrch", "put", (data, success, status) => {
                if (success) { 
                 console.log("done");
                } 
              },val);
              
              var UpdatedList=[val,...li]
                      setli(UpdatedList)
              setPage("Details_Page");
            } 
            else{
              seterrmg("Data Not Found");
            } 
          }
        }
      }
      , val)
    }
  }
})

useEffect(()=>{
  if(formik.values.message.length>0){
    formik.setFieldValue("providerSpec","");
    formik.setFieldValue("nwkName","");
    formik.setFieldValue("nwkId","");
    formik.setFieldValue("FrDt",null);
    formik.setFieldValue("endDt",null);
    formik.setFieldValue("value","");
  }
},[formik.values.message])


  const getChildData=(val) =>{
    console.log(val)
    setPage(val);
  }


if(Page==="Form_page"){
    return(
        <div className="MainArea">
            <div className="content">
            <Toast ref={toast} />
              <form noValidate className="form  form-multiline" onSubmit={formik.handleSubmit}>
                
    <div className="row">
        <div className="form-group col">
        <label className="control-label ">Provider NPI</label>
        <input type="text" className="form-control " id="message" name="message" placeholder="Provider_NPI" value={formik.values.message} onChange={formik.handleChange}></input>

        </div>


        <div className="form-group col">
        <label className="control-label ">Provider Speciality</label>
        <input type="text" className="form-control " id="providerSpec" name="providerSpec" placeholder="Provider Speciality" value={formik.values.providerSpec} onChange={formik.handleChange} disabled={formik.values.message.length>0?true:false}></input>

        </div>

        <div className="form-group col">
        <label className="control-label ">Network Id</label>
        <input type="text" className="form-control " id="nwkId" name="nwkId" placeholder="Neteork id" value={formik.values.nwkId} onChange={formik.handleChange} disabled={formik.values.message.length>0?true:false}></input>
        </div>
        </div>


        <div className="row">  
        <div className="form-group col-lg-4">
        <label className="control-label ">Network Set Name</label>
        <input type="text" className="form-control " id="nwkName" name="nwkName" placeholder="Network Set Name" value={formik.values.nwkName}  onChange={formik.handleChange} disabled={formik.values.message.length>0?true:false}></input>
        </div>

        <div className="form-group col-lg-8" >
        <div>
    <label className="control-label "  style={{}}>Date Range</label>
        </div>
            <div class="row"style={{float:"left", textAlign:"left", width:"104%"}}>
            <input type="date" className="form-control inp_text col" style={{marginLeft:12,marginRight:0, width:"70%"}} value={formik.values.FrDt} onChange={formik.handleChange} id="FrDt" name="FrDt" disabled={formik.values.message.length>0?true:false}/>
            <div className="col-auto" style={{paddingTop:5,paddingRight:5,paddingLeft:5}}>to</div> 
            <input type="date" className="form-control inp_text col"  value={formik.values.endDt} onChange={formik.handleChange} id="endDt" name="endDt" disabled={formik.values.message.length>0?true:false}/>
            </div>
           </div>


        <div className="card flex col-lg-3" style={{marginTop:38,marginRight:30,padding:5,paddingTop:7, height:38, marginLeft:15, width:"39%"}}>
                <Radio.Group  value={formik.values.value} onChange={formik.handleChange} id="value" name="value" disabled={formik.values.message.length>0?true:false} >
                   <Radio className="col" value="PF"  style={{width:"48%", textAlign:"center"}}>Provider Fraud Flag</Radio>
                   <Radio className="col" value="PC"  style={{width:"48%", textAlign:"center"}}>Provider Credentials</Radio>
                </Radio.Group>                
          </div>

   

           <div style={{textAlign:"center"}}>
<button type="reset" className="btn btn-primary" style={{ width: "15%", marginRight: 10, marginTop: 20, marginBottom: 20}} onClick={() => {
              formik.resetForm();
              seterrmg("");
            }}
          >
            Clear
          </button>
        <button type= "submit" onClick={formik.handleSubmit} className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20, marginBottom:20, backgroundColor:"#0dcaf0", border:"1px solid #0dcaf0"}}>Search </button>

        {errmsg.length>0 && <div style={{color:"red", fontWeight:"bold"}}>{errmsg}</div>}
        </div>
        </div>
        </form>
        </div>
        <div className="content">
              <h4>Search History</h4>
              


<div className="card btm">
            <DataTable value={li} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                    selectionMode="single" selection={selected} onSelectionChange={(e) => setselected(e.value)} dataKey="searcH_ID" metaKeySelection={false}>
                    
                <Column field="prpR_NPI" header="Provider NPI" ></Column>
                <Column field="prpR_SPEC" header="Provider speciality" ></Column> 
                <Column field="nwnW_ID" header="Network Id" ></Column>
                <Column field="nwnW_NAME" header="Network Set Name" ></Column>
                <Column field="prpR_FLAG" header="Provider f f/Provider Cred." ></Column>
                <Column field="froM_DT" header="From Date" ></Column>
                <Column field="enD_DT" header="End Date" ></Column>
                
            </DataTable>
        </div>
            </div>
        </div>
    )
}

else if(Page==="Details_Page"){

  return(

   <ProviderSearch sendToParent={getChildData} data={providerDetails}/>
   
  )
}

}

function return_data(data){
  return(data[1])
}

function dateDiffInDays(a, b) {
  const _MS_PER_DAY = 1000 * 60 * 60 * 24;
  var aa=new Date(a), bb=new Date(b)
  const utc1 = Date.UTC(aa.getFullYear(), aa.getMonth(), aa.getDate());
  const utc2 = Date.UTC(bb.getFullYear(), bb.getMonth(), bb.getDate());

  const res = Math.floor((utc2 - utc1) / _MS_PER_DAY);
  if(res >= 0 ){
    if(res > 366 ){
      return("F");
    }
    else{return("T")}
  }
  else if(res<0){return("G")}
}


export default Provider;