import React, { useState } from "react";
import invoke from "../../api";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';




function Membersearch(props){

    console.log(props.data);
    var MemDetails=props.data;

    const footerContent = (
        <div>
            
            <Button label="close"  onClick={() =>{ setVisible(false); setonClickView([])}} autoFocus />
        </div> )
  
  const paginatorLeft = <Button type="button" icon="pi pi-refresh" text />;
  const paginatorRight = <Button type="button" icon="pi pi-download" text />;

  const [onclickMem, setOnclickMem]=useState(null);
  const [visible, setVisible] = useState(false);
  const [onclickview, setonClickView]=useState([]);
  const [visible1, setVisible1] = useState(false);




    return(
        <div className="MainArea">
        <div className="content">
        <div className="row">
                        <h4 className="col">Search Results</h4>
                        <div className="col">
                        <button className="btn btn-primary" onClick={()=>props.sendToParent("Member_Page")}  style={{float:"right"}}> Back</button></div>
                        </div>
    <div className="card">
                <DataTable value={MemDetails} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                        selectionMode="single" cellSelection  dataKey="clcL_ID" metaKeySelection={false}>
                       
                        
                    <Column field="sbsB_NAME" header="Member Name" body={row => <button style={{border:"1px white solid", backgroundColor:"white"}} onClick={()=>{
                              var payload={
              
                                "sbsB_NAME": "",
                                "memE_REL": "",
                                "grgR_ID": "",
                                "sbsB_ID": row.sbsB_ID,
                                "mcrE_ID": "",
                                "grgR_NAME": "",
                                "neT_DUE": 0,
                                "cob": "",
                                "lasT_PAY_DT": "",
                                "memE_STATUS": "",
                                "iD_MAILED_DT": "",
                                "deliquencY_DT": "",
                                "sbsB_CK": 0,
                                "sgsG_CK": row.sgsG_CK,
                                "memE_CK": row.memE_CK,
                                "grgR_CK": 0,
                                "plaN_DESC": "",
                                "carrieR_NAME": "",
                                "coB_EFF_DT": "",
                                "coB_TERM_DT": "",
                                "membeR_RELATION": "",
                                "membeR_NAME": "",
                                "plaN_EFF_DT": "",
                                "plaN_TERM_DT": "",
                                "membeR_DOB": "",
                                "homE_ADDRESS": "",
                                "pcP_DETAILS": ""
                                
                            }
                            invoke("api/home/getMemberDetailDesc", "post", (data, success, status) => {
                              if (success) {
                                if(status===200){
                               console.log(data[1]);
                               var l=getData(data)
                               setOnclickMem(l);
                               setVisible(true);
                               console.log(onclickMem);
                                }
                              } 
                              console.log(onclickMem);
                            },payload);  
                    }}>{row.sbsB_NAME}</button>}></Column>
                    <Column field="sbsB_ID" header="Subscriber Id" ></Column>
                    <Column header="Member Relationship" body={(rowData) => get_relation(rowData.memE_REL)}></Column>
                    <Column field="grgR_ID" header="Group Id" ></Column>
                    <Column field="grgR_NAME" header="Group Name" ></Column>
                    <Column field="cob" header="COB" ></Column>
                    <Column field="neT_DUE" header="Net Due" body={(rowData) =>getDue(rowData.neT_DUE) }></Column>
                    <Column field="lasT_PAY_DT" header="Last Payment Date" body={(rowData) =>getDue(rowData.lasT_PAY_DT) }></Column>
                    <Column field="memE_STATUS" header="Status" ></Column>
                    <Column field="iD_MAILED_DT" header="Id Card Mailed Date" ></Column>
                    <Column  header="Deliquency Date" body={(rowData) => getDue(rowData.deliquencY_DT)} ></Column>
                  
                </DataTable>
            </div>
    
    
          </div>
    
          {visible &&
          <div className="content"> 
          <h2>Detail Description</h2>
    
<DataTable value={onclickMem} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                   selectionMode="single"  dataKey="searcH_ID" metaKeySelection={false}>
               {/* <Column  header="Accumlator Name" body={(rowData) => get_Acc_Name(rowData.acC_AMT2)}></Column> */}
               <Column  field="sbsB_NAME" header="Subgroup Name"></Column>
               <Column field="plaN_DESC" header="Plan Name" ></Column>
               <Column field="membeR_NAME" header="Member Name" ></Column>
               <Column  header="View Details" body={row => <button className="btn btn-primary" onClick={()=>{setVisible1(true); var viewlist=[row]; setonClickView(viewlist)}}>view</button>} ></Column> 
           </DataTable>

           <Dialog header="Provider Details" visible={visible1} position={"top"} style={{ width: '80vw' }} onHide={() => setVisible1(false)} footer={footerContent} draggable={false} resizable={true}>
                    
                    {onclickview.map((i) => (
                      <table style={{width:"100%"}}>
                      <tr className="row" style={{height:50}}>
                        <th className="col">Subgroup Name</th>
                        <td className="col">:{i.sbsB_NAME}</td>
                        <th className="col">Carrier Name</th>
                        <td className="col">: {i.carrieR_NAME}  </td>
                        
                      </tr>
                      <tr className="row" style={{height:50}}>
                        <th className="col">Plan Name</th>
                        <td className="col">:{i.plaN_DESC}</td>
                        <th className="col">COB Effect Date</th>
                        <td className="col">:{i.coB_EFF_DT}</td>
                        
                      </tr>
                      <tr className="row" style={{height:50}}>
                        <th className="col">COB Term Date</th>
                        <td className="col">:{getDue(i.coB_TERM_DT)}</td>
                        <th className="col">Relationship Description</th>
                        <td className="col">:{get_relation(i.membeR_RELATION)}</td>
                        
                      </tr>
                      <tr className="row" style={{height:50}}>
                        <th className="col">Member Name</th>
                        <td className="col">:{i.membeR_NAME}</td>
                        <th className="col">Effective Date</th>
                        <td className="col">:{i.plaN_EFF_DT}</td>
    
                      </tr>
                      <tr className="row" style={{height:50}}>
                        <th className="col">End Date</th>
                        <td className="col">:{i.plaN_TERM_DT}</td>
                        <th className="col">DOB</th>
                        <td className="col">:{i.membeR_DOB}</td>
    
                      </tr>
                      <tr className="row" style={{height:50}}>
                        <th className="col">Home Address</th>
                        <td className="col">:{i.homE_ADDRESS}</td>
                        <th className="col">PCP Details</th>
                        <td className="col">:{i.pcP_DETAILS}</td>
                      </tr>
                      </table>
                       ))} 
                    
                </Dialog>
            </div>
            }
          </div>
    )
}

function getData(data){
    return(data[1])
  }

  function getDue(val){
    if(val){
      return(val)
    }
    else{return("Not Applicable")}
  }


  function get_relation(rel){
    if(rel==="M"){
      return("Subscriber")
    }
    else if(rel==="H"){return("Husband")}
    else if(rel==="W"){return("Wife")}
    else if(rel==="D"){return("Daughter")}
    else if(rel==="S"){return("Son")}
    else if(rel==="O"){return("Other Dependencies")}
    }
    

export default Membersearch;