import React, { useState,useEffect,useRef } from "react";
import { Radio } from 'antd';
import {useLocation} from "react-router-dom";
import invoke from "../../api";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import Membersearch from "./MemberSearch";
import { Formik, useFormik } from "formik";
import { Toast } from "primereact/toast";

function Member(){

    var [li,setli]=useState([]);

    const [Page,setPage]=useState("Member_Page");
    const [selected, setselected] = useState(null);
    const [memberData, setmemberData]=useState(null);
    const [errmsg, seterrmg]= useState("");

    const toast = useRef(null);
    
    var id=sessionStorage.getItem("UserId");
    useEffect(() => {
      invoke("api/home/getMemeSrch/"+id, "get", (data, success, status) => {
        if (success) {
          if (status === 200) {
            console.log(data[1])
            var lst=returnData(data)
            setli(lst)
          }
        } 
      })
    }, []);



    const { state } = useLocation();
    
    useEffect (()=>{
      try{
        formik.setFieldValue("Subscriber_Id" ,state.subscriber_Id);
        formik.setFieldValue("GroupId",state.Group_ID);
       formik.setFieldValue( "SubGroupId",state.SubGroup_ID);
      }
      catch{
        formik.setFieldValue("Subscriber_Id","");
        formik.setFieldValue("GroupId","");
        formik.setFieldValue("SubGroupId");
      }
   
    },[state])

   
    const formik = useFormik({
      initialValues: {
      Subscriber_Id:'',
      GroupId:'',
      SubGroupId:'',
      relation:"",
      value:"",
      fname:"",
      lname:"",
      dob:null
      },
      onSubmit: (values) => {
        var val={
          "useR_ID": sessionStorage.getItem("UserId"),
          "searcH_ID": 0,
          "sbsB_ID": values.Subscriber_Id,
          "memE_ID": 0,
          "grgR_ID": values.GroupId,
          "memE_REL": values.relation,
          "sgsG_ID": values.SubGroupId,
          "firsT_NAME": values.fname,
          "lasT_NAME": values.lname,
          "birtH_DT": "",
          "dob": values.dob,
          "gender":values.value.trim()
      }
      
          if(values.Subscriber_Id==="" && values.GroupId==="" &&( values.SubGroupId===""|| values.SubGroupId==undefined) && values.relation==="" && values.value==="" && values.fname==="" && values.lname==="" &&( values.dob===null|| values.dob===undefined|| values.dob==="undefined-undefined-")){
            seterrmg("Please enter the data");
          toast.current.show({ severity: "error", summary: "Error", detail:"Please enter the data", life: 3000 });
          }
          else if(values.Subscriber_Id==="" && values.GroupId==="" &&( values.SubGroupId===""|| values.SubGroupId==undefined) && values.relation==="" && values.fname==="" && values.lname==="" && values.dob===null){
            seterrmg("Please enter required feilds data");
            toast.current.show({ severity: "error", summary: "Error", detail:"Please enter required feilds data", life: 3000 });
          }
          else if (values.relation && !values.Subscriber_Id) {
            seterrmg("Please enter Subscriber Id");
            toast.current.show({ severity: "error", summary: "Error", detail:"Please enter Subscriber Id", life: 3000 });
           }
          else if (values.SubGroupId && !values.GroupId) {
            seterrmg("Please enter Group Id");
            toast.current.show({ severity: "error", summary: "Error", detail:"Please enter Group Id", life: 3000 });
           }   
          else if ((values.fname || values.lname) && !values.dob) {
            seterrmg( "Please enter Date of Birth");
             toast.current.show({ severity: "error", summary: "Error", detail:"Please enter Date of Birth", life: 3000 });
           }
          else if (values.dob && !values.fname && !values.lname) {
            seterrmg("Please enter First Name or Last Name");
            toast.current.show({ severity: "error", summary: "Error", detail:"Please enter First Name or Last Name", life: 3000 });

           }
         else {
          seterrmg(""); 
           invoke(
             "api/Home/getMembers",
             "post",
             (data, success, status) => {
               if (success) {
                 if (status === 200) {
                   if(data[1].length>0){
                     console.log(data[1]);
                     setmemberData(data[1]);
         
                       invoke("api/home/insertMemeSrch", "put", (data, success, status) => {
                         if (success) {
                          console.log("done")
                         } 
                       },val);
                     var UpdatedList=[val,...li]
                     setli(UpdatedList)
                     
                      setPage("Member_Search")
                   } 
                   else{
                    seterrmg("Data Not Found");
                    toast.current.show({ severity: "error", summary: "Error", detail:"Data Not Found", life: 3000 });
                   } 
                 }
               }
             }
             , val)
         }

         
             }
    })

    useEffect(() => {
      if (selected) {
        formik.setFieldValue("Subscriber_Id" ,selected.sbsB_ID);
        formik.setFieldValue("relation",selected.memE_REL);
        formik.setFieldValue("GroupId",selected.grgR_ID);
        formik.setFieldValue("SubGroupId",selected.sgsG_ID);
        formik.setFieldValue("fname",selected.firsT_NAME);
        formik.setFieldValue("lname",selected.lasT_NAME);
        formik.setFieldValue("dob" ,formatDate(selected.birtH_DT));
        formik.setFieldValue("value",selected.gender);
      }

    }, [selected]);



    const getChildData=(val) =>{
      console.log(val)
      setPage(val);
    }
  

if(Page==="Member_Page"){
    return(
        <div className="MainArea">
            <div className="content">
            <Toast ref={toast} />
              <form noValidate className="form  form-multiline" id="myForm" onSubmit={formik.handleSubmit}>
                
    <div className="row">
        <div className="form-group col">
        <label className="control-label ">Subscriber Id</label>
        <input type="text" className="form-control " id="Subscriber_Id" value={formik.values.Subscriber_Id} onChange={formik.handleChange} placeholder="Subscriber Id"></input>
        </div>

        <div className="form-group col" >
        <label className="control-label ">Member Relation</label>
        <select className="form-control inp_text " value={formik.values.relation}  onChange={formik.handleChange} placeholder="select" name="relation" id="relation">              
          <option value="" >Select Relation</option>
          <option value="M">Subscriber</option>
          <option value="H">Husband</option>
          <option value="W">Wife</option>
          <option value="D">Daughter</option>
          <option value="S">Son</option>
          <option value="O">Other Dependent</option>
        </select>
      </div>


        <div className="form-group col">
        <label className="control-label ">Group Id</label>
        <input type="text" className="form-control " value={formik.values.GroupId} onChange={formik.handleChange} id="GroupId" placeholder="Group Id"></input>
        </div> 
        </div>


        <div className="row">
        <div className="form-group col">
        <label className="control-label ">Subgroup Id</label>
        <input type="text" className="form-control " value={formik.values.SubGroupId} onChange={formik.handleChange} id="SubGroupId" placeholder="Subgroup Id"></input>
        </div>
 

        <div className="form-group col">
        <label className="control-label ">First Name</label>
        <input type="text" className="form-control" value={formik.values.fname} onChange={formik.handleChange} id="fname" placeholder="First Name"></input>
        </div>
        


        <div className="form-group col">
        <label className="control-label ">Last Name</label>
        <input type="text" className="form-control " value={formik.values.lname} onChange={formik.handleChange} id="lname" placeholder="Last Name"></input>
        </div>       
        </div>


        <div className="row">
        <div className="form-group col-lg-4">
        <label className="control-label ">DOB</label>
        <input type="date" className="form-control " value={formik.values.dob} onChange={formik.handleChange} id="dob" placeholder="Enter Date"></input>

        </div>

        <div className="form-group col-lg-4">
        <label className="control-label ">Gender</label>
        <Radio.Group onChange={formik.handleChange} value={formik.values.value} className="row" id="value" name="value">
                   <Radio className="col-auto" value="M" style={{fontSize:17,fontWeight:350}}>Male</Radio>
                   <Radio className="col" value="F" style={{fontSize:17,fontWeight:350}}>Female</Radio>
                </Radio.Group>

        </div>
 </div>

        
        <div style={{textAlign:"center"}}>
      

        <button type="reset" className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20,  marginBottom:20}} 
        onClick={()=>{
          formik.resetForm();
          formik.setFieldValue("dob", null);
          seterrmg("");
        }}>Clear</button>
          <button type= "submit" onClick={formik.handleSubmit} className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20, marginBottom:20, backgroundColor:"#0dcaf0", border:"1px solid #0dcaf0"}}>Search </button>
        {errmsg.length>0 && <div style={{color:"red", fontWeight:"bold"}}>{errmsg}</div>}
        </div>
</form>
</div>


<div className="content">
              <h4>Search History</h4>
              

<div className="card btm">
            <DataTable value={li} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                    selectionMode="single" selection={selected} onSelectionChange={(e) => setselected(e.value)} dataKey="searcH_ID" metaKeySelection={false}>
                <Column field="sbsB_ID" header="Subscriber Id" ></Column>
                <Column header="Member Relationship" body={(rowData) => get_relation(rowData.memE_REL)}></Column>
                <Column field="grgR_ID" header="Group Id" ></Column>
                <Column field="sgsG_ID" header="Subgroup Id" ></Column>
                <Column field="firsT_NAME" header="First Name" ></Column>
                <Column field="lasT_NAME" header="Last Name" ></Column>
                <Column field="birtH_DT" header="DOB" ></Column>
                <Column field="gender" header="Gender" ></Column>
            </DataTable>
        </div>
            </div>
        </div>
    )
}

else if(Page==="Member_Search"){

  return(

   <Membersearch  sendToParent={getChildData} data={memberData}/>
  )
}

}

function get_relation(rel){
if(rel==="M"){
  return("Subscriber")
}
else if(rel==="H"){return("Husband")}
else if(rel==="W"){return("Wife")}
else if(rel==="D"){return("Daughter")}
else if(rel==="S"){return("Son")}
else if(rel==="O"){return("Other Dependencies")}
}



function formatDate(inputDate) {
  if(inputDate!==""){
  const dateComponents = inputDate.split('-');
  const formattedDate = `${dateComponents[2]}-${dateComponents[1]}-${dateComponents[0]}`;
  return formattedDate;}
  else{
    return null
  }
 }




function returnData(data){
  return(data[1])
}


export default Member;






