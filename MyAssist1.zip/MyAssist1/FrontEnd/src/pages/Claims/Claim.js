import React, { useEffect,useState,useRef } from "react";
import { Radio } from 'antd';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import invoke from "../../api";
import ClaimDetail from "./ClaimDetail";
import { Formik, useFormik } from "formik";
import { Toast } from "primereact/toast";
import { useNavigate } from "react-router-dom";

function Claim(){
  const navigate = useNavigate();

  
  const [selected, setselected] = useState(null);
  const [Page, setPage]=useState("claims");
  const [claims_data,setClaims_data]=useState([]);
  const [errmsg, seterrmg]= useState("");

  var [li,setli]=useState([]);
  const toast = useRef(null);

  var id=sessionStorage.getItem("UserId");
  useEffect(() => {
    invoke("api/home/getClaimsSrch/"+id, "get", (data, success, status) => {
      if (success) {
        if (status === 200) {
          // console.log(data[1])
          var lst=Claims(data)
          setli(lst)
        }
      } 
    })
  },[]);
  
    useEffect(() => {
      if (selected) {
        formik.setFieldValue("message",selected.clcL_ID);
        formik.setFieldValue("auth_id",selected.cdmL_UMAUTH_ID);
        formik.setFieldValue("claim_type",selected.clcL_TYPE);
        formik.setFieldValue("value",selected.mB_TYPE);
        formik.setFieldValue("value1",selected.datE_TYPE);
        formik.setFieldValue("mB_value",selected.mB_VAL);
        formik.setFieldValue("dt1",selected.froM_DT);
        formik.setFieldValue("dt2",selected.tO_DATE);
      }
    }, [selected]);

    const formik = useFormik({
      initialValues: {
        message:'',
        auth_id:"",
        claim_type:"",
        value:"",
        value1:"",
        mB_value:"",
        dt1:null,
        dt2:null
      },
      onSubmit: (values) => {
        const val={
          "useR_ID": sessionStorage.getItem("UserId"),
          "searcH_ID": 0,
          "clcL_ID": values.message,
          "sbsB_ID": "",
          "ckpY_REF_ID": "",
          "cdmL_UMAUTH_ID": values.auth_id,
          "cdmL_UMREF_ID": "",
          "mB_TYPE": values.value,
          "mB_VAL": values.mB_value,
          "c_SEQ_NO": 0,
          "sbsB_CK": 0,
          "grgR_CK": 0,
          "units": 0,
          "prpR_ID": "",
          "cspI_ID": "",
          "prpR_NPI": "",
          "prpR_NAME": "",
          "clcL_CL_TYPE": "",
          "clcL_CUR_STS": "",
          "starT_DT": "",
          "enD_DT": "",
          "clcL_TOT_CHG": 0,
          "clcL_TOT_PAYABLE": 0,
          "memB_LIABILITY": 0,
          "clcL_NTWK_IND": "",
          "pldS_DESC": "",
          "clcL_TYPE": values.claim_type,
          "datE_TYPE": values.value1,
          "pos": "",
          "servicE_ID": "",
          "sedS_DESC": "",
          "pscD_DESC": "",
          "sesE_ID": "",
          "idcD_ID": "",
          "clcL_LOW_SVC_DT": "",
          "clcL_HIGH_SVC_DT": "",
          "clcL_PAID_DT": "",
          "froM_DT": values.dt1,
          "tO_DATE": values.dt2
        }
        if(values.message==="" && values.auth_id==="" && values.claim_type==="" && values.value==="" && values.value1==="" && values.mB_value==="" && values.dt1===null && values.dt2===null)
 { 
  seterrmg("Please enter the data");
  toast.current.show({ severity: "error", summary: "Error", detail:"Please enter the data", life: 3000 });

}
else if (values.message !== "") {
  srch();
}


else {
  if ( values.value != "") {
      if (values.mB_value != "") {
          if (values.value1 != "") {
              if ((values.dt1 != "") && (values.dt2 != "")) {
                      var res = dateDiffInDays(values.dt1, values.dt2);
                      if (res == "F") {
                        seterrmg( "Date range must be maximum of one year");
                        toast.current.show({ severity: "error", summary: "Error", detail:"Date range must be maximum of one year", life: 3000 });
                      } else if (res == "G") {
                        seterrmg( "Start date must be greater than end date");
                        toast.current.show({ severity: "error", summary: "Error", detail:"Start date must be greater than end date", life: 3000 });
                      } else if (res == "T") {
                          srch();
                      }
              }else
              {
                  seterrmg("Please enter date range values");
                  toast.current.show({ severity: "error", summary: "Error", detail:"Please enter date range values", life: 3000 });
              }
          }else
          {
              seterrmg("Please enter date range values");
              toast.current.show({ severity: "error", summary: "Error", detail:"Please enter date range values", life: 3000 });
          }
      } else {
          seterrmg( "Please enter Member Id & Billing/Service NPI value and Date range");
          toast.current.show({ severity: "error", summary: "Error", detail:"Please enter Member Id & Billing/Service NPI value and Date range", life: 3000 });
      }
  }
  else if (values.value1 != "") {
      if ((values.dt1 != "") && (values.dt2 != "")) {
              if (values.auth_id != "") {

                  var res = dateDiffInDays(values.dt1, values.dt2);
                  if (res == "F") {
                      seterrmg( "Date range must be maximum of one year");
                      toast.current.show({ severity: "error", summary: "Error", detail: "Date range must be maximum of one year", life: 3000 });
                  } else if (res == "G") {
                      seterrmg("Start date must be greater than end date");
                      toast.current.show({ severity: "error", summary: "Error", detail:"Start date must be greater than end date", life: 3000 });
                  } else if (res == "T") {
                     srch();
                  }
              } else {
                  seterrmg( "Please enter Member Id/Billing/Service NPI value or Authorization ID");
                  toast.current.show({ severity: "error", summary: "Error", detail:"Please enter Member Id/Billing/Service NPI value or Authorization ID", life: 3000 });
              }
          
      } else {
          seterrmg("Please enter date range values");
          toast.current.show({ severity: "error", summary: "Error", detail:"Please enter date range values", life: 3000 });
      }
  }
  else if (values.auth_id != "") {
      seterrmg("Please enter Date range values");
      toast.current.show({ severity: "error", summary: "Error", detail:"Please enter Date range values", life: 3000 });
  } 
  else {
      seterrmg("Please enter required fields");
      toast.current.show({ severity: "error", summary: "Error", detail:"Please enter required fields", life: 3000 });
  }
}


 function srch(){
invoke(
  "api/Home/getClaims",
  "post",
  (data, success, status) => {
    if (success) {
      if (status === 200) {
        if(data[1].length>0){
          console.log(data[1]);
          setClaims_data(data[1]);
            invoke("api/home/insertClaimsSrch", "put", (data, success, status) => {
              if (success) {
               console.log("done")
              } 
            },val);
          var UpdatedList=[val,...li]
          setli(UpdatedList)
          setPage("Claim_search")
        } 
        else{
          seterrmg("Data Not Found")
      toast.current.show({ severity: "error", summary: "Error", detail:"Data Not Found", life: 3000 });

        } 
      }
    }
  }
  , val)

        }
      }
    })

    useEffect(()=>{

      if(formik.values.message.length>0){
   
   formik.setFieldValue("auth_id","");
   formik.setFieldValue("claim_type","");
   formik.setFieldValue("value","");
   formik.setFieldValue("value1","");
   formik.setFieldValue("mB_value","");
   formik.setFieldValue("dt1",null);
   formik.setFieldValue("dt2",null);
      }
    
    },[formik.values.message])
  


    const getChildData=(val) =>{
      console.log(val)
      setPage(val);
    }
  
if(Page=="claims"){
    return(
        <div className="MainArea">
            <div className="content">
            <Toast ref={toast} />
              <form noValidate className="form  form-multiline" id="myForm" onSubmit={formik.handleSubmit}>
                
    <div className="row">
        <div className="form-group col">
        <label className="control-label ">Claim Id</label>
        <input type="text" className="form-control " id="message" value={formik.values.message} onChange={formik.handleChange} placeholder="Claim Id"></input>

        </div>
        <div className="form-group col">
        <label className="control-label ">Autherization Id</label>
        <input type="text" className="form-control " id="auth_id" value={formik.values.auth_id} onChange={formik.handleChange} placeholder="Autherization Id" disabled={formik.values.message.length>0?true:false}></input>

        </div>
        

        <div className="form-group col" >
        <label className="control-label ">Claim type</label>
        <select className="form-control inp_text " id="claim_type" value={formik.values.claim_type} onChange={formik.handleChange} placeholder="select" name="claim_type"  disabled={formik.values.message.length>0?true:false}>        
          <option value="">Select </option>
          <option value="Dental">Dental</option>
          <option value="Medical">Medical</option>
          <option value="hospital">Hospital</option>
          <option value="all">All</option>
        </select>
      </div>
        </div>

      <div className="row" >
                
    <div className="card flex col-lg-5" style={{marginTop:20,marginRight:30,padding:20, marginLeft:15, width:"30.5%"}}>
                <Radio.Group  value={formik.values.value} onChange={formik.handleChange} name="value" id="value">
                   <Radio className="col" value="M"  disabled={formik.values.message.length>0?true:false}>Member Id</Radio>
                   <Radio className="col" value="B" disabled={formik.values.message.length>0?true:false}>Billing/Service NPI</Radio>
                </Radio.Group>
                <div>
                <div className="row" style={{paddingTop:10}}>
                   <div className="col-lg-4 " >
                     value:
                  </div>
                <div class="col-lg-6">
                <input type="text" className="form-control inp_text" value={formik.values.mB_value} onChange={formik.handleChange} id="mB_value" name="mB_value" disabled={formik.values.message.length>0?true:false}/>
                </div>
                </div>
                </div>
                </div>
                
    
                <div className="card flex  col-lg-6" style={{marginTop:20,padding:20}}>
                <Radio.Group value={formik.values.value1} onChange={formik.handleChange}  name="value1" id="value1" className="row" disabled={formik.values.message.length>0?true:false}>
                   <Radio className="col" value="S">Date of service</Radio>
                   <Radio className="col" value="R">Claim Recived</Radio>
                   <Radio className="col" value="P">Claim Paid Date</Radio>
                </Radio.Group>
                <div style={{paddingTop:10, margin:"auto"}}>
            <div className="row justify-content-md" style={{paddingTop:10, textAlign:"center"}}>
               <div className="col-auto " style={{paddingTop:5}}>
                 Date Range:
              </div>
            <div class="col row"style={{width:"auto"}}>
            <input type="date" className="form-control inp_text col" id="dt1" name="dt1" value={formik.values.dt1} onChange={formik.handleChange} disabled={formik.values.message.length>0?true:false}/>
            <div className="col-auto">to</div> <input type="date" className="form-control inp_text col" id="dt2" name="dt2" value={formik.values.dt2} onChange={formik.handleChange} disabled={formik.values.message.length>0?true:false}/>
            </div>
           </div>
            </div>
                </div>
                </div>

                <div style={{textAlign:"center"}}>
        {/* <button type="button" onClick={()=>{}} className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20, marginBottom:20}} >Search </button>
        <button type="reset" className="btn btn-primary" onClick={()=>setMessage("")}  style={{width:"15%", marginRight:10, marginTop:20,  marginBottom:20}}>Clear</button> */}
       
<button
            type="reset"
            className="btn btn-primary"
            style={{ width: "15%", marginRight: 10, marginTop: 20, marginBottom: 20 }}
            onClick={() => {
              formik.resetForm();
              seterrmg("");
            }}
          >
            Clear
          </button>
          <button type= "submit" onClick={formik.handleSubmit} className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20, marginBottom:20, backgroundColor:"#0dcaf0", border:"1px solid #0dcaf0"}}>Search </button>
          {errmsg.length>0 && <div style={{color:"red", fontWeight:"bold"}}>{errmsg}</div>}
        </div>


        </form>
            </div>
            <div className="content">
              <h4>Search History</h4>
              <div className="table-responsive">
           

<div className="card btm" >
            <DataTable value={li} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }}  size="small"
                    selectionMode="single" selection={selected} onSelectionChange={(e) => setselected(e.value)} dataKey="searcH_ID" metaKeySelection={false}>
                <Column field="clcL_ID" header="Claims Id" ></Column>
                <Column field="mB_TYPE" header="Entity Type" ></Column>
                <Column field="mB_VAL" header="Entity Value" ></Column>
                <Column field="" header="Autherization Id" ></Column>
                <Column field="clcL_TYPE" header="Date Range" ></Column>
                <Column field="datE_TYPE" header="From Date" ></Column>
                <Column field="tO_DATE" header="To Date" ></Column>
            </DataTable>
        </div>
</div>
            </div>

        </div>
    )
}
else if("Claim_search"){
return(

<>
<ClaimDetail sendToParent={getChildData} data={claims_data}/>
</>
 
)
}
}


function Claims(data){
  return(data[1])
}

function dateDiffInDays(a, b) {
  const _MS_PER_DAY = 1000 * 60 * 60 * 24;
  var aa=new Date(a), bb=new Date(b)
  const utc1 = Date.UTC(aa.getFullYear(), aa.getMonth(), aa.getDate());
  const utc2 = Date.UTC(bb.getFullYear(), bb.getMonth(), bb.getDate());

  const res = Math.floor((utc2 - utc1) / _MS_PER_DAY);
  if(res >= 0 ){
    if(res > 366 ){
      return("F");
    }
    else{return("T")}
  }
  else if(res<0){return("G")}
}

export default Claim;