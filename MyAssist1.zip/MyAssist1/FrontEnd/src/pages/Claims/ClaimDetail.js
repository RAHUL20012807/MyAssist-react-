import React, {useState } from "react";
import {useNavigate} from "react-router-dom"
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import invoke from "../../api";




function ClaimDetail(props){
    const [onClickClaims,setonClickClaims]=useState(null);
    const [claims_data,setClaims_data]=useState([]);
    const [visible, setVisible] = useState(false);
    const [visible1, setVisible1] = useState(false);
    const [onclickview, setonClickView]=useState([]);

    const navigate = useNavigate();

    console.log(props.data);
    var claims_details =props.data;

    const footerContent = (
        <div>
            
            <Button label="close"  onClick={() => setVisible(false)} autoFocus />
        </div>
    );

    const paginatorLeft = <Button type="button" icon="pi pi-refresh" text />;
    const paginatorRight = <Button type="button" icon="pi pi-download" text />;


    return(
    <div className="MainArea">
    <div className="content btm">
      <div className="row">
                      <h4 className="col">Search Results</h4>
                      <div className="col">
                      <button className="btn btn-primary" onClick={()=>props.sendToParent("claims")}  style={{float:"right"}}> Back</button></div>
                      </div>
    <div className="card">
              <DataTable value={claims_details} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                      selectionMode="single" cellSelection selection={onClickClaims} onSelectionChange={(e) => setonClickClaims(e.value)} dataKey="clcL_ID" metaKeySelection={false}>
              {/* <DataTable value={claims_details} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }}
                      paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink"
                      currentPageReportTemplate="{first} to {last} of {totalRecords}" paginatorLeft={paginatorLeft} paginatorRight={paginatorRight}
                      selectionMode="single" cellSelection selection={onClickClaims} onSelectionChange={(e) => setonClickClaims(e.value)} dataKey="clcL_ID" metaKeySelection={false}> */}
                     
                      
                  <Column field="clcL_ID" header="Claims Id" body={row => <button style={{border:"1px white solid", backgroundColor:"white"}} onClick={()=>{
                            var val1={
                              "useR_ID": sessionStorage.getItem("UserId"),
                     "searcH_ID": 0,
                    "clcL_ID": row.clcL_ID,
                    "sbsB_ID": "",
                    "ckpY_REF_ID": "",
                    "cdmL_UMAUTH_ID": "",
                    "cdmL_UMREF_ID": "",
                    "mB_TYPE": "",
                    "mB_VAL": "",
                    "c_SEQ_NO": 0,
                    "sbsB_CK": 0,
                    "grgR_CK": 0,
                    "units": 0,
                    "prpR_ID": "",
                    "cspI_ID": "",
                    "prpR_NPI": "",
                    "prpR_NAME": "",
                    "clcL_CL_TYPE": "",
                    "clcL_CUR_STS": "",
                    "starT_DT": "",
                    "enD_DT": "",
                    "clcL_TOT_CHG": 0,
                    "clcL_TOT_PAYABLE": 0,
                    "memB_LIABILITY": 0,
                    "clcL_NTWK_IND": "",
                    "pldS_DESC": "",
                    "clcL_TYPE": "",
                    "datE_TYPE": "",
                    "pos": "",
                    "servicE_ID": "",
                    "sedS_DESC": "",
                    "pscD_DESC": "",
                    "sesE_ID": "",
                    "idcD_ID": "",
                    "clcL_LOW_SVC_DT": "",
                    "clcL_HIGH_SVC_DT": "",
                    "clcL_PAID_DT": "",
                    "froM_DT": "2023-09-07T10:03:33.260Z",
                    "tO_DATE": "2023-09-07T10:03:33.261Z"
                    
                            }
                            
                            invoke("api/home/getClaimsDetailDesc", "post", (data, success, status) => {
                              if (success) {
                                if(status==200){
                               console.log(data[1]);
                               var l=Claims(data)
                               setonClickClaims(l);
                               setVisible(true);
                               console.log(onClickClaims);
                                }
                              } 
                              console.log(onClickClaims);
                            },val1);
  
                  }}>{row.clcL_ID}</button>}></Column>
  
  
                  <Column field="sbsB_ID" header="Subscriber_Id" body={row => <button style={{border:"1px white solid", backgroundColor:"white"}} 
                  onClick={()=>{navigate("/nav/member",  { state: { subscriber_Id: row.sbsB_ID, Group_ID:"", SubGroup_ID:"" } })}}
                  >{row.sbsB_ID}</button>}></Column>
  
                  <Column field="prpR_NPI" header="Billing Provider NPI" ></Column>
                  <Column field="prpR_NAME" header="Provider Name" ></Column>
                  <Column field="pldS_DESC" header="Claim Type" ></Column>
                  <Column header="Claim Status"
            body={(rowData) => get_status(rowData.clcL_CUR_STS)}></Column>
                  <Column field="clcL_LOW_SVC_DT" header="Date of Service" ></Column>
                  <Column field="clcL_TOT_CHG" header="Billed Amount" 
                  body={(rowData) => `$${Number(rowData.clcL_TOT_CHG).toFixed(2)}`}></Column>
                  <Column field="clcL_TOT_PAYABLE" header="Paid Amount" 
                  body={(rowData) => `$${Number(rowData.clcL_TOT_PAYABLE).toFixed(2)}`}></Column>
                  <Column field="ckpY_REF_ID" header="Cheque number" ></Column>
                  <Column field="" header="Autherization Id" ></Column>
                  <Column  header="Network Type"
            body={(rowData) => get_network(rowData.clcL_NTWK_IND)} ></Column>
                
                  <Column field="pldS_DESC" header="Plain Description" ></Column>
                  <Column field="clcL_PAID_DT" header="Paid Date" ></Column>
              </DataTable>
          </div>

      </div>
      {visible &&
      <div className="content" disabled={onClickClaims?false:true}>
        <h2>Detail Description</h2>
  

         <DataTable value={onClickClaims} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }}
size="small"
                   selectionMode="single"  dataKey="searcH_ID" metaKeySelection={false}>
                   {/* selectionMode="single" selection={data_selected} onSelectionChange={(e) => setData_selected(e.value)}   dataKey="userId" metaKeySelection={false}> */}
               <Column field="clcL_ID" header="Claim ID" ></Column>
               <Column field="prpR_NPI" header="Servicing Provider NPI" ></Column>
               <Column field="" header="Authorization ID" ></Column>
               <Column  header="View Details" body={row => <button className="btn btn-primary" onClick={()=>{setVisible1(true); var viewlist=[row]; setonClickView(viewlist)}}>view</button>} ></Column> 
           </DataTable>


         <Dialog header="Claim Details" visible={visible1} position={"top"} style={{ width: '80vw' }} onHide={() => setVisible1(false)} footer={footerContent} draggable={false} resizable={true}>
                  
                  {onclickview.map((i) => (
                    <table style={{width:"100%"}}>
                    <tr className="row" style={{height:50}}>
                      <th className="col">Claim ID</th>
                      <td className="col">:{i.clcL_ID}</td>
                      <th className="col">Autherisation ID</th>
                      <td className="col">:           </td>
                      <th className="col">Servicing Provider NPI</th>
                      <td className="col">:{i.prpR_NPI}</td>
                    </tr>
                    <tr className="row" style={{height:50}}>
                      <th className="col">Diagonisis Code</th>
                      <td className="col">:</td>
                      <th className="col">POS Description</th>
                      <td className="col">:</td>
                      <th className="col">Service Description</th>
                      <td className="col">:</td>
                    </tr>
                    <tr className="row" style={{height:50}}>
                      <th className="col">Member liablity</th>
                      <td className="col">:${i.memB_LIABILITY}.00</td>
                      <th className="col">Units</th>
                      <td className="col">:{i.units}</td>
                      <th className="col">Billed Amount</th>
                      <td className="col">:${i.clcL_TOT_CHG}.00</td>
                    </tr>
                    <tr className="row">
                      <th className="col">Paid Amount</th>
                      <td className="col">:${i.clcL_TOT_PAYABLE}.00</td>
                      <th className="col">Date of Service</th>
                      <td className="col">:{i.clcL_HIGH_SVC_DT}</td>
                      <th className="col"></th>
                      <td className="col"></td>
  
                    </tr>
                    </table>
                    ))}
                  
              </Dialog>
      </div>
  }
      </div>
    )
}
function get_status(status_type){
    if(status_type=="02"){
      return("Claim Accepted - Batch Run Completed")
    }
  }
  
  function get_network(Network_type){
    if(Network_type=="O"){
      return("Out of Network")
    }
  }

  function Claims(data){
    return(data[1])
  }

export default ClaimDetail;