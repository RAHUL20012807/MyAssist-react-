import React, { useEffect,useState,useRef } from "react";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import invoke from "../../api";
import BenifitSearch from "./BenifitSearch";
import { useFormik } from "formik";
import { Toast } from "primereact/toast";


function Benifits(){


  const [selected, setselected] = useState(null);
  const [BnftData, setBnftData] = useState(null);
  const [Page, setPage] = useState("Bnft_Form")
  const [errmsg, seterrmg]= useState("");

  var [li,setli]=useState([]);
  const toast = useRef(null);
 
  var id=sessionStorage.getItem("UserId");
  useEffect(() => {
    invoke("api/home/getBNFTSrch/"+id, "get", (data, success, status) => {
      if (success) {
        if (status === 200) {
          console.log(data[1])
          var lst=returnData(data)
          setli(lst)
        }
      } 
    })
  },[]);
  
  useEffect(() => {
    if (selected) {
      const i = selected;
      formik.setFieldValue("plan_Id", i.cspI_ID);
      formik.setFieldValue("product_Id", i.pdpD_ID.trim());
      formik.setFieldValue("lob", i.pdpD_ID.trim());
      formik.setFieldValue("GrpId", i.grgR_ID.trim());
      formik.setFieldValue("EfFrm_Dt", formatDate(i.efF_FROM_DTs));
      formik.setFieldValue("EfTo_Dt", formatDate(i.efF_TO_DTs));
      formik.setFieldValue("EdFrm_Dt",formatDate(i.enD_FROM_DTs));
      formik.setFieldValue("EdTo_Dt", formatDate(i.enD_TO_DTs));
    }
  }, [selected]);

  const getChildData=(val) =>{
    console.log(val)
    setPage(val);
  }

  const formik = useFormik({
    initialValues: {
      plan_Id:"",
      product_Id:"",
      lob:"",
      GrpId:"",
      EfFrm_Dt:null,
      EfTo_Dt:null,
      EdFrm_Dt:null,
      EdTo_Dt:null
    },
    onSubmit: (values) => {
      if(values.plan_Id==="" && values.product_Id==="" && values.lob==="" && values.GrpId==="" && values.EfFrm_Dt===null && values.EfTo_Dt===null && values.EdFrm_Dt===null && values.EdTo_Dt===null){
        seterrmg("Please enter the values");
        toast.current.show({ severity: "error", summary: "Error", detail:"Please enter the values", life: 3000 });
      }
      else if(values.plan_Id==="" && values.product_Id==="" && values.lob==="" && values.GrpId===""){
       seterrmg("Please enter required values");
       toast.current.show({ severity: "error", summary: "Error", detail:"Please enter required values", life: 3000 });
      }
    else if (((values.EfFrm_Dt != "") && (values.EfTo_Dt != "")) && ((values.EdFrm_Dt == "") || (values.EdTo_Dt == "")) && (values.plan_Id != "") && (values.product_Id != "") && (values.lob != "") && (values.GrpId != "")) {
        srch();
    }
    else if (((values.EfFrm_Dt == "") || (values.EfTo_Dt == "")) && ((values.EdFrm_Dt != "") || (values.EfTo_Dt != "")) && (values.plan_Id != "") && (values.product_Id != "") && (values.lob != "") && (values.GrpId!= "")) {
      srch();
   }
   else if (((values.EfFrm_Dt  === "") && (values.EfTo_Dt === "")) || ((values.EdFrm_Dt === "") && (values.EdTo_Dt=== ""))) {
    seterrmg("Please enter both date ranges");
    toast.current.show({ severity: "error", summary: "Error", detail:"Please enter both date ranges", life: 3000 });
   }
   else if ((((values.EfFrm_Dt=== "") && (values.EfTo_Dt !== "")) || ((values.EfFrm_Dt !== "") && (values.EfTo_Dt=== ""))) || (((values.EdFrm_Dt === "") && (values.EdTo_Dt !== "")) || ((values.EdFrm_Dt !== "") && (values.EdTo_Dt === "")))) {
    seterrmg("Please enter both dates");
    toast.current.show({ severity: "error", summary: "Error", detail:"Please enter both dates", life: 3000 });
   }
   else if ((((values.EfFrm_Dt === "") && (values.EfTo_Dt !== "")) || ((values.EfFrm_Dt !== "") && (values.EfTo_Dt === ""))) || (((values.EdFrm_Dt === "") && (values.EdTo_Dt!= "")) || ((values.EdFrm_Dt != "") && (values.EdTo_Dt === "")))) {
    seterrmg("Please enter both dates");
    toast.current.show({ severity: "error", summary: "Error", detail:"Please enter both dates", life: 3000 });
   }
   else{
                    var res = dateDiffInDays(values.EfFrm_Dt, values.EfTo_Dt);
                    if (res == "F") {
                        seterrmg( "Date range must be maximum of one year");
                        toast.current.show({ severity: "error", summary: "Error", detail:"Date range must be maximum of one year", life: 3000 });
                    } else if (res == "G") {
                      seterrmg( "Start date must be greater than end date");
                      toast.current.show({ severity: "error", summary: "Error", detail:"Start date must be greater than end date", life: 3000 });
                    } else if (res == "T") {
                        res = dateDiffInDays(values.EdFrm_Dt, values.EdTo_Dt);
                        if (res == "F") {
                          seterrmg( "Date range must be maximum of one year");
                        toast.current.show({ severity: "error", summary: "Error", detail:"Date range must be maximum of one year", life: 3000 });
                        } else if (res == "G") {
                          seterrmg( "Start date must be greater than end date");
                        toast.current.show({ severity: "error", summary: "Error", detail:"Start date must be greater than end date", life: 3000 });
                        } else if (res == "T") {
                           srch();
                        }
                    }
            }


function srch(){
  const val={
    "useR_ID": sessionStorage.getItem("UserId"),
    "searcH_ID": 0,
    "grgR_ID":values.GrpId,
    "cspI_ID": values.plan_Id,
    "pdpD_ID": values.product_Id,
    "lob": values.lob,
    "efF_FROM_DT": values.EfFrm_Dt,
    "efF_TO_DT": values.EfTo_Dt,
    "enD_FROM_DT": values.EdFrm_Dt,
    "enD_TO_DT": values.EdTo_Dt,
    "efF_FROM_DTs": "",
    "efF_TO_DTs": "",
    "enD_FROM_DTs": "",
    "enD_TO_DTs": ""
}
invoke(
"api/Home/getBenefits",
"post",
(data, success, status) => {
if (success) {
  if (status === 200) {
    if(data[1].length>0){
      console.log(data[1]);
      setBnftData(data[1]);
        invoke("api/home/insertBNFTSrch", "put", (data, success, status) => {
          if (success) {
           console.log("done")
          } 
        },val);
        var val1={
          "useR_ID": sessionStorage.getItem("UserId"),
          "searcH_ID": 0,
          "grgR_ID": values.GrpId,
          "cspI_ID": values.plan_Id,
          "pdpD_ID": values.product_Id,
          "lob": values.lob,
          "efF_FROM_DT": values.EfFrm_Dt,
          "efF_TO_DT": values.EfTo_Dt,
          "enD_FROM_DT": values.EdFrm_Dt,
          "enD_TO_DT": values.EdTo_Dt,
          "efF_FROM_DTs":formatDate(values. EfFrm_Dt),
          "efF_TO_DTs": formatDate(values.EfTo_Dt),
          "enD_FROM_DTs": formatDate(values.EdFrm_Dt),
          "enD_TO_DTs":formatDate(values.EdTo_Dt)
      }
      var UpdatedList=[val1,...li]
      setli(UpdatedList)
      setPage("BnFt_search")
    } 
    else{
      seterrmg("Data Not Found")
      toast.current.show({ severity: "error", summary: "Error", detail:"Date range must be maximum of one year", life: 3000 });
    } 
  }
}
}
, val)
     
    }
    }
  })


if(Page==="Bnft_Form"){
    return(
        <div className="MainArea">
            <div className="content">
            <Toast ref={toast} />
              <form noValidate className="form  form-multiline" id="myForm" onSubmit={formik.handleSubmit}>
                
    <div className="row">
        <div className="form-group col">
        <label className="control-label ">Plan Id</label>
        <input type="text" className="form-control " value={formik.values.plan_Id} onChange={formik.handleChange} id="plan_id"  placeholder="Plan Id"></input>
        </div>

        <div className="form-group col">
        <label className="control-label ">Product Id</label>
        <input type="text" className="form-control " value={formik.values.product_Id} onChange={formik.handleChange} id="product_Id" placeholder="Product Id" ></input>
        </div>
        
        <div className="form-group col">
        <label className="control-label ">Line of Bussiness</label>
        <input type="text" className="form-control " value={formik.values.lob} onChange={formik.handleChange} id="lob" placeholder="Line of Bussiness" ></input>
        </div>
        </div>

        <div className="row">
        <div className="form-group col-lg-4">
        <label className="control-label ">Group Id</label>
        <input type="text" className="form-control " value={formik.values.GrpId} onChange={formik.handleChange} id="GrpId"  placeholder="Group Id"></input>
        </div>
        

        <div className="form-group col-lg-8" >
        <div>
    <label className="control-label" >Effective Date Range</label>
        </div>
            <div class="row"style={{width:"103%",float:"left", textAlign:"left"}}>
            <input type="date" value={formik.values.EfFrm_Dt} onChange={formik.handleChange} id="EfFrm_Dt" className="form-control inp_text col" style={{marginLeft:12,marginRight:0}}/>
            <div className="col-auto" style={{paddingTop:5,paddingRight:5,paddingLeft:5}}>to</div> 
            <input type="date" value={formik.values.EfTo_Dt} onChange={formik.handleChange} id="EfTo_Dt" className="form-control inp_text col" />
            </div>
        </div>
        </div>
           <div className="form-group" style={{marginBottom:60}}>
           <div>
    <label className="control-label ">End Date Range</label>
        </div>
            <div class="row"style={{width:"69.3%",float:"left", textAlign:"left"}}>
            <input type="date" value={formik.values.EdFrm_Dt} onChange={formik.handleChange} id="EdFrm_Dt" className="form-control inp_text col" style={{marginLeft:12,marginRight:0}}/>
            <div className="col-auto" style={{paddingTop:5,paddingRight:5,paddingLeft:5}}>to</div> 
            <input type="date" value={formik.values.EdTo_Dt} onChange={formik.handleChange} id="EdTo_Dt" className="form-control inp_text col" />
            </div>
           </div>

           <div style={{textAlign:"center"}}>
          
        <button type="reset" className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20,  marginBottom:20}} 
        onClick={()=>{
          formik.resetForm();
          seterrmg("")
        }}>Clear</button>
         <button type= "submit" onClick={formik.handleSubmit} className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20, marginBottom:20, backgroundColor:"#0dcaf0", border:"1px solid #0dcaf0"}}>Search </button>
        {errmsg.length>0 && <div style={{color:"red", fontWeight:"bold"}}>{errmsg}</div>}
        </div>
</form>
</div>

<div className="content">
              <h4>Search History</h4>
              <div className="card btm">
            <DataTable value={li} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                    selectionMode="single" selection={selected} onSelectionChange={(e) => setselected(e.value)} dataKey="searcH_ID" metaKeySelection={false}>
                <Column field="cspI_ID" header="Plan Id" ></Column>
                <Column field="pdpD_ID" header="Product Id" ></Column>
                <Column field="lob" header="Line of Bussiness" ></Column>
                <Column field="grgR_ID" header="Group Id" ></Column>
                <Column field="efF_FROM_DTs" header="From Date (Effective)" ></Column>
                <Column field="efF_TO_DTs" header="To Date (Effective)" ></Column>
                <Column field="enD_FROM_DTs" header="From Date (End)" ></Column>
                <Column field="enD_TO_DTs" header="To Date (End)" ></Column>
            </DataTable>
        </div>
            </div>
        </div>
    )
  }
  else if(Page==="BnFt_search"){
  return(
    <>
    <BenifitSearch sendToParent={getChildData} data={BnftData} />
    </>
  )
  }
}


function returnData(val){
  console.log(val[1])
  return(val[1])
}

function formatDate(inputDate) {
  if(inputDate!=="" && inputDate!=null){
  const dateComponents = inputDate.split('-');
  const formattedDate = `${dateComponents[2]}-${dateComponents[1]}-${dateComponents[0]}`;
  return formattedDate;
}
else{
return null
}
 }

 function dateDiffInDays(a, b) {
  const _MS_PER_DAY = 1000 * 60 * 60 * 24;
  // Discard the time and time-zone information.
  var aa=new Date(a), bb=new Date(b)
  const utc1 = Date.UTC(aa.getFullYear(), aa.getMonth(), aa.getDate());
  const utc2 = Date.UTC(bb.getFullYear(), bb.getMonth(), bb.getDate());

  const res = Math.floor((utc2 - utc1) / _MS_PER_DAY);
  if(res >= 0 ){
    if(res > 366 ){
      return("F");
    }
    else{return("T")}
  }
  else if(res<0){return("G")}
}



export default Benifits;