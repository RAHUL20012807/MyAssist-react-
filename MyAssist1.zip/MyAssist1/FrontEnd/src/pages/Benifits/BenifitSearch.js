import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog'
import React, { useState} from "react";
import invoke from "../../api";
import {useNavigate} from "react-router-dom"



function BenifitSearch(props){
    const navigate = useNavigate();
    console.log(props.data);
    var BNFTDetails=props.data;

    const paginatorLeft = <Button type="button" icon="pi pi-refresh" text />;
    const paginatorRight = <Button type="button" icon="pi pi-download" text />;

    const [onclickBNFT, setOnclickBNFT]=useState(null);
const [visible, setVisible] = useState(false);
const [onclickview, setonClickView]=useState([]);
const [visible1, setVisible1] = useState(false);

const footerContent = (
    <div>
        
        <Button label="close"  onClick={() => setVisible(false)} autoFocus />
    </div>
);


return(
    <>
    <div className="MainArea">
        <div className="content ">
        <div className="row">
        <h4 className="col">Benifit Search</h4>
                 <div className="col" style={{textAlign:"right"}}>
                   <button className="btn btn-primary"  onClick={()=>props.sendToParent("Bnft_Form")}> Back</button>
                 </div></div>

                 <DataTable value={BNFTDetails} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                    cellSelection selectionMode="single" dataKey="searcH_ID" metaKeySelection={false}> 
                    {/* selectionMode="single" selection={data_selected} onSelectionChange={(e) => setData_selected(e.value)}   dataKey="userId" metaKeySelection={false}> */}
                    <Column field="pdpD_ID" header="Product ID"
                    body={row => <button style={{border:"1px white solid", backgroundColor:"white"}}onClick={() =>{
                       console.log(row.pdpD_ID)
                       var payload={
                        "cspI_ID": "",
                        "pdpD_ID": row.pdpD_ID,
                        "grgR_ID": "",
                        "cspI_EFF_DT": "",
                        "cspI_TERM_DT": "",
                        "pldS_DESC": "",
                        "cspD_CAT": "",
                        "pddS_MCTR_BCAT": "",
                        "accounT_NO": 0,
                        "relation": "",
                        "accumulator_Name": "",
                        "acC_AMT1": 0,
                        "acC_AMT2": 0,
                        "benefits_Name": "",
                        "pre_Auth_Indicator": "",
                        "limits_Applies_to_Service_or_not": ""  
                       }
                      
                      invoke("api/home/getBenefitDetailDesc", "post", (data, success, status) => {
                        if (success) {
                          if(status===200){
                        setOnclickBNFT(data[1]);
                          setVisible(true);
                          }
                        } 
                         console.log(onclickBNFT);
                      },payload);

                      }} >{row.pdpD_ID}</button>} 
                      ></Column>


                <Column field="pdpD_ID" header="Plan Id"></Column>
                <Column field="grgR_ID" header="Group ID"
                 body={row => <button style={{border:"1px white solid", backgroundColor:"white"}} 
                onClick={()=>{navigate("/nav/member",  { state: { subscriber_Id:"", Group_ID:row.grgR_ID, SubGroup_ID:"" } })}}
                >{row.grgR_ID}</button>}></Column>
                <Column field="cspI_EFF_DT" header="Effective Date"></Column>
                <Column field="cspI_TERM_DT" header="End Date"></Column>
                <Column field="pldS_DESC" header="Plan Description"></Column>
                <Column header="Product Category" body={row =>get_catrgy(row.cspD_CAT)}></Column>
                <Column field="pddS_MCTR_BCAT" header="Line of Bussiness"></Column>
            </DataTable>

                  
                  </div>
                  {visible && 
      
      <div className="content">
                   <DataTable value={onclickBNFT} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                   selectionMode="single"  dataKey="searcH_ID" metaKeySelection={false}>
               <Column  header="Accumlator Name" body={(rowData) => get_Acc_Name(rowData.acC_AMT2)}></Column>
               <Column field="acC_AMT1" header="Accumlator Ammount(Individual)" ></Column>
               <Column field="acC_AMT2" header="Accumlator Ammount(Family)" ></Column>
               <Column  header="View Details" body={row => <button className="btn btn-primary" onClick={()=>{setVisible1(true); var viewlist=[row]; setonClickView(viewlist)}}>view</button>} ></Column> 
           </DataTable>
           <Dialog header="Provider Details" visible={visible1} position={"top"} style={{ width: '80vw' }} onHide={() => setVisible1(false)} footer={footerContent} draggable={false} resizable={true}>
               
               {onclickview.map((i) => (
                 <table style={{width:"100%"}}>
                 <tr className="row" style={{height:50}}>
                   <th className="col">Accumlator Name</th>
                   <td className="col">:{get_Acc_Name(i.acC_AMT2)}</td>
                   <th className="col">Accumlator Amount(Individual)</th>
                   <td className="col">: {i.acC_AMT1}  </td>                   
                 </tr>

                 <tr className="row" style={{height:50}}>
                   <th className="col">Accumlator Amount(Family)</th>
                   <td className="col">:{i.acC_AMT2}</td>
                   <th className="col">Benifits Names</th>
                   <td className="col">:{i.benefits_Name}</td>                 
                 </tr>

                 <tr className="row" style={{height:50}}>
                   <th className="col">Pre Auth Indicator</th>
                   <td className="col">:{i.pre_Auth_Indicator}</td>
                   <th className="col">Limits Apply to Service or Not</th>
                   <td className="col">:{i.Limits_Applies_to_Service_or_not}</td>
                 </tr>

                 
                 </table>
                  ))} 
               
           </Dialog>
         </div>
         }
        </div>
    
    </>
)
}


function get_Acc_Name(val){
  if(val>0){
    return("Member & Family Accumlator")
  }
  else{
    return("Member Accumlator ")
  }

}


function get_catrgy(catgry){
  if(catgry==="D"){
    return("Dental")
  }
}

export default BenifitSearch; 