


function Sales(){



    return(
        <div className="MainArea">
            <div className="content">
              
              <form noValidate className="form  form-multiline" id="myForm" >
                
    <div className="row">
        <div className="form-group col">
        <label className="control-label ">Population (Large Group)</label>
        <input type="text" className="form-control " id="claim_id"  placeholder="Large Group"></input>
        </div>

        <div className="form-group col">
        <label className="control-label ">Population (Small group)</label>
        <input type="text" className="form-control " id="autherization_id" placeholder="Small Grop" ></input>
        </div>
        
        <div className="form-group col">
        <label className="control-label ">Population(ASO)</label>
        <input type="text" className="form-control " id="autherization_id" placeholder="ASO" ></input>
        </div>

        </div>


        <div className="row">
        <div className="form-group col-lg-4">
        <label className="control-label ">Renewal Date</label>
        <input type="date" className="form-control " id="claim_id"  placeholder="Renewal Date"></input>
        </div>

        <div className="form-group col-lg-4">
        <label className="control-label ">Line of Bussiness</label>
        <input type="text" className="form-control " id="autherization_id" placeholder="Small Grop" ></input>
        </div>
        </div>

        <div style={{textAlign:"center", marginTop:30}}>
        <button type="reset" className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20,  marginBottom:20}}>Clear</button>
        <button className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20, marginBottom:20, backgroundColor:"#0dcaf0", border:"1px solid #0dcaf0"}}>Search </button>
        </div>

        </form>
        </div>
        </div>
    )
}
export default Sales;