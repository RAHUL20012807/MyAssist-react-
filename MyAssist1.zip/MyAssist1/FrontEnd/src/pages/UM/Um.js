import React, { useState, useEffect,useRef } from "react";
import { Radio } from 'antd';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import invoke from "../../api";
import UmDetails from "./UmDetails";
import { useFormik } from "formik";
import { Toast } from "primereact/toast";

function Um(){

    

    const [selected, setselected] = useState(null);
    const [Umdetails, setUmdetails] = useState(null);
    const [Page, setPage] = useState("Um_Form")
    const [errmsg, seterrmg]= useState("");

    var [li,setli]=useState([]);
    const toast = useRef(null);
 
    var id=sessionStorage.getItem("UserId");
    useEffect(() => {
      invoke("api/home/getUMSrch/"+id, "get", (data, success, status) => {
        if (success) {
          if (status === 200) {
            console.log(data[1])
            var lst=return_data(data)
            setli(lst)
          }
        } 
      })
    },[])




    useEffect(() => {
      if (selected) {
        var i=selected;
        console.log(i);
        formik.setFieldValue("umId",i.uM_ID);
        formik.setFieldValue("MemberId",i.memE_ID);
        formik.setFieldValue("status",i.status);
        formik.setFieldValue("UM_Type",i.uM_TYPE);
        formik.setFieldValue("service_type",i.srvC_TYPES);
        formik.setFieldValue("Provider_Npi",i.prpR_NPI);
        formik.setFieldValue("Requesting_Npi",i.reQ_NPI);
        formik.setFieldValue("Servicing_Npi",i.srvC_NPI);
        formik.setFieldValue("Strt_Dt",formatDate(i.starT_DTs));
        formik.setFieldValue("End_DT",formatDate(i.enD_DTs));
        formik.setFieldValue("valueDR",i.dtrnG_TYPE);
      }
    }, [selected]);
const formik = useFormik({
  initialValues: {
    valueDR:"",
    umId:"",
    MemberId:"",
    status:"",
    UM_Type:"",
    service_type:"",
    Provider_Npi:"",
    Requesting_Npi:"",
    Servicing_Npi:"",
    Strt_Dt:"",
    End_DT:null
  },
  onSubmit: (values) => {

    const val=
    {
      "useR_ID": sessionStorage.getItem("UserId"),
      "searcH_ID": 0,
      "memE_ID": values.MemberId,
      "uM_ID": values.umId,
      "dtrnG_TYPE": values.valueDR,
      "status": values.status,
      "uM_TYPE": values.UM_Type,
      "srvC_TYPES": values.service_type,
      "prpR_NPI": values.Provider_Npi,
      "reQ_NPI": values.Requesting_Npi,
      "srvC_NPI": values.Servicing_Npi,
      "starT_DT": values.Strt_Dt,
      "enD_DT": values.End_DT,
      "starT_DTs": "",
      "enD_DTs": ""
    }
    if(values.valueDR==="" && values.umId==="" && values.MemberId==="" && values.status==="" && values.UM_Type==="" && values.service_type==="" && values.Provider_Npi==="" && values.Requesting_Npi==="" && values.Servicing_Npi==="" && values.Servicing_Npi==="" && values.Strt_Dt===null && values.End_DT===null){
      seterrmg("Please enter the values");
tst("err", "Please enter the values")   
  }
     else if (values.umId !== "") {
      srch();
    }
    else{
      if ((values.valueDR !== "")) {
        if ((values.Strt_Dt === "") && (values.End_DT === "")) {
            seterrmg( "Please enter date range");
             tst("err","Please enter date range");
        }
        else if (((values.Strt_Dt === "") && (values.End_DT !== "")) || ((values.Strt_Dt !== "") && (values.End_DT === ""))) {
            seterrmg("Please enter both dates");
            tst("err","Please enter both dates")
        }else
        {
                var res = dateDiffInDays(values.Strt_Dt, values.End_DT);
                if (res === "F") {
              seterrmg( "Date range must be maximum of one year");
              tst("err","Date range must be maximum of one year");
                } else if (res === "G") {
                seterrmg("Start date must be greater than end date");
                tst("err","Start date must be greater than end date");
                } else if (res === "T") {
                 srch();
                }
        }
    } else {
        seterrmg( "Please select a date range");
        tst("err", "Please select a date range");
    }
    }
   

    function srch(){
      invoke(
        "api/Home/getUM",
        "post",
        (data, success, status) => {
          if (success) {
            if (status === 200) {
              if(data[1].length>0){
                console.log(data[1]);
                 setUmdetails(data[1]);
                
                invoke("api/home/insertUMSrch", "put", (data, success, status) => {
                  if (success) { 
                   console.log("done");
                  } 
                },val);
                var val1={
                  "useR_ID": sessionStorage.getItem("UserId"),
    "searcH_ID": 0,
    "memE_ID":values.MemberId,
    "uM_ID": values.umId,
    "dtrnG_TYPE":values.valueDR,
    "status": values.status,
    "uM_TYPE": values.UM_Type,
    "srvC_TYPES": values.service_type,
    "prpR_NPI": values.Provider_Npi,
    "reQ_NPI": values.Requesting_Npi,
    "srvC_NPI": values.Servicing_Npi,
    "starT_DT": values.Strt_Dt,
    "enD_DT": values.End_DT,
    "starT_DTs":values.Strt_Dt ,
    "enD_DTs": values.End_DT
                }
                var UpdatedList=[val1,...li]
                        setli(UpdatedList)
                setPage("Details_Page");
              } 
              else{
                seterrmg("Data Not Found");
                tst("err","Data Not Found")
              } 
            }
          }
        }
        , val)
     }

  }

})

function tst(type, message){
if(type==="err"){
  toast.current.show({ severity: "error", summary: "Error", detail:message, life: 3000 });
}
}


useEffect(()=>{
  if(formik.values.umId.length>0){
    formik.setFieldValue("MemberId","");
    formik.setFieldValue("status","");
    formik.setFieldValue("UM_Type","");
    formik.setFieldValue("service_type","");
    formik.setFieldValue("Provider_Npi","");
    formik.setFieldValue("Requesting_Npi","");
    formik.setFieldValue("Servicing_Npi","");
    formik.setFieldValue("Strt_Dt",null);
    formik.setFieldValue("End_DT",null);
    formik.setFieldValue("valueDR","");
  }  
},[formik.values.umId])


    const getChildData=(val) =>{
      console.log(val)
      setPage(val);
    }

if(Page==="Um_Form"){
    return(
        <div className="MainArea">
            <div className="content">
            <Toast ref={toast} />
              <form noValidate className="form  form-multiline" onSubmit={formik.handleSubmit}>
                
    <div className="row">
        <div className="form-group col">
        <label className="control-label ">UM Id</label>
        <input type="text" className="form-control" value={formik.values.umId} onChange={formik.handleChange} id="umId" placeholder="UM Id"></input>
        </div>

        <div className="form-group col">
        <label className="control-label ">Member Id</label>
        <input type="text" className="form-control" value={formik.values.MemberId} onChange={formik.handleChange} id="MemberId" placeholder="Member Id"
        disabled={formik.values.umId.length>0?true:false}></input>
        </div>

        <div className="form-group col">
        <label className="control-label ">Status</label>
        <select className="form-control inp_text " value={formik.values.status} onChange={formik.handleChange} placeholder="select" 
        disabled={formik.values.umId.length>0?true:false} name="Status" id="status"> 
        <option value="">Select </option>
          <option value="CL">Void (closed)</option>
          <option value="CO">Completed</option>
          <option value="DS">Disallowed Service</option>
          <option value="UP">Pend</option>
          <option value="IN">Pend with errors</option>
          <option value="LG">Logged</option>
          <option value="PD">Predetermination(2.8)</option>
          </select>
        </div>

        <div className="form-group col">
        <label className="control-label ">UM Type</label>
        <select className="form-control inp_text " value={formik.values.UM_Type} onChange={formik.handleChange} placeholder="select" 
        disabled={formik.values.umId.length>0?true:false} name="Status" id="UM_Type"> 
          <option value="">Select </option>
          <option value="A">Admission</option>
          <option value="R">Reffral</option>
          <option value="S">Service</option>
        </select>
        </div>
        </div>

        <div className="row">
        
        <div className="form-group col">
        <label className="control-label ">Service Type</label>
        <input type="text" className="form-control " value={formik.values.service_type} onChange={formik.handleChange} id="service_type" 
        disabled={formik.values.umId.length>0?true:false} placeholder="Service Type"></input>
        </div>

        <div className="form-group col">
        <label className="control-label ">Provider NPI</label>
        <input type="text" className="form-control " value={formik.values.Provider_Npi} onChange={formik.handleChange} id="Provider_Npi" 
        disabled={formik.values.umId.length>0?true:false} placeholder="Provider NPI"></input>
        </div>  

        <div className="form-group col-lg-3">
        <label className="control-label ">Requesting NPI</label>
        <input type="text" className="form-control " value={formik.values.Requesting_Npi} onChange={formik.handleChange} id="Requesting NPI" 
        disabled={formik.values.umId.length>0?true:false} placeholder="Requesting NPI"></input>
        </div>

        <div className="form-group col-lg-3">
        <label className="control-label ">Servicing NPI</label>
        <input type="text" className="form-control " value={formik.values.Servicing_Npi} onChange={formik.handleChange} id="Servicing_Npi"
        disabled={formik.values.umId.length>0?true:false} placeholder="Servicing NPI"></input>
        </div>  
        </div>


 <div className="card flex  col-lg-6" style={{marginTop:20,padding:20}}>
                <Radio.Group onChange={formik.handleChange} value={formik.values.valueDR} id="valueDR" name="valueDR" className="row" disabled={formik.values.umId.length>0?true:false} >
                   <Radio className="col" value="C">Create Date</Radio>
                   <Radio className="col" value="R">Request Date</Radio>
                   <Radio className="col" value="S">Service Date</Radio>
                </Radio.Group>
                <div style={{paddingTop:10, margin:"auto"}}>
            <div className="row justify-content-md" style={{paddingTop:10, textAlign:"center"}}>
               <div className="col-auto " style={{paddingTop:5}}>
                 Date Range:
              </div>
            <div class="col row"style={{width:"auto"}}>
            <input type="date" className="form-control inp_text col" id="Strt_Dt" value={formik.values.Strt_Dt} onChange={formik.handleChange} disabled={formik.values.umId.length>0?true:false}/>
            <div className="col-auto">to</div> <input type="date" className="form-control inp_text col" value={formik.values.End_DT} id="End_DT" onChange={formik.handleChange} disabled={formik.values.umId.length>0?true:false}/>
            </div>
           </div>
            </div>
                </div>

        
        <div style={{textAlign:"center"}}>
        <button type="reset" className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20,  marginBottom:20}} onClick={()=>{
          formik.resetForm();
          seterrmg("");
        }}>Clear</button>
        <button type= "submit" onClick={formik.handleSubmit} className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20, marginBottom:20, backgroundColor:"#0dcaf0", border:"1px solid #0dcaf0"}}>Search </button>

        {errmsg.length>0 && <div style={{color:"red", fontWeight:"bold"}}>{errmsg}</div>}
        </div>
</form>
</div>


<div className="content btm">
              <h4>Search History</h4>
<div className="card">
            <DataTable value={li} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                    selectionMode="single" selection={selected} onSelectionChange={(e) => setselected(e.value)} dataKey="searcH_ID" metaKeySelection={false}>

                <Column field="uM_ID" header="UM Id" ></Column>
                <Column header="Member ID" field="memE_ID"></Column> 
                <Column  header="Date Range" field="dtrnG_TYPE" body={(rowData)=>get_type(rowData.dtrnG_TYPE)}></Column>
                <Column field="starT_DTs" header="State Date" ></Column>
                <Column  header="End Date" field="enD_DTs"></Column>
                <Column field="status" header="Status" ></Column>
                <Column field="uM_TYPE" header="UM Type" ></Column>
                <Column field="srvC_TYPES" header="Service Type" ></Column>
                
            </DataTable>
        </div>
            </div>
        </div>
    )
}
else if(Page==="Details_Page"){
  return(
    <div>
  <UmDetails sendToParent={getChildData} data={Umdetails}/>
  </div>
  )
}
}

function return_data(val){
  return(val[1])
}

function get_type(val){
if(val==="C"){
  return("Create Date")
}
else if(val==="R"){return("Request Date")}
else if(val==="s"){return("Service Date")}
}

function formatDate(inputDate) {
if(inputDate){
  const dateComponents = inputDate.split('-');
  const formattedDate = `${dateComponents[2]}-${dateComponents[1]}-${dateComponents[0]}`;
  return formattedDate;
}
else{
  return(null);
}

 }

 function dateDiffInDays(a, b) {
  const _MS_PER_DAY = 1000 * 60 * 60 * 24;
  // Discard the time and time-zone information.
  var aa=new Date(a), bb=new Date(b)
  const utc1 = Date.UTC(aa.getFullYear(), aa.getMonth(), aa.getDate());
  const utc2 = Date.UTC(bb.getFullYear(), bb.getMonth(), bb.getDate());

  const res = Math.floor((utc2 - utc1) / _MS_PER_DAY);
  if(res >= 0 ){
    if(res > 366 ){
      return("F");
    }
    else{return("T")}
  }
  else if(res<0){return("G")}
}


export default Um;