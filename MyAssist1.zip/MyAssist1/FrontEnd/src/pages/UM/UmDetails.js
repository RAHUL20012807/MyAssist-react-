import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog'
import React, { useState} from "react";
import invoke from "../../api";





function UmDetails(props){


    console.log(props.data);
    var UMDetails=props.data;

    const paginatorLeft = <Button type="button" icon="pi pi-refresh" text />;
    const paginatorRight = <Button type="button" icon="pi pi-download" text />;


    const [onclickUM, setOnclickUM]=useState(null);
const [visible, setVisible] = useState(false);
const [onclickview, setonClickView]=useState([]);
const [visible1, setVisible1] = useState(false);

const footerContent = (
    <div>
        <Button label="Close"  onClick={() =>{ setVisible(false)}} autoFocus />
    </div> )

    return(
<div className="MainArea">
            <div className="content">
            <div className="row">
                  <h4 className="col">UM Search</h4>
                 <div className="col" style={{textAlign:"right"}}>
                   <button className="btn btn-primary"  onClick={()=>props.sendToParent("Um_Form")}> Back</button></div>
                  </div>

                  <DataTable value={UMDetails} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }}
                    paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink"
                    currentPageReportTemplate="{first} to {last} of {totalRecords}" paginatorLeft={paginatorLeft} paginatorRight={paginatorRight}
                    cellSelection selectionMode="single" dataKey="searcH_ID" metaKeySelection={false}> 
                    <Column field="umuM_REF_ID" header="UM ID" body={row => <button style={{border:"1px white solid", backgroundColor:"white"}}onClick={() =>{
                      console.log(row.umuM_REF_ID)
                      var payload={
                        
                            "umuM_REF_ID": row.umuM_REF_ID,
                            "umsV_RECD_DT": "",
                            "umsV_FROM_DT": "",
                            "umsV_PRPR_ID_REQ": "",
                            "umsV_PRPR_ID_SVC": "",
                            "umvT_STS": "",
                            "reF_TYPE": "",
                            "clcL_ID": "",
                            "requesteD_UNITS": 0,
                            "authorizatioN_UNITS": 0,
                            "authorizatioN_DT": "",
                            "procedurE_CODE": "",
                            "diagnosiS_CODE": "",
                            "servicE_TYPE": "",
                            "authorizatioN_HISTORY": "",
                            "uM_STATUS": "",
                            "sbsB_ID": ""
                          
                      }
                      
                      invoke("api/home/getUMDetailDesc", "post", (data, success, status) => {
                        if (success) {
                          if(status===200){
                        setOnclickUM(data[1]);
                          setVisible(true);
                          }
                        } 
                         console.log(onclickUM);
                      },payload);

                      }} >{row.umuM_REF_ID}</button>} ></Column>


                <Column field="umsV_RECD_DT" header="Requested Date" ></Column>
                <Column field="umsV_FROM_DT" header="Service Date" ></Column>
                <Column field="umsV_PRPR_ID_REQ" header="Requesting NPI" ></Column>
                <Column field="umsV_PRPR_ID_SVC" header="Servicing NPI" ></Column>
                <Column field="clcL_ID" header="Claim ID" ></Column>
                <Column field="umvT_STS" header="Status" ></Column>
                <Column field="reF_TYPE" header="UM Type" ></Column>
            </DataTable>

                </div>
                {visible && 
      
      <div className="content">
                   <DataTable value={onclickUM} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }}
                   paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink"
                   currentPageReportTemplate="{first} to {last} of {totalRecords}" paginatorLeft={paginatorLeft} paginatorRight={paginatorRight}
                   selectionMode="single"  dataKey="searcH_ID" metaKeySelection={false}>
               <Column field="requesteD_UNITS" header="Requested Units" ></Column>
               <Column field="authorizatioN_UNITS" header="Autherized Units" ></Column>
               <Column field="authorizatioN_DT" header="Autherized Dates" ></Column>
               <Column  header="View Details" body={row => <button className="btn btn-primary" onClick={()=>{setVisible1(true); var viewlist=[row]; setonClickView(viewlist)}}>view</button>} ></Column> 
           </DataTable>
           <Dialog header="Provider Details" visible={visible1} position={"top"} style={{ width: '80vw' }} onHide={() => setVisible1(false)} footer={footerContent} draggable={false} resizable={true}>
               
               {onclickview.map((i) => (
                 <table style={{width:"100%"}}>
                 <tr className="row" style={{height:50}}>
                   <th className="col">UM ID</th>
                   <td className="col">:{i.umuM_REF_ID}</td>
                   <th className="col">Requested Units</th>
                   <td className="col">: {i.requesteD_UNITS}  </td>                   
                 </tr>

                 <tr className="row" style={{height:50}}>
                   <th className="col">Autherized Units</th>
                   <td className="col">:{i.authorizatioN_UNITS}</td>
                   <th className="col">Autherized Dates</th>
                   <td className="col">:{i.authorizatioN_DT}</td>                 
                 </tr>

                 <tr className="row" style={{height:50}}>
                   <th className="col">Procedure Code</th>
                   <td className="col">:{i.procedurE_CODE}</td>
                   <th className="col">Diagonasis Code</th>
                   <td className="col">:{i.diagnosiS_CODE}</td>
                 </tr>

                 <tr className="row" style={{height:50}} >
                   <th className="col">Service Type</th>
                   <td className="col">:{i.servicE_TYPE}</td>
                   <th className="col">Status</th>
                   <td className="col">:{i.uM_STATUS}</td>
                 </tr>
                 </table>
                  ))} 
               
           </Dialog>
         </div>
         }
            </div>
    )
}

export default UmDetails;