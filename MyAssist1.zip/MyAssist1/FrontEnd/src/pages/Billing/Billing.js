import React, { useState ,useEffect, useRef} from "react";
import { Radio } from 'antd';
import { useFormik } from "formik";
import invoke from "../../api";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import BillSearch from "./BillSearch";
import { Toast } from "primereact/toast";

 function Billing(){

const [selected, setselected] = useState(null);
const [Page, setPage] = useState("Bill_Form");
const [BillingDetails, setBillingDetails]=useState(null);
const [isvalid, setisvalid]=useState("false");
const [errmsg, seterrmg]= useState("");
    var [li,setli]=useState([]);

    const toast = useRef(null);

    var id=sessionStorage.getItem("UserId");
    useEffect(() => {
      invoke("api/home/getBILLSrch/"+id, "get", (data, success, status) => {
        if (success) {
          if (status === 200) {
            console.log(data[1])
            var lst=return_data(data)
            setli(lst)
          }
        } 
      })
    },[])


useEffect(() => {
  if (selected) {
    const i = selected;
    formik.setFieldValue("invoice_id", i.invoicE_ID);
    formik.setFieldValue("value", i.gsM_TYPE);
    formik.setFieldValue("value1", i.dT_TYPE);
    formik.setFieldValue("gsM_value", i.gsM_VAL);
    formik.setFieldValue("Srtdate", formatDate(i.strT_DTs));
    formik.setFieldValue("Enddate", formatDate(i.enD_DTs));
    formik.setFieldValue("State_value", i.entitY_TYPE);
  }
}, [selected]);



const formik = useFormik({
  initialValues: {
    invoice_id: "",
    value: "",
    value1: "",
    gsM_value: "",
    Srtdate: null,
    Enddate: null,
    State_value: null,
  },


  onSubmit: (values) => {
    if (values.invoice_id === "" && values.Enddate === null && values.Srtdate===null && values.State_value === null 
    && values.gsM_value==="" && values.value==="" && values.value1==="") {
      // alert("Please enter the data");
      seterrmg("Please enter the data");
      toast.current.show({ severity: "error", summary: "Error", detail: "Please enter the data", life: 3000 });
    }
    else if(values.invoice_id!=""){
      setisvalid(true)
      srch();
    }
    else if(values.value!=""){
      if(values.gsM_value!=""){
        if(values.value1!=""){
          if(values.Srtdate===null||values.Enddate===null){
            toast.current.show({ severity: "error", summary: "Error", detail: "Enter Date Range", life: 3000 });
            seterrmg("Enter Date Range")
          }
          else{
            const res= dateDiffInDays(values.Srtdate, values.Enddate);
             if(res==="F"){
              toast.current.show({ severity: "error", summary: "Error", detail: "Date range should be less than 1 year ", life: 3000 });
              seterrmg("Date range should be less than 1 year ")
             }
             else if(res==="G"){
              seterrmg("Start date must be greater than end date");
              toast.current.show({ severity: "error", summary: "Error", detail: "Start date must be greater than end date", life: 3000 });
             }
             else if(res==="T"){
              if(values.State_value.trim()===""){
                // setisvalid("true")
                // console.log(isvalid)
                seterrmg("")
                srch();
              }
              else if(values.State_value!=""){
                if(values.State_value==="RF"||values.State_value==="SE"||values.State_value==="CB"){
                  if(values.value1==="BC"){
                
                    seterrmg("")
                    srch();
                  }
                  else{
                    seterrmg("Please select Bill Created date range");
                    toast.current.show({ severity: "error", summary: "Error", detail: "Please select Bill Created date range", life: 3000 });
                  }
                }
                else if(values.State_value==="RB"){
                  if(values.State_value=="BD"){
                    setisvalid(true)
                    seterrmg("")
                    srch();
                  }
                  else {
                    seterrmg("Please select Bill Due date range");
                    toast.current.show({ severity: "error", summary: "Error", detail: "Please select Bill Due date range", life: 3000 });
                    // alert("Please select Bill Due date range");
                  }
                }
              }
             }
          }
        }else{
          seterrmg("Please enter Date ranges")
          toast.current.show({ severity: "error", summary: "Error", detail: "Please enter Date ranges", life: 3000 });
          // alert("Please enter Date ranges")
        }
      }else{
        seterrmg("Please enter value")
        toast.current.show({ severity: "error", summary: "Error", detail: "Please enter value", life: 3000 });
      }
    }
    else if (values.value!= "") {
      seterrmg("Please select Group Id/Subgroup Id/Member Id and Date range");
      toast.current.show({ severity: "error", summary: "Error", detail:"Please select Group Id/Subgroup Id/Member Id and Date range", life: 3000 });
    }
    else if(values.value1!=""){
      if(values.Srtdate===null||values.Enddate===null){
        seterrmg("Enter Date Range");
        toast.current.show({ severity: "error", summary: "Error", detail:"Enter Date Range", life: 3000 });
      }
      else{
        const res= dateDiffInDays(values.Srtdate, values.Enddate);
         if(res==="F"){
          seterrmg("Date range should be less than 1 year ");
          toast.current.show({ severity: "error", summary: "Error", detail:"Date range should be less than 1 year ", life: 3000 });
         }
         else if(res==="G"){
          seterrmg("Start date must be greater than end date");
          toast.current.show({ severity: "error", summary: "Error", detail:"Start date must be greater than end date", life: 3000 });
         }
         else if(res==="T"){
          if(values.State_value!=""){
            if(values.State_value==="RB"){
              if(values.value1==="BD"){
                setisvalid(true);
                seterrmg("");
                srch();
              }
              else{
                seterrmg("Please select Bill Debited date range");
                toast.current.show({ severity: "error", summary: "Error", detail:"Please select Group Id/Subgroup Id/Member Id and Date range", life: 3000 });
              }
            }
            else {
              if(values.value1==="BC"){
                // setisvalid(true)
                seterrmg("")
                srch();
              }
              else{
                seterrmg("Please select Bill Debited date range");
                toast.current.show({ severity: "error", summary: "Error", detail:"Please select Bill Debited date range", life: 3000 });
              }
            }
          }else{
            seterrmg( "Please select Group Id/Subgroup Id/Member Id or State")
            toast.current.show({ severity: "error", summary: "Error", detail:"Please select Group Id/Subgroup Id/Member Id or State", life: 3000 });
          }
         }
      }
    }
    else if ((values.Srtdate != "") || (values.Enddate != "")) {
      seterrmg("Please enter required values");
      toast.current.show({ severity: "error", summary: "Error", detail:"Please enter required values", life: 3000 });
  }
else if(values.value===""){
  seterrmg("Please select Group Id/Subgroup Id/Member Id and Date range");
  toast.current.show({ severity: "error", summary: "Error", detail:"Please select Group Id/Subgroup Id/Member Id and Date range", life: 3000 });
}
    
function srch() {
      {

        var val={

          "invoicE_ID": values.invoice_id,
          "useR_ID": sessionStorage.getItem("UserId"),
          "searcH_ID": 0,
          "grgR_ID": "",
          "gsM_TYPE": values.value,
          "gsM_VAL": values.gsM_value,
          "dT_TYPE": values.value1,
          "entitY_TYPE": values.State_value,
          "strT_DT": values.Srtdate,
          "enD_DT": values.Enddate,
          "strT_DTs": "",
          "enD_DTs": ""

      }
          invoke(
  "api/Home/getBillings",
  "post",
  (data, success, status) => {
    if (success) {
      if (status === 200) {
        if(data[1].length>0){
          console.log(data[1]);
          setBillingDetails(data[1]);
           invoke("api/Home/insertBILLSrch","put",(data, success, status) => {
            console.log("done");
           },val)
           var val1={

            "invoicE_ID": values.invoice_id,
            "useR_ID": sessionStorage.getItem("UserId"),
            "searcH_ID": 0,
            "grgR_ID": "",
            "gsM_TYPE": values.value,
            "gsM_VAL": values.gsM_value,
            "dT_TYPE": values.value1,
            "entitY_TYPE": values.State_value,
            "strT_DT": values.Srtdate,
            "enD_DT": values.Enddate,
            "strT_DTs": formatDate(values.Srtdate),
            "enD_DTs": formatDate(values.Enddate)
        
        }
           var UpdatedList=[val1,...li]
           setli(UpdatedList)
   setPage("Details_Page");
   toast.current.show({ severity: "success", summary: "Success", detail: "search succesfull", life: 3000 });

        }
        else{
          toast.current.show({ severity: "error", summary: "Error", detail:"Data not found", life: 3000 });
          seterrmg("Data Not found");
          
        } 
      }
    }
  }
  , val)
      }
    }
  },
});


const getChildData=(val) =>{
  console.log(val)
  setPage(val);
}



if(Page==="Bill_Form"){
    return(
        <div className="MainArea">
            <div className="content">
            <Toast ref={toast} />
              <form noValidate className="form  form-multiline" id="myForm" onSubmit={formik.handleSubmit}>
                
    <div className="row">
        <div className="form-group col-lg-6" style={{width:"47.5%"}}>
        <label className="control-label ">Invoice Id</label>
        <input type="text" className="form-control " id="invoice_id"   placeholder="Invoice Id" value={formik.values.invoice_id} onChange={formik.handleChange}></input>

        </div>
      
        <div className="form-group col-lg-6" >
        <label className="control-label ">State</label>
        <select className="form-control inp_text " value={formik.values.State_value} name="State_value" id="State_value" onChange={formik.handleChange}>               
          <option value="">Select </option>
          <option value="RF">Refund</option>
          <option value="SE">Suspend Entities</option>
          <option value="CB">Close Out Bills</option>
          <option value="RB">Rebills</option>
        </select>
      </div>
        </div>


      <div className="row" >
                
    <div className="card flex col-lg-6" style={{marginTop:20,marginRight:30,padding:20, marginLeft:15, width:"45%"}}>
                <Radio.Group onChange={formik.handleChange} value={formik.values.value} id="value" name="value" >
                   <Radio className="col" value="M" style={{width:"30%"}}>Member Id</Radio>
                   <Radio className="col" value="G" style={{width:"30%"}}>Group Id</Radio>
                   <Radio className="col" value="S" style={{width:"30%"}}>Subgroup Id</Radio>
                </Radio.Group>
                <div>
                <div className="row" style={{paddingTop:10}}>
                   <div className="col-lg-3 " style={{margin:"auto", paddingLeft:"50px"}}>
                     value:
                  </div>
                <div class="col-lg-8">
                <input type="text" className="form-control inp_text" value={formik.values.gsM_value} onChange={formik.handleChange} id="gsM_value" name="gsM_value" />
                </div>
                </div>
                </div>
                </div>
                
    
                <div className="card flex  col-lg-6" style={{marginTop:20,padding:20}}>
                <Radio.Group onChange={formik.handleChange} value={formik.values.value1} className="row" id="value1" name="value1">
                   <Radio className="col" value="BC">Bill Credited</Radio>
                   <Radio className="col" value="BD">Bill Due</Radio>
                   <Radio className="col" value="PR">Payment Recived</Radio>
                </Radio.Group>
                <div style={{paddingTop:10, margin:"auto"}}>
            <div className="row justify-content-md" style={{paddingTop:10, textAlign:"center"}}>
               <div className="col-auto " style={{paddingTop:5}}>
                 Date Range:
              </div>
            <div class="col row"style={{width:"auto"}}>
            <input type="date" className="form-control inp_text col" value={formik.values.Srtdate} onChange={formik.handleChange} id="Srtdate" name="Srtdate"/>
            
            <div className="col-auto">to</div>
            <input type="date" className="form-control inp_text col" value={formik.values.Enddate} onChange={formik.handleChange} id="Enddate" name="Enddate"/>
            </div>
           </div>
            </div>
                </div>
                </div>

                <div style={{textAlign:"center"}}>
      
<button
            type="reset"
            className="btn btn-primary"
            style={{ width: "15%", marginRight: 10, marginTop: 20, marginBottom: 20 }}
            onClick={() => {
              formik.resetForm();
              seterrmg("");
            }}
          >
            Clear
          </button>
          <button type= "submit" onClick={formik.handleSubmit} className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20, marginBottom:20, backgroundColor:"#0dcaf0", border:"1px solid #0dcaf0"}}>Search </button>
   {errmsg.length>0 && <div style={{color:"red", fontWeight:"bold"}}>{errmsg}</div>}
        </div>
        </form>
            </div>
            <div className="content">
              <h4>Search History</h4>
<div className="card btm">
            <DataTable value={li} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                    selectionMode="single" selection={selected} onSelectionChange={(e) => setselected(e.value)} dataKey="searcH_ID" metaKeySelection={false}>
                <Column field="invoicE_ID" header="Invoice Id" ></Column>
                <Column header="Entity Type" body={(rowData) => get_value(rowData.gsM_TYPE)}></Column> 
                <Column field="gsM_VAL" header="Entity Value" ></Column>
                <Column field="entitY_TYPE" header="State type" ></Column>
                <Column  header="Date Range Type" body={(rowData) => get_value(rowData.dT_TYPE)}></Column>
                <Column field="strT_DTs" header="From Date" ></Column>
                <Column field="enD_DTs" header="End Date" ></Column>
            </DataTable>
        </div>
            </div>
        </div>
    )
      }
      else if(Page==="Details_Page"){
        return(
<div>
              <BillSearch sendToParent={getChildData} data={BillingDetails}/>
              </div>          
        )
      }
}

function return_data(val){
  return(val[1])
}
function get_value(val){
if(val==="G"){ return("Group ID")}
else if(val==="S"){ return("Subroup ID")}
else if(val==="M"){return("Member ID")}
if(val==="BD"){ return("Bill Due")}
else if(val==="BC"){return("Bill Credited")}
else if(val==="PR"){return("Payment Recived")}
}

function formatDate(inputDate) {
 const dateComponents = inputDate.split('-');
 const formattedDate = `${dateComponents[2]}-${dateComponents[1]}-${dateComponents[0]}`;
 return formattedDate;
}

function dateDiffInDays(a, b) {
  const _MS_PER_DAY = 1000 * 60 * 60 * 24;
  // Discard the time and time-zone information.
  var aa=new Date(a), bb=new Date(b)
  const utc1 = Date.UTC(aa.getFullYear(), aa.getMonth(), aa.getDate());
  const utc2 = Date.UTC(bb.getFullYear(), bb.getMonth(), bb.getDate());

  const res = Math.floor((utc2 - utc1) / _MS_PER_DAY);
  if(res >= 0 ){
    if(res > 366 ){
      return("F");
    }
    else{return("T")}
  }
  else if(res<0){return("G")}
}



export default Billing;

