import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog'
import React, { useState ,useEffect} from "react";
import {useNavigate} from "react-router-dom"
import invoke from "../../api";

function BillSearch(props){
const navigate = useNavigate();

console.log(props.data);
var BillingDetails=props.data;


const [onclickBill, setOnclickBill]=useState(null);
const [visible, setVisible] = useState(false);
const [onclickview, setonClickView]=useState([]);
const [visible1, setVisible1] = useState(false);



const paginatorLeft = <Button type="button" icon="pi pi-refresh" text />;
const paginatorRight = <Button type="button" icon="pi pi-download" text />;

const footerContent = (
    <div>
        <Button label="Close"  onClick={() =>{ setVisible(false)}} autoFocus />
    </div> )


    return(
        <div className="MainArea">
        <div className="content">
        <div className="row">
                  <h4 className="col">Search History</h4>
                 <div className="col" style={{textAlign:"right"}}>
                   <button className="btn btn-primary"  onClick={()=>props.sendToParent("Bill_Form")}> Back</button></div>
                  {/* <button className="btn btn-primary"  onClick={()=>props.sendToParent("Bill_Form")}> Back</button></div> */}
                  </div>

                  <DataTable value={BillingDetails} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size="small"
                    cellSelection selectionMode="single" dataKey="searcH_ID" metaKeySelection={false}> 
                    {/* selectionMode="single" selection={data_selected} onSelectionChange={(e) => setData_selected(e.value)}   dataKey="userId" metaKeySelection={false}> */}
                    <Column field="blbL_DUE_DT" header="Due Date" body={row => <button style={{border:"1px white solid", backgroundColor:"white"}}onClick={() =>{
                      console.log(row.blbL_DUE_DT)
                      var payload={
                        "bleI_NET_DUE": 0,
                        "rcpT_AMT": 0,
                        "blbL_BILLED_AMT": 0,
                        "blbL_RCVD_AMT": 0,
                        "bleI_LST_PD_DUE_DT": "",
                        "refunD_DT": "",
                        "bleI_LST_BL_DUE_DT": "",
                        "grgR_ID": "",
                        "grgR_NAME": "",
                        "sgsG_ID": "",
                        "sgsG_NAME": "",
                        "sbsB_ID": "",
                        "susB_NAME": "",
                        "bliV_ID": "",
                        "blbL_CREATE_DTM": "",
                        "blbL_DUE_DT": row.blbL_DUE_DT,
                        "rcpT_ID": "",
                        "bleI_BILL_LEVEL": "",
                        "pldS_DESC": "",
                        "lives": 0,
                        "totalBreakUp": 0,
                        "iniD_OUTSTAND_BAL": 0,
                        "bleI_CK": row.bleI_CK
                      }
                      
                      invoke("api/home/getBillingDetailDesc", "post", (data, success, status) => {
                        if (success) {
                          if(status===200){
                        setOnclickBill(data[1]);
                          setVisible(true);
                          }
                        } 
                         console.log(onclickBill);
                      },payload);

                      }} >{row.blbL_DUE_DT}</button>} ></Column>


                <Column field="grgR_ID" header="Group ID" body={row => <button style={{border:"1px white solid", backgroundColor:"white"}}onClick={() =>{
                      console.log(row.blbL_DUE_DT)
                       navigate("/nav/member",  { state: {subscriber_Id:"", Group_ID: row.grgR_ID, SubGroup_ID: row.sgsG_ID } })
                      }} >{row.grgR_ID}</button>}></Column>


                <Column field="grgR_NAME" header="Group Name" ></Column>

                <Column field="sgsG_ID" header="Sub Group Id" body={row => <button style={{border:"1px white solid", backgroundColor:"white"}}onClick={() =>{
                      console.log(row.blbL_DUE_DT)
                       navigate("/nav/member",  { state: { Group_ID: row.grgR_ID, SubGroup_ID: row.sgsG_ID } })
                      }} >{row.sgsG_ID}</button>}></Column>


                <Column field="sgsG_NAME" header="Sub Group Name" ></Column>
                <Column field="sgsG_NAME" header="Sub Group Name" ></Column>
                <Column field="sbsB_ID" header="Subscriber Id" ></Column>
                <Column field="susB_NAME" header="Subscriber Name" ></Column>
                <Column field="bleI_NET_DUE" header="Net Due" ></Column>
                <Column field="bleI_LST_BL_DUE_DT" header="Last Billed Due" ></Column>
                <Column field="bleI_LST_PD_DUE_DT" header="Last Paid Date" ></Column>
                <Column field="rcpT_AMT" header="Last Paid Amount" ></Column>
            </DataTable>
        </div>


        {visible && 
      
      <div className="content">
                   <DataTable value={onclickBill} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }} size='small'
                   selectionMode="single"  dataKey="searcH_ID" metaKeySelection={false}>
                   {/* selectionMode="single" selection={data_selected} onSelectionChange={(e) => setData_selected(e.value)}   dataKey="userId" metaKeySelection={false}> */}
               <Column field="pldS_DESC" header="Choice" ></Column>
               <Column field="lives" header="Lives" ></Column>
               <Column field="rcpT_ID" header="Receipt Id" ></Column>
               <Column field="strT_DTs" header="View Details" body={row => <button className="btn btn-primary" onClick={()=>{setVisible1(true); var viewlist=[row]; setonClickView(viewlist)}}>view</button>} ></Column> 
           </DataTable>
           <Dialog header="Provider Details" visible={visible1} position={"top"} style={{ width: '80vw' }} onHide={() => setVisible1(false)} footer={footerContent} draggable={false} resizable={true}>
               
               {onclickview.map((i) => (
                 <table style={{width:"100%"}}>
                 <tr className="row" style={{height:50}}>
                   <th className="col">Plan</th>
                   <td className="col">:{i.pldS_DESC}</td>
                   <th className="col">Lives</th>
                   <td className="col">: {i.lives}  </td>                   
                 </tr>

                 <tr className="row" style={{height:50}}>
                   <th className="col">ToTal Break Up</th>
                   <td className="col">:${i.totalBreakUp}</td>
                   <th className="col">Amount</th>
                   <td className="col">:{i.iniD_OUTSTAND_BAL}</td>                 
                 </tr>

                 <tr className="row" style={{height:50}}>
                   <th className="col">Receipt Id</th>
                   <td className="col">:{i.rcpT_ID}</td>
                   <th className="col">Received Amount</th>
                   <td className="col">:{i.rcpT_AMT}</td>
                 </tr>

                 <tr className="row" style={{height:50}} >
                   <th className="col">Invoice Number</th>
                   <td className="col">:{i.bliV_ID}</td>
                   <th className="col">Due Date</th>
                   <td className="col">:{i.blbL_DUE_DT}</td>
                 </tr>
               
                 <tr className="row" style={{height:50}}>
                   <th className="col">Refund Amount</th>
                   <td className="col">:{i.rcpT_AMT}</td>
                   <th className="col">Refund Date</th>
                   <td className="col">:{i.refunD_DT}</td>
                  </tr>
                 </table>
                  ))} 
               
           </Dialog>
         </div>
         }
        </div>
    )

}

export default BillSearch;