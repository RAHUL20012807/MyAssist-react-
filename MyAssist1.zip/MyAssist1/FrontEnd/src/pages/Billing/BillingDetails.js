






function BillingDetails(){

    // val={

    //     "invoicE_ID": invoice_id,
    //     "useR_ID": sessionStorage.getItem("UserId"),
    //     "searcH_ID": 0,
    //     "grgR_ID": "",
    //     "gsM_TYPE": value,
    //     "gsM_VAL": gsM_value,
    //     "dT_TYPE": value1,
    //     "entitY_TYPE": State_value,
    //     "strT_DT": Srtdate,
    //     "enD_DT": Enddate,
    //     "strT_DTs": "",
    //     "enD_DTs": ""
    
    // }

    // console.log(props.gsM_value);



    return(
        <div className="MainArea">
            <div className="content">
        
        {/* <div className="row">
                    <h4 className="col">Search History</h4>
                    <div className="col">
                    <button className="btn btn-primary" style={{justifyContent:"end"}} onClick={()=>props.sendToParent("Bill_Form")}> Back</button></div>
                    </div> */}
                    <h2>dhfg</h2>
        </div>
        </div>
        
    )

}


export default BillingDetails;