
import React from "react";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { useNavigate } from "react-router-dom";
import { Formik, Form, Field, ErrorMessage } from "formik";
import invoke from "./api";
import * as Yup from "yup";
import { Password } from 'primereact/password';
import logo from "./symbol Logo.png"
import { useState,useEffect, useRef} from "react";


function Login() {

  const navigate = useNavigate();
  const formRef = useRef(null);
 

  const initialValues = {
    userName: "",
    password: "",
  };
  const validationSchema = Yup.object({
    userName: Yup.string().required("User Name Required"),
    password: Yup.string().required("Password Required"),
  });


  const LoginAction = (val) => {
    invoke(
      "api/User/Login",
      "post",
      (data, success, status) => {
        if (success) {
          if (status === 200) {
            console.log(data);
            var userdata=data[0];
            sessionStorage.setItem("UserModule", JSON.stringify(data[1]));
            sessionStorage.setItem("UserData",JSON.stringify(userdata));
            sessionStorage.setItem("token", data[0].tokenString);
            sessionStorage.setItem("UserId", data[0].userId);
            
            navigate('/nav')
          }
          
        }
      }
      , val)
    
    return (
      sessionStorage.getItem("UserData"))
  }




  return (

    <div className="login-screen login-form content" style={{margin: 0, padding: 0,overflow:"hidden"}} >
    <div class="half-circle">
</div>
<div class="car">    
            <div class="p1">
            <div class="hc1">
            </div>   
            </div>

            <div class="p2" style={{padding:30}}>
                <div class="sigincontainer">
                   <h2>My Assist</h2>
                   <img src={logo} alt="Logo" style={{width:"30%",height:100}}></img> 
                </div>
                <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={(values) => {
          LoginAction(values)
 
          }}
        >
          {({ errors, touched, handleSubmit }) => (
            <Form style={{ width: "100%" }} className="p-fluid">
              <div className="field" style={{paddingRight:"10%"}}>
                <span className=" p-input-icon-right" style={{textAlign:"left"}}>
                <label htmlFor="userName" className="label">
                    User Name
                  </label>
                  <Field
                    style={{ height:" 40px", border: '1px solid rgb(198, 189, 189)', borderRadius: '8px'}}
                    id="userName"
                    name="userName"
                    as={InputText}
                    placeholder="User Name"
                    className={
                      errors.userName && touched.userName ? "p-invalid " : ""
                    }
                  />
                  <i className="pi pi-user" style={{fontSize:20, height:40, paddingLeft:5, paddingTop:10}}/>
                  
                </span>
                <ErrorMessage
                  name="userName"
                  component="div"
                  className="p-error"
                  style={{ display: "flex" }}
                />
              </div>

              <div className="field" style={{paddingRight:"10%", verticalAlign:"middle" }}>
                <span style={{ marginTop: "25px", textAlign:"left" }} className="p-input-icon-left">
                <label htmlFor="username" className="label">
                    Password
                  </label>
                  <Field
                    inputStyle={{ height:" 40px", border: '1px solid rgb(198, 189, 189)', borderRadius: '8px' ,overflow: "hidden", top:10}}
                    name="password"
                    as={Password}
                    placeholder="Password"
                    className={
                      errors.password && touched.password ? "p-invalid" : ""
                    }
                    feedback={false}
                     toggleMask
                  />

                </span>
                <ErrorMessage
                  name="password"
                  component="div"
                  className="p-error"
                  style={{ display: "flex" }}
                />
              </div>
              <div style={{width:"100%", textAlign:"center"}}>
              <button 
                style={{ paddingRight:25, paddingLeft:25, width:"80%", backgroundColor:"#0dcaf0", border:"1px solid #0dcaf0"}}
                onClick={handleSubmit}
                type="button"
                label="Login"
                className="mt-3 btn btn-primary"
                
              >Login</button></div>
            </Form>
          )}
        </Formik>
            </div>
        </div>

 
    </div>
  );
}




export default Login;

