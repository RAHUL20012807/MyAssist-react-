import axios from "axios";


let axios_instance = axios.create({
  baseURL: process.env.REACT_APP_API_URL,
  timeout: process.env.REACT_APP_API_TIMEOUT,
});

//
let invoke = (path, method, callback, data, params) => {
  
    let config = {
      method: method,
      url: path,
    };
    if (data !== undefined) {
      config["data"] = data;
    }
    if (params !== undefined) {
      config["params"] = params;
    }
    if (path !== "api/User/Login") {
      let contentType = "application/json";
      
      const token = sessionStorage.getItem("token");
      // console.log(token);
      config["headers"] = {
        Authorization: "bearer " + token,
        "Content-Type": contentType,
        TimeZone: new Date().toString().match(/\(([A-Za-z\s].*)\)/)[1],
        IpAddress: "",
        "Access-Control-Allow-Origin": process.env.REACT_APP_API_URL,
      };
    } else {
      config["headers"] = {
        "Access-Control-Allow-Origin": process.env.REACT_APP_API_URL,
      };
    }
    axios_instance
      .request(config)
      .then((res) => {
        if (res.status === 401) {
          window.location.pathname = "";
          sessionStorage.clear();
        }
        callback(res.data, true, res.status);
      })
      .catch((err) => {
        if (err.response && err.response.status === 403 && path !== "login") {
        } else if (err.response && err.response.status === 401) {
          window.location.pathname = "";
          sessionStorage.clear();
        } else if (err.response && err.response.status === 500) {
          console.log(err.response);
          callback(
            err.response.statusText,
            false,
            err.response.status
          );
        } else {
          //callback(null, false, err.response.status);
          try{
          callback(null, false,err.response.status);
          }
          catch{
             window.location.pathname = "";
            sessionStorage.clear();
          
          }
        }
      });
  };
//}





export default invoke;
