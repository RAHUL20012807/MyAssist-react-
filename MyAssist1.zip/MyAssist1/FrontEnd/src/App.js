import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, Routes } from 'react-router-dom';
import Claim from './pages/Claims/Claim';
import Member from './pages/Member/Member';
import Provider from './pages/Provider/Provider';
import Billing from './pages/Billing/Billing';
import Um from './pages/UM/Um';
import Benifits from './pages/Benifits/Benifits';
import  Navbar from './Navbar';
import Sales from './pages/Sales';
import Login from './Login';
import Myprofile from './User/Myprofile';
import UserManagement from './User/UserManagement';
import { useState , useEffect} from 'react';
import { useNavigate } from "react-router-dom";



function App() {
 
  const navigate = useNavigate();
console.log("hello");
  var l= sessionStorage.getItem("UserData");
  const [Acc, setAcc]= useState(false);
useEffect (()=>{
  if(l!=""&&l!==null){
  setAcc(true)
  }
},[l]);


if(window.location.pathname==="/login" ||  window.location.pathname==="/"){
  sessionStorage.clear();
    document.body.classList.add('bgOvfly');
}
else{
    document.body.classList.remove('bgOvfly');
  }

  return (
      <>
      <Routes>
        <Route index element={<Login />} />
        <Route path='/login' element={<Login />}></Route>
         <Route path='/nav' element={<Navbar />}> 
        <Route path='MyProfile' element={<Myprofile/>}/>
        <Route path='UserManagement' element={<UserManagement/>}/>  
          <Route index element={<Claim/>}/>
          <Route path='claim' element={<Claim />}/>
          <Route path='member' element={<Member/>}/>
          <Route path='provider' element={<Provider/>}/>
          <Route path='billing' element={<Billing/>}/>
          <Route path='um' element={<Um/>}/>
          <Route path='benifits' element={<Benifits/>}/>
          <Route path='sales' element={<Sales/>}/>
          <Route path='sales' element={<Sales/>}/>
        </Route>
      </Routes>
        </>  
  );
}






 export default App;



