import React from "react";
import {useNavigate} from "react-router-dom"
import invoke from "./../api";
import { useState } from "react";


function Myprofile(){

    const navigate = useNavigate();
    const [permission, setpermission] = useState(true);
   


    var obj = JSON.parse(sessionStorage.getItem('UserData'));
    console.log(obj);
    const [usr_na, setusr_na] = useState(obj.strUsrNme);
    const [pass, setPass] = useState(obj.strPassword);
    const [fst_na, setfst_na] = useState(obj.firstname);
    const [lst_na, setlst_na] = useState(obj.lastname);

    const [passTouched, setPassTouched] = useState(false);
    const [fstNaTouched, setFstNaTouched] = useState(false);
    const [lstNaTouched, setLstNaTouched] = useState(false);
  
    const [srh_Acc, setSrh_Acc] = useState(false);
  
    const validatePass = () => {
      if (passTouched && pass.trim() === '') {
        return 'Password is required'; 
      }
      return ''; 
    };

    const validateFstNa = () => {
      if (fstNaTouched && fst_na.trim() === '') {
        return 'First name is required';
      }
      return ''; 
    };
    const validateLstNa = () => {
      if (lstNaTouched && lst_na.trim() === '') {
        return 'Last name is required';
      }
      return ''; 
    };

    const passErrorMessage = validatePass();
    const fstNaErrorMessage = validateFstNa();
    const lstNaErrorMessage = validateLstNa();

    const [isVisible, setIsVisible] = useState(false);

    const toggleVisibility = () => {
      setIsVisible(!isVisible);
    };


    return(
        <div className="content">
          <div  style={{width:"70%", margin:"auto"}}>
            <h3 style={{textAlign:"center"}}>User Profile</h3>
        

<form noValidate className="form  form-multiline" id="myForm" >
<div className="form-group row ">
        <label className="control-label lab">User Name</label>
        
        <input type="text" className="form-control set" value={usr_na} onChange={(e)=>setusr_na(e.target.value)} id="userName" disabled></input>
        </div>


<div className="form-group row ">
        <label className="control-label lab">password</label>
        <input type="text" className={`form-control set col-auto ${passErrorMessage ? 'is-invalid' : ''}`}
         value={pass} onChange={(e)=>{setPass(e.target.value);setPassTouched(true);}} id="password" ></input>
         {passErrorMessage && <div className="Input feedback">{passErrorMessage}</div>}
        </div>


<div className="form-group row ">
        <label className="control-label lab ">First Name</label>
        <input type="text" className={`form-control set col-auto ${fstNaErrorMessage ? 'is-invalid' : ''}`}
        value={fst_na} onChange={(e)=>{setfst_na(e.target.value); setFstNaTouched(true);}} id="firstName" ></input>
        {fstNaErrorMessage && <div className="Input feedback">{fstNaErrorMessage}</div>}
        </div>

<div className="form-group row ">
        <label className="control-label lab ">Last Name</label>
        <input type="text" className={`form-control set col-auto ${lstNaErrorMessage ? 'is-invalid' : ''}`}
        value={lst_na} onChange={(e)=>{setlst_na(e.target.value); setLstNaTouched(true)}} id="lastName" ></input>
        {lstNaErrorMessage && <div className="Input feedback">{lstNaErrorMessage}</div>}
        </div>
<div style={{textAlign:"center"}}>
        <button type="button" onClick={()=>{
          var val={
            
              "tokenString": "",
              "strUsrNme": usr_na,
              "strPassword": pass,
              "strRole": "",
              "userId": sessionStorage.getItem("UserId"),
              "roleId": 0,
              "strMsg": "",
              "firstname": fst_na,
              "lastname": lst_na,
              "lstModuleIds": [
                0
              ],
              "isActive": "",
              "enable": ""
            
          }
          invoke("api/User/Update_Profile", "post", (data, success, status) => {
            if (success) {
              if (status === 200) {
                console.log(data)
                if(data=="Success"){
                // setpermission(false)
                toggleVisibility()
                }
                
              }
            } 
          },val);
        }} className="btn btn-primary"  style={{width:"15%", marginRight:10, marginTop:20,  marginBottom:20, backgroundColor:"#0dcaf0", border:"#0dcaf0"}} disabled={(pass==="")||(fst_na==="")||(lst_na==="")?true:false}>Save</button>
        <button type="reset" onClick={()=>{
              
              setPass("");
              setfst_na("");
              setlst_na("");

        }} className="btn btn-primary"  style={{width:"15%", marginRight:10, marginTop:20,  marginBottom:20}}>Clear</button></div>
        <div>
      {isVisible && <p style={{color:"green"}}>Udated successfully.</p>}
    </div>
        </form>
        </div>
        </div>
    )


}

export default Myprofile;



