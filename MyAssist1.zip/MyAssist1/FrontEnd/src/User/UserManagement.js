import invoke from "./../api";
import React, { useEffect,useState,useRef } from "react";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { MultiSelect } from 'primereact/multiselect';
import AddUser from "./AddUser";
import { Toast } from "primereact/toast";


function UserManagement(){

    var [li,setli]=useState([]);

    var [Page,setPage]=useState("user_table");
    var [data_selected, setData_selected]=useState(null);
    console.log(Page);

    

    console.log(data_selected);

  
    useEffect(() => {
      invoke("api/User/get_Users", "post", (data, success, status) => {
        if (success) {
          if (status === 200) {
            console.log(data)
            setli(data)
            console.log(li)
          }
        } 
      },[])
    },[]);

 
    const getChildData=(val) =>{
      console.log(val)
      setPage(val);
    }
  



    //Add Page
    const [usr_na, setusr_na] = useState("");
    const [pass, setPass] = useState("");
    const [fst_na, setfst_na] = useState("");
    const [lst_na, setlst_na] = useState("");
    const [State_Value, setState_Value]=useState("");

    const toast = useRef(null);
    const [selectedUser_id,setSelectedUser_id]=useState("");
    const [selectedModules, setSelectedModules] = useState(null);
    
    const Modules = [
      {
        "strModuleName": "Claims",
        "userID": 0,
        "modulE_ID": 1
      },
      {
        "strModuleName": "Member",
        "userID": 0,
        "modulE_ID": 2
      },
      {
        "strModuleName": "Provider",
        "userID": 0,
        "modulE_ID": 3
      },
      {
        "strModuleName": "Billing",
        "userID": 0,
        "modulE_ID": 4
      },
      {
        "strModuleName": "UM",
        "userID": 0,
        "modulE_ID": 5
      },
      {
        "strModuleName": "Benefits",
        "userID": 0,
        "modulE_ID": 6
      },
      {
        "strModuleName": "Sales & Marketing",
        "userID": 0,
        "modulE_ID": 7
      }
    ];
console.log(selectedModules)

    const handleModuleChange = (e) => {
      console.log(e.target.value)
      const moduleId = parseInt(e.target.value);
    
      if (e.target.checked) {
        setSelectedModules([...selectedModules, Modules[moduleId-1]]);
      } else {
        setSelectedModules(selectedModules.filter(id => id.modulE_ID !== moduleId));
        console.log(selectedModules);
      }
    }
    console.log(selectedModules)


if(Page==="user_table"){
    return(
        <div className="content" >
          <Toast ref={toast} />
            
            <div className="row">
            <h2 className="col" style={{verticalAlign:"middle", marginTop:20}}>User Management</h2>
            <div className="col">
            <button className="btn btn-primary " style={{width:"30%", marginTop:20,  marginBottom:20, float:"right",  backgroundColor:"#0dcaf0", border:"1px solid #0dcaf0"}} onClick={()=>setPage("Add_page")} >Add</button>
            </div>
            </div>
            <div className="card">
            <DataTable value={li} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }}
            cellSelection paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink" scrollable scrollHeight="300px"
                   onSelectionChange={(e) => setData_selected(e.value)}   dataKey="userId" metaKeySelection={false}>
                <Column field="strUsrNme" header="User Name" style={{ width: '16.66%' }}></Column>
                <Column field="strPassword" header="Password" style={{ width: '16.66%' }}></Column>
                <Column field="firstname" header="First Name" style={{ width: '16.66%' }}></Column>
                <Column field="lastname" header="Last Name" style={{ width: '16.66%' }}></Column>
                <Column field="strRole" header="Role Name" style={{ width: '16.66%' }}></Column>
                <Column  header="Edit" style={{ width: '16.66%' }} body={row => <i className="pi pi-user-edit" style={{ fontSize: '1.5rem', color:"green", cursor:"pointer" }} onClick={()=>{
                  var id=row.userId;
                  console.log(id);
                  invoke("api/User/get_UserModules/"+id, "get", (data, success, status) => {
                    if (success) {
                      if (status == 200) {
                        console.log(data);
                        setSelectedModules(data);
                        console.log(selectedModules);
                        setPage("Edit_page");
                      }
                    } 
                  }
                  )
                  
                  console.log(row.strRole);
                 
                setState_Value(row.strRole);
    setfst_na(row.firstname);
    setlst_na(row.lastname);
       setusr_na  (row.strUsrNme);
      setPass(row.strPassword)  ;
      setSelectedUser_id(row.userId) ;  
      console.log(State_Value);
    

                }}></i>}></Column>
            </DataTable>
        </div>



        </div>
    )

}
else if(Page==="Add_page"){

  return(

<AddUser sendToParent={getChildData}/>
  )
}
else if(Page==="Edit_page"){

  return(
    <div className="content" >
  <Toast ref={toast} />
  <div style={{width:"70%", margin:"auto"}}>
<h3 style={{textAlign:"center"}}>Edit User</h3>

<form noValidate className="form  form-multiline" id="myForm" >
<div className="form-group row ">
        <label className="control-label lab">User Name</label>
        <input type="text" className="form-control set" value={usr_na} onChange={(e)=>setusr_na(e.target.value)} id="userName" style={{width:"60%"}}></input>
        </div>
<div className="form-group row ">
        <label className="control-label lab">Password</label>
        <input type="text" className="form-control set" value={pass} onChange={(e)=>setPass(e.target.value)} id="password" style={{width:"60%"}}></input>
        </div>
<div className="form-group row ">
        <label className="control-label lab">First Name</label>
        <input type="text" className="form-control set" value={fst_na} onChange={(e)=>setfst_na(e.target.value)} id="firstName" style={{width:"60%"}}></input>
        </div>
<div className="form-group row ">
        <label className="control-label lab">Last Name</label>
        <input type="text" className="form-control set" value={lst_na} onChange={(e)=>setlst_na(e.target.value)} id="lastName" style={{width:"60%"}}></input>
        </div>

        <div className="form-group row ">
        <label className="control-label lab">Role</label>
        <select className="form-control inp_text set" value={State_Value} placeholder="select" name="Role_type" id="Role_type" style={{width:"60%"}} onChange={event => setState_Value(event.target.value)}>               
                        <option value="">Select </option>
                        <option value="Administrator">Administrator</option>
                        <option value="User">User</option>
        </select>
        </div>

        <div className="form-group row ">
        <label className="control-label col-lg-2 lab">Modules</label>
        <label className="control-label col-auto">:</label>
        <div className="col" style={{width:"55%"}}>
{Modules.map((module) => (
    <div key={module.modulE_ID} className="form-check form-check-inline" style={{ width: "180px" }}>
      <input
        type="checkbox"
        className="form-check-input"
        id={`module-${module.modulE_ID}`}
        value={module.modulE_ID}
        checked={selectedModules ? selectedModules.map((item) => item.modulE_ID).includes(module.modulE_ID) : false}
        onChange={handleModuleChange}
      />
      <label className="form-check-label" htmlFor={`module-${module.modulE_ID}`}>
        {module.strModuleName}
      </label>
    </div>
  ))}
</div>

      
        </div>
<div style={{textAlign:"center", marginBottom:"50px"}}>
        <button type="button" onClick={()=>{
          var val={
            
              "tokenString": "",
              "strUsrNme": usr_na,
              "strPassword": pass,
              "strRole": "",
              "userId": selectedUser_id,
              "roleId": role_Int(State_Value),
              "strMsg": "",
              "firstname": fst_na,
              "lastname": lst_na,
              "lstModuleIds":selectedModules.map(item => item.modulE_ID),
              "isActive": "",
              "enable": ""
            
          }
          if(usr_na!==""&&pass!==""&&fst_na!==""&&lst_na!==""&&State_Value!==""){
          invoke("api/User/Update_User", "post", (data, success, status) => {
            if (success) {
              if (status === 200) {
                console.log(data)
                toast.current.show({ severity: "success", summary: "Success", detail: "updated Successfully", life: 3000 });
              }
            } 
          },val);}
          else{
       toast.current.show({ severity: "error", summary: "Error", detail:"Please enter required values", life: 3000 });
          }
        }} className="btn btn-primary"  style={{width:"15%", marginRight:10, marginTop:20,  marginBottom:20,  backgroundColor:"#0dcaf0", border:"1px solid #0dcaf0"}}>Save</button>
         <button className="btn btn-primary" onClick={()=>{setPage("user_table"); setData_selected(null);setSelectedModules(null)}} 
         style={{width:"15%", marginRight:10, marginTop:20,  marginBottom:20, backgroundColor:"rgb(33, 190, 33)", border:"1px solid rgb(33, 190, 33)"}} >Back</button></div>
        </form>
        </div>
    </div>
  )
      
}
}


function role_Int(val){
if(val==="Administrator"){return(1)}
else if(val==="User"){return(2)}
}

export default UserManagement;