import invoke from "./../api";
import React, { useEffect,useState,useRef } from "react";
import { useFormik } from "formik";
import { Toast } from "primereact/toast";



function AddUser(props){


   
    const [selectedModules, setSelectedModules] = useState([]);
    const [errmsg, seterrmsg] = useState("");
    const toast = useRef(null);
    
    const Modules = [
      {
        "strModuleName": "Claims",
        "userID": 0,
        "modulE_ID": 1
      },
      {
        "strModuleName": "Member",
        "userID": 0,
        "modulE_ID": 2
      },
      {
        "strModuleName": "Provider",
        "userID": 0,
        "modulE_ID": 3
      },
      {
        "strModuleName": "Billing",
        "userID": 0,
        "modulE_ID": 4
      },
      {
        "strModuleName": "UM",
        "userID": 0,
        "modulE_ID": 5
      },
      {
        "strModuleName": "Benefits",
        "userID": 0,
        "modulE_ID": 6
      },
      {
        "strModuleName": "Sales & Marketing",
        "userID": 0,
        "modulE_ID": 7
      }
    ];


    const formik = useFormik({
      initialValues: {
        usr_na:"",
        pass:"",
        fst_na:"",
        lst_na:"",
        State_Value:""
      },
      onSubmit: (values) => {
        var val={
          
          "tokenString": "",
          "strUsrNme": values.usr_na,
          "strPassword": values.pass,
          "strRole": "",
          "userId": sessionStorage.getItem("UserId"),
          "roleId": parseInt(values.State_Value),
          "strMsg": "",
          "firstname": values.fst_na,
          "lastname": values.lst_na,
          "lstModuleIds":selectedModules,
          "isActive": "",
          "enable": ""
        
      }
      if(values.State_Value===""||values.fst_na===""||values.lst_na===""||values.pass===""||values.usr_na===""){
        seterrmsg("Enter required fields");
       toast.current.show({ severity: "error", summary: "Error", detail:"Please enter required values", life: 3000 });

      }
      else{
      invoke("api/User/Add_User", "post", (data, success, status) => {
        if (success) {
          if (status === 200) {
            console.log(data)
            if(data=="Success"){
            console.log(data)
          //   toggleVisibility()
            }
            toast.current.show({ severity: "success", summary: "Success", detail: "Added Successfully", life: 3000 });
          }
        } 
      },val);
    }
            
      }
    })





const handleModuleChange = (e) => {
  const moduleId = parseInt(e.target.value);

  if (e.target.checked) {
    setSelectedModules([...selectedModules, moduleId]);
  } else {
    setSelectedModules(selectedModules.filter(id => id !== moduleId));
  }
};
console.log(selectedModules)



    return(
    <div className="content" >
      <div style={{width:"70%", margin:"auto"}}>
        <Toast ref={toast} />
    <h3 style={{textAlign:"center"}}>Add User</h3>
    <form noValidate className="form  form-multiline" id="myForm" onSubmit={formik.handleSubmit}>
<div className="form-group row ">
      <label className="control-label " style={{marginLeft:"80px"}}>User Name</label>
      
      <input type="text" className="form-control col-auto" value={formik.values.usr_na} onChange={formik.handleChange} id="usr_na" style={{width:"80%", margin:"auto"}}></input>
      </div>
<div className="form-group row ">
      <label className="control-label " style={{marginLeft:"80px"}}>Password</label>
      
      <input type="text" className="form-control col-auto" value={formik.values.pass} onChange={formik.handleChange} id="pass" style={{width:"80%", margin:"auto"}}></input>
      </div>
<div className="form-group row ">
      <label className="control-label " style={{marginLeft:"80px"}}>First Name</label>
      
      <input type="text" className="form-control col-auto" value={formik.values.fst_na} onChange={formik.handleChange} id="fst_na" style={{width:"80%", margin:"auto"}}></input>
      </div>
<div className="form-group row ">
      <label className="control-label " style={{marginLeft:"80px"}}>Last Name</label>
    
      <input type="text" className="form-control col-auto" value={formik.values.lst_na} onChange={formik.handleChange} id="lst_na" style={{width:"80%", margin:"auto"}}></input>
      </div>

      <div className="form-group row ">
      <label className="control-label " style={{marginLeft:"80px"}}>Role</label>
    
      <select className="form-control inp_text col-auto"  placeholder="select" name="State_Value" id="State_Value"  value={formik.values.State_Value} onChange={formik.handleChange}  style={{width:"80%", margin:"auto"}}>               
                      <option value="">Select </option>
                      <option value="1">Administrator</option>
                      <option value="2">User</option>
      </select>
      </div>

      <div className="form-group row ">
      <label className="control-label col-lg-2" style={{marginLeft:"80px"}}>Modules</label>
      <label className="control-label col-auto">:</label>
<div className="col" style={{width:"55%"}}>
{Modules.map((module) => (
            <div key={module.modulE_ID} className="form-check form-check-inline" style={{width:"180px"}}>
              <input
                type="checkbox"
                className="form-check-input"
                id={`module-${module.modulE_ID}`}
                value={module.modulE_ID}
                checked={selectedModules.includes(module.modulE_ID)}
                onChange={handleModuleChange}
              />
              <label
                className="form-check-label"
                htmlFor={`module-${module.modulE_ID}`}
              >
                {module.strModuleName}
              </label>
            </div>
          ))}
      </div>
      </div>
      <div style={{textAlign:"center", marginBottom:"50px"}}>
      <button type= "submit" onClick={formik.handleSubmit} className="btn btn-primary" style={{width:"15%", marginRight:10, marginTop:20, marginBottom:20,  backgroundColor:"#0dcaf0", border:"1px solid #0dcaf0"}}>Add</button>

       <button
            type="reset"
            className="btn btn-primary"
            style={{ width: "15%", marginRight: 10, marginTop: 20, marginBottom: 20}}
            onClick={() => {
              formik.resetForm();
              
            }}
          >
            Clear
          </button>
          <button className="btn btn-primary" onClick={()=>props.sendToParent("user_table")}  style={{width:"15%", marginRight:10, marginTop:20,  marginBottom:20,  backgroundColor:"rgb(33, 190, 33)", border:"1px solid rgb(33, 190, 33)"}} >Back</button>
          </div>
      <div>
  </div>
      </form>
</div>
  </div>
    )
}




export default AddUser;